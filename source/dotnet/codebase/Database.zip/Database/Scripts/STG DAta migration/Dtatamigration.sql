/*select 
	PROJECT_STEPS.ProjectStepID,PROJECT_STEPS.ProjectStepName, PROJECT_STEPS.ParentProjectStepID,PROJECT_STEPS.StepID
	,PROJECT_STEPS.ProjectID,ps.WebTitle,ps.StartDate,ps.EndDate,ps.BeforePeriodDescription
	,ps.DuringPeriodDescription,ps.AfterPeriodDescription,ps.Background,ps.ScopeOfActivities,ps.Instructions,ps.Remarks
	,ps.UpdatedBy,ps.DTS,ps.Status,ps.DetailPageURL
from 
	PROJECT_STEPS 
INNER JOIN
	Project_Step_Setup ps
ON
	PROJECT_STEPS.ProjectStepID = ps.ProjectStepID
WHERE PROJECT_STEPS.ProjectID=16 */
--select * from OPLM_CALL_FOR_INTENT where PROJECTID=16
--select * from OPUS_PROJECT_STEPS
--select * from OPUS_PROJECT_STEP_DATA_DEFINITION
--select * from OPUS_PROJECT_STEP_DATA
--DELETE OPUS_PROJECT_STEPS
--DELETE OPUS_PROJECT_STEP_DATA

--Intent to Call
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(4,1,0,'Call for Intent to Submit Candidate Standards','2010-01-01 09:00:00.000','2010-03-30 17:00:00.000',
				'NQF issued a Call for Intent to submit candidate standards for Imaging Efficiency. Notices of intent closed on November 16, 2009.  For additional information, see the full Call for Intent (PDF) document.',
				'NQF issued a Call for Intent to submit candidate standards for Imaging Efficiency. Notices of intent closed on November 16, 2009.  For additional information, see the full Call for Intent (PDF) document.',
				'NQF issued a Call for Intent to submit candidate standards for Imaging Efficiency. Notices of intent closed on November 16, 2009.  For additional information, see the full Call for Intent (PDF) document.',
				'Call for Intent to Submit Candidate Standards',16)

INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
			VALUES(1,4,'There is a clear need for measurement and research regarding the appropriate and effective use of imaging in a clinical setting. Medicare spends approximately $14 billion annually on outpatient imaging studies.i It is imperative to clarify which imaging procedures and technology result in improvements in patient care and possible decreases in healthcare costs. Given the specific inclusion of overuse of imaging procedures in the National Priorities Partnership, it is anticipated that these measures will seek to improve the rate of cost growth and enhance the quality of care provided.  To date, NQF has endorsed a limited number of imaging efficiency measures focused on appropriateness of imaging, efficient use and management of imaging diagnostic services, coordination of care and communication among all providers and departments regarding a diagnostic imaging service. NQF will implement this project as a follow-up project to the Outpatient Imaging Efficiency project report that was completed in November 2008. There was a limited set of measures that specifically examined the use of imaging procedures that were unlikely to result in improved patient outcomes. This follow-up project seeks to fill measurement gaps that address overuse of high cost, high risk imaging in the outpatient setting.')

INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
			VALUES(2,4,'NQF issued a Call for Intent to submit candidate standards for Imaging Efficiency. Notices of intent closed on November 16, 2009.  For additional information, see the full Call for Intent (PDF) document.')

INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
			VALUES(3,4,'NQF issued a Call for Intent to submit candidate standards for Imaging Efficiency. Notices of intent closed on November 16, 2009.  For additional information, see the full Call for Intent (PDF) document.')


--Call for nomination
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(30,2,0,'Call for Nominations','2010-01-01 09:00:00.000','2010-03-30 17:00:00.000',
				'The Call for Nominations closed on January 6, 2010. For information on the Steering Committee formation process, please refer to the Call for Nominations documents.',
				'The Call for Nominations closed on January 6, 2010. For information on the Steering Committee formation process, please refer to the Call for Nominations documents.',
				'The Call for Nominations closed on January 6, 2010. For information on the Steering Committee formation process, please refer to the Call for Nominations documents.',
				'Call for Nominations',16)

--Call for Candidate Standard
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(31,3,0,'Call for Candidate Standards','2010-01-01 09:00:00.000','2010-03-30 17:00:00.000',
				'The Call for Candidate Standards will open on December 7, 2009.',
				'The Call for Candidate Standards is currently open and will close on January 6, 2010.',
				'The Call for Candidate Standards closed on January 6, 2010.',
				'Call for Candidate Standards',16)

--Candidate Consensus Standards Review
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(32,4,0,'Candidate Consensus Standards Review','2010-01-01 09:00:00.000','2010-03-30 17:00:00.000',
				'CANDIDATE CONSENSUS STANDARDS REVIEW',
				'CANDIDATE CONSENSUS STANDARDS REVIEW',
				'CANDIDATE CONSENSUS STANDARDS REVIEW',
				'CANDIDATE CONSENSUS STANDARDS REVIEW',16)

--Nomination period
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(33,10,30,'CALL FOR NOMINATION','2010-01-11 09:00:00.000','2010-02-10 09:00:00.000',
				'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.',
				'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.',
				'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.',
				'CALL FOR NOMINATION',16)

--Submission period
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(34,12,31,'Call For Measures','2010-01-11 09:00:00.000','2010-02-10 09:00:00.000',
				'NQF received 9 measures to review for potential endorsement as national voluntary consensus standards.',
				'NQF received 9 measures to review for potential endorsement as national voluntary consensus standards.',
				'NQF received 9 measures to review for potential endorsement as national voluntary consensus standards.',
				'Call For Measures',16)
--Dynamic data
INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
			VALUES(5,34,'Materials must be submitted using the online measure submission form by 6:00 pm, ET on Wednesday, January 6, 2010. If you have any questions, please contact Ian Corbridge at 202.783.1300 or imagingefficiency2@qualityforum.org. Thank you for your assistance with this project!')


--Public and Member Comment
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(35,5,0,'Public and Member Comment','2010-02-09 00:00:00.000','2010-04-07 00:00:00.000',
				'The public and member commenting step will start on Tuesday, February 09, 2010.',
				'The public and member commenting step has begun.',
				'The public and member commenting step will conclude on April 7, 2010.',
				'Public and Member Commenting',16)

--Roster Commenting
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(36,11,30,'COMMENT ON PROPOSED ROSTER','2010-01-05 09:00:00.000','2010-01-19 09:00:00.000',
				'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.',
				'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.',
				'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.',
				'COMMENT ON PROPOSED ROSTER',16)

--Dynamic data
INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
			VALUES(4,36,'NQF Members and the public will have 14 days to comment on the roster of submitted nominees. The roster and the bios will be posted when the comment period begins.')

--Commenting Period
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(44,13,35,'Initial Measure Commenting Period','2010-01-19 10:00:00.000','2010-02-22 10:00:00.000',
				'Before description',
				'During description',
				'After description',
				'Initial Measure Commenting Period',16)

--Dynamic Data
INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
			VALUES(6,44,'2010-02-15 10:00:00.000')

--Submission Period
INSERT INTO OPUS_PROJECT_STEPS (ProjectStepID,ProjectTypeStepID,ProjectParentStepID,ProjectStepName,StartDAte
								,EndDate,BeforePeriodDescription,DuringPeriodDescription,AfterPeriodDescription,WebTitle
								,ProjectID)
			VALUES(55,12,31,'MEASURE SUBMISSION PERIOD','2010-01-28 09:00:00.000','2010-03-01 09:00:00.000',
				'BEFORE Period Description TEST',
				'DURING Period Description TEST',
				'AFTER Period Description TEST',
				'MEASURE SUBMISSION PERIOD',16)

----Dynamic data
--INSERT INTO OPUS_PROJECT_STEP_DATA(DefinitionID,ProjectStepID,[Value])
--			VALUES(5,55,'Materials must be submitted using the online measure submission form by 6:00 pm, ET on Wednesday, January 6, 2010. If you have any questions, please contact Ian Corbridge at 202.783.1300 or imagingefficiency2@qualityforum.org. Thank you for your assistance with this project!')




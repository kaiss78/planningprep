/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPLM
 * --Procedure name			: 
 * --Purpose/Function		: Gets iMIS user information from iMIS DB to local IMIS_USER_DERAILS Table (requires linked server)
 * --Author					: ZZ
 * --Start Date(MM/DD/YY)	: 01/25/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/25/2010		ZZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

PRINT 'Insterting into IMIS_USER_DETAILS';

TRUNCATE TABLE IMIS_USER_DETAILS

INSERT INTO IMIS_USER_DETAILS
(
IMISUserID
,FirstName
,LastName
,InstituteName
,InstituteContactId
,[PrimaryCouncil]
,[SecondaryCouncil]
,[ORG_CODE]
,[MEMBER_TYPE]
,[CATEGORY]
,[STATUS]
,[MAJOR_KEY]
,[CO_ID]
,[LAST_FIRST]
,[COMPANY_SORT]
,[BT_ID]
,[DUP_MATCH_KEY]
,[FULL_NAME]
,[TITLE]
,[COMPANY]
,[FULL_ADDRESS]
,[PREFIX]
,[MIDDLE_NAME]
,[SUFFIX]
,[DESIGNATION]
,[INFORMAL]
,[WORK_PHONE]
,[HOME_PHONE]
,[FAX]
,[TOLL_FREE]
,[CITY]
,[STATE_PROVINCE]
,[ZIP]
,[COUNTRY]
,[MAIL_CODE]
,[CRRT]
,[BAR_CODE]
,[COUNTY]
,[MAIL_ADDRESS_NUM]
,[BILL_ADDRESS_NUM]
,[GENDER]
,[BIRTH_DATE]
,[US_CONGRESS]
,[STATE_SENATE]
,[STATE_HOUSE]
,[SIC_CODE]
,[CHAPTER]
,[FUNCTIONAL_TITLE]
,[CONTACT_RANK]
,[MEMBER_RECORD]
,[COMPANY_RECORD]
,[JOIN_DATE]
,[SOURCE_CODE]
,[PAID_THRU]
,[MEMBER_STATUS]
,[MEMBER_STATUS_DATE]
,[PREVIOUS_MT]
,[MT_CHANGE_DATE]
,[CO_MEMBER_TYPE]
,[EXCLUDE_MAIL]
,[EXCLUDE_DIRECTORY]
,[DATE_ADDED]
,[LAST_UPDATED]
,[UPDATED_BY]
,[INTENT_TO_EDIT]
,[ADDRESS_NUM_1]
,[ADDRESS_NUM_2]
,[ADDRESS_NUM_3]
,[EMAIL]
,[WEBSITE]
,[TIME_STAMP]
,[SHIP_ADDRESS_NUM]
,[DISPLAY_CURRENCY]
,[WEB_LOGIN]
)

SELECT 
N.[ID] AS IMISUserID
,[FIRST_NAME] AS FirstName
,[LAST_NAME] AS LastName
,[COMPANY] AS InstituteName
,[CO_ID] AS InstituteContactId
,ND.[PrimaryCouncil]
,ND.[SecondaryCouncil]
,[ORG_CODE]
,[MEMBER_TYPE]
,[CATEGORY]
,[STATUS]
,[MAJOR_KEY]
,[CO_ID]
,[LAST_FIRST]
,[COMPANY_SORT]
,[BT_ID]
,[DUP_MATCH_KEY]
,[FULL_NAME]
,[TITLE]
,[COMPANY]
,[FULL_ADDRESS]
,[PREFIX]
,[MIDDLE_NAME]
,[SUFFIX]
,[DESIGNATION]
,[INFORMAL]
,[WORK_PHONE]
,[HOME_PHONE]
,[FAX]
,[TOLL_FREE]
,[CITY]
,[STATE_PROVINCE]
,[ZIP]
,[COUNTRY]
,[MAIL_CODE]
,[CRRT]
,[BAR_CODE]
,[COUNTY]
,[MAIL_ADDRESS_NUM]
,[BILL_ADDRESS_NUM]
,[GENDER] [varchar]
,[BIRTH_DATE]
,[US_CONGRESS]
,[STATE_SENATE]
,[STATE_HOUSE]
,[SIC_CODE]
,[CHAPTER]
,[FUNCTIONAL_TITLE]
,[CONTACT_RANK]
,[MEMBER_RECORD]
,[COMPANY_RECORD]
,[JOIN_DATE]
,[SOURCE_CODE]
,[PAID_THRU]
,[MEMBER_STATUS]
,[MEMBER_STATUS_DATE]
,[PREVIOUS_MT]
,[MT_CHANGE_DATE]
,[CO_MEMBER_TYPE]
,[EXCLUDE_MAIL]
,[EXCLUDE_DIRECTORY]
,[DATE_ADDED]
,[LAST_UPDATED]
, N.[UPDATED_BY]
,[INTENT_TO_EDIT]
,[ADDRESS_NUM_1]
,[ADDRESS_NUM_2]
,[ADDRESS_NUM_3]
,[EMAIL]
,[WEBSITE]
,GETDATE() AS TIME_STAMP
,[SHIP_ADDRESS_NUM]
,[DISPLAY_CURRENCY]
,NS.WEB_LOGIN
FROM [LinkToIMISDB].[iMIS_NQF_Dev].[dbo].[Name] AS N
INNER JOIN [LinkToIMISDB].[iMIS_NQF_Dev].[dbo].[NQF_DEMO] AS ND
ON N.ID=ND.ID
INNER JOIN [LinkToIMISDB].[iMIS_NQF_Dev].[dbo].[NAME_SECURITY] AS NS  
ON
NS.ID = N.ID


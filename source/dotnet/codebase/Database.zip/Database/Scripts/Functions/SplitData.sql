SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SplitData'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Dropping function SplitData.';
	DROP FUNCTION dbo.SplitData;
END

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

/*-------------------------------------------------
 * Project Name: OPUS
 * Client Name: NQF
 * Procedure name: dbo.SplitData
 * Purpose/Function: Returns tabular data splitting by given character
 * Author : MI
 * Start Date: 10-29-2009
 * End Date:   
---------------------------------------------------*/

CREATE function [dbo].[SplitData](@text text,@delimiter char(1)=',')
returns @ids table
(    
  position int identity(1,1) not null,
  id varchar(max)  
)
as
begin
	declare @index int,@textindex  int,@chunklen smallint,@tmpstr   varchar(8000),@leftover varchar(8000), @value   varchar(30)
	set @textindex = 1
	set @leftover = ''
	while @textindex <= datalength(@text) 
	begin
         set @chunklen = 8000 - datalength(@leftover) 
         set @tmpstr = @leftover + substring(@text, @textindex, @chunklen)
         set @textindex = @textindex + @chunklen

         set @index = charindex(@delimiter, @tmpstr)

         while @index > 0
         begin
            set @value = ltrim(rtrim(left(@tmpstr, @index - 1)))
            insert into @ids (id) VALUES(@value)
            set @tmpstr = substring(@tmpstr, @index + 1, len(@tmpstr))
            set @index = charindex(@delimiter, @tmpstr)
         end
         set @leftover = @tmpstr
	end
	insert into @ids(id) values (ltrim(rtrim(@leftover)))
	return
end

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SplitData'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Function SplitData created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create function SplitData.';
END
GO

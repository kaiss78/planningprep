SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'HAS_NOMINEE_FORM_COMPLETED'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Dropping function HAS_NOMINEE_FORM_COMPLETED.';
	DROP FUNCTION dbo.HAS_NOMINEE_FORM_COMPLETED;
END

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
go

/*-------------------------------------------------
 * Project Name: OPUS
 * Client Name: NQF
 * Procedure name: dbo.HAS_NOMINEE_FORM_COMPLETED
 * Purpose/Function: Returns Comma Separated Committee Names for a Nominee
 * Author : MHR
 * Start Date: 11-30-2009
 * End Date:   
---------------------------------------------------*/
--SELECT dbo.HAS_NOMINEE_FORM_COMPLETED(71, 1)
CREATE FUNCTION dbo.HAS_NOMINEE_FORM_COMPLETED(
	@NomineeID BIGINT	
)
RETURNS BIT

AS
BEGIN
	DECLARE @ISCompleted BIT
	DECLARE @LetterOfInterestFileName VARCHAR(255)
	DECLARE @CVorExperienceFileName VARCHAR(255)
	DECLARE @NonDisclosureAgreementFileName VARCHAR(255)
	DECLARE @ShortBiography VARCHAR(255)

	SELECT 
		 @LetterOfInterestFileName= ISNULL(files.LetterOfInterestFileName,'')
		,@CVorExperienceFileName=  ISNULL(files.CVorExperienceFileName,'')
		,@NonDisclosureAgreementFileName=  ISNULL(files.NonDisclosureAgreementFileName,'')
		,@ShortBiography=  ISNULL(nom.ShortBiography,'')
	FROM dbo.NOMINEES_FILES files
	INNER JOIN 
	     dbo.NOMINEE_OF_COMMITTEE nom
	ON files.NomineeID = nom.NomineeID
	WHERE nom.NomineeID = @NomineeID;	

    IF @LetterOfInterestFileName <>'' AND @CVorExperienceFileName<>'' AND  @NonDisclosureAgreementFileName <>'' AND  @ShortBiography <> ''
      BEGIN
        SET @ISCompleted = 1
      END
	ELSE
      BEGIN
        SET @ISCompleted = 0;
      END

	RETURN @ISCompleted;
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'HAS_NOMINEE_FORM_COMPLETED'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Function HAS_NOMINEE_FORM_COMPLETED created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create function HAS_NOMINEE_FORM_COMPLETED.';
END
GO
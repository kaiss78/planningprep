SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'HtmlDecode'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Dropping function HtmlDecode.';
	DROP FUNCTION dbo.HtmlDecode;
END

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
go

/*-------------------------------------------------
 * Project Name: OPUS
 * Client Name: NQF
 * Procedure name: dbo.HtmlDecode
 * Purpose/Function: Returns Comma Separated Committee Names for a Nominee
 * Author : HA
 * Start Date: 11-30-2009
 * End Date:   
---------------------------------------------------*/
--select dbo.HtmlDecode('Test_01172010_01&amp;acute;asd&amp;quot;asd&amp;sdf&amp;lt;sdf&amp;gt;')
CREATE FUNCTION dbo.HtmlDecode(
    @Encoded VARCHAR(MAX)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @Decoded VARCHAR(MAX);

  --order is important here. Replace the amp first, then the lt and gt. 
  --otherwise the &lt will become &amp;lt; 

	SELECT @Decoded = Replace(@Encoded,'&amp;','&');
	WHILE(CHARINDEX('&amp;', @Decoded) > 0)
	BEGIN
		SELECT @Decoded = Replace(@Decoded,'&amp;','&');
	END
	SELECT @Decoded = Replace(@Decoded,'&lt;','<');
	SELECT @Decoded = Replace(@Decoded,'&gt;','>');
	SELECT @Decoded = Replace(@Decoded,'&quot;','"');
	SELECT @Decoded = Replace(@Decoded,'&acute;','''');
	
	RETURN @Decoded
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'HtmlDecode'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Function HtmlDecode created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create function HtmlDecode.';
END
GO
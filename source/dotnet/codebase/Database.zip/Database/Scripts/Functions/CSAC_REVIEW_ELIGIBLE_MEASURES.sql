SET QUOTED_IDENTIFIER OFF;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'CSAC_REVIEW_ELIGIBLE_MEASURES'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Dropping function CSAC_REVIEW_ELIGIBLE_MEASURES.';
	IF EXISTS ( SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'MSF_STATUS_CHANGE' AND COLUMN_NAME = 'IMISUserID')
	BEGIN
		ALTER TABLE MSF_STATUS_CHANGE
		DROP COLUMN [IMISUserID]
	END
	DROP FUNCTION dbo.CSAC_REVIEW_ELIGIBLE_MEASURES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: NQF - OPLM. Project Management
 * --Procedure name			: CSAC_REVIEW_ELIGIBLE_MEASURES
 * --Purpose/Function		: Get Semicolon separated category for the provided Intent Submission ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 10/29/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date						Name	Comments
 * 298th October, 2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--SELECT DBO.CSAC_REVIEW_ELIGIBLE_MEASURES(479, 112201)
CREATE FUNCTION CSAC_REVIEW_ELIGIBLE_MEASURES()
RETURNS @MEASURES TABLE
(
  MeasureID BIGINT
)
AS

BEGIN
	INSERT INTO @MEASURES 
	SELECT 
		DISTINCT ms.ID 
	FROM 
		MSF_SUBMISSIONS ms
	INNER JOIN
		VOTING_RESULTS vr
	ON
		vr.MeasureID = ms.ID	
	WHERE 
		ms.StatusSubmitted in (18,31,23)
		OR
	    (ms.StatusSubmitted = 33 AND ms.PublishUnpublishDate + 30 < GETDATE())
	return
END
GO

------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'CSAC_REVIEW_ELIGIBLE_MEASURES'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Function CSAC_REVIEW_ELIGIBLE_MEASURES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create function CSAC_REVIEW_ELIGIBLE_MEASURES.';
END
GO




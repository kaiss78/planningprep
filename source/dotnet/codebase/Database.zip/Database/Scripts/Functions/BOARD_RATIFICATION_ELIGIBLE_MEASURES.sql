SET QUOTED_IDENTIFIER OFF;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'BOARD_RATIFICATION_ELIGIBLE_MEASURES'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Dropping function BOARD_RATIFICATION_ELIGIBLE_MEASURES.';
	IF EXISTS ( SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'MSF_STATUS_CHANGE' AND COLUMN_NAME = 'IMISUserID')
	BEGIN
		ALTER TABLE MSF_STATUS_CHANGE
		DROP COLUMN [IMISUserID]
	END
	DROP FUNCTION dbo.BOARD_RATIFICATION_ELIGIBLE_MEASURES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: NQF - OPLM. Project Management
 * --Procedure name			: BOARD_RATIFICATION_ELIGIBLE_MEASURES
 * --Purpose/Function		: Fetches all the measures ELIGIBLE for Board Ratification
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 02/17/10
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date						Name	Comments
 * 17th February, 2009		MHA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--SELECT DBO.BOARD_RATIFICATION_ELIGIBLE_MEASURES(479, 112201)
CREATE FUNCTION BOARD_RATIFICATION_ELIGIBLE_MEASURES()
RETURNS @MEASURES TABLE
(
  MeasureID BIGINT
)
AS

BEGIN
	INSERT INTO @MEASURES 
	SELECT 
		DISTINCT ms.ID 
	FROM 
		MSF_SUBMISSIONS ms	
	WHERE 
		ms.StatusSubmitted in (20,21,22,37)
		--AND ms.ID NOT IN (SELECT MeasureID FROM VW_MEETING_DATES_WITH_MEASURES)
	return
END
GO

------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'BOARD_RATIFICATION_ELIGIBLE_MEASURES'
				AND ROUTINE_TYPE = 'FUNCTION' )
BEGIN
	PRINT 'Function BOARD_RATIFICATION_ELIGIBLE_MEASURES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create function BOARD_RATIFICATION_ELIGIBLE_MEASURES.';
END
GO




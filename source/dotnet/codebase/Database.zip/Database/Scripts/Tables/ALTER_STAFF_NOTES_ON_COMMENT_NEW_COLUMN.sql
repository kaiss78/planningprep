Alter table dbo.STAFF_NOTES_ON_COMMENTS add FinalResponseOPLMUserID BIGINT
Go
update dbo.STAFF_NOTES_ON_COMMENTS set FinalResponseOPLMUserID = OPLMUserID
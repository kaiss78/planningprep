/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPLM
 * --Table name 			: OPLM_HISTORY_DATA
 * --Purpose/Function		: Table to maintain history Data
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/22/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: MHA
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 10/22/09		AFS	Initial Development				
 * ===================================================================*/

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

DECLARE @AlteredFlag BIT
SELECT @AlteredFlag	= 0;

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.TABLES
			WHERE TABLE_SCHEMA = 'dbo'
				AND TABLE_NAME = 'OPLM_HISTORY_DATA'
				AND TABLE_TYPE = 'BASE TABLE' )
-------------------------------------------------------------------------------
--Table already exists - do ALTER condition
-------------------------------------------------------------------------------
BEGIN
	/*
	IF NOT EXISTS ( SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'OPLM_HISTORY_DATA' AND COLUMN_NAME = 'StartDate' )
	BEGIN
		ALTER TABLE dbo.OPLM_HISTORY_DATA ADD StartDate SMALLDATETIME NULL;
		PRINT 'dbo.OPLM_HISTORY_DATA.StartDate column added.';
		SET @AlteredFlag = 1;
	END
	*/
	IF ( @AlteredFlag = 1 )
	BEGIN
		PRINT 'Table OPLM_HISTORY_DATA altered with latest changes.';		
		PRINT 'Table OPLM_HISTORY_DATA successfully upgraded.';
	END
	ELSE
	BEGIN
		PRINT 'Table OPLM_HISTORY_DATA requires no changes.';
	END
END
ELSE
-------------------------------------------------------------------------------
--Table does not exist - do CREATE condition
-------------------------------------------------------------------------------
BEGIN
	CREATE TABLE [dbo].[OPLM_HISTORY_DATA](
	[HistoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[ProjectID] [bigint] NOT NULL,
	[DataTypeName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DataTypeCode] [tinyint] NOT NULL,
	[FieldName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[SQLFieldTypeCode] [tinyint] NOT NULL,
	[BeforeValue] [sql_variant] NULL,
	[AfterValue] [sql_variant] NULL,
	[UserID] [bigint] NOT NULL,
	[UserName] [varchar](60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[UserFirstName] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UserLastName] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DataID] [bigint] NOT NULL,
	[DataName] [varchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DTS] [datetime] NOT NULL,
	[PreviousDTS] [datetime] NULL,
 CONSTRAINT [PK_OPLM_HISTORY_DATA] PRIMARY KEY CLUSTERED 
(
	[HistoryID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
-- Make sure object was created successfully.
	IF EXISTS (	SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'dbo'
					AND TABLE_NAME = 'OPLM_HISTORY_DATA'
					AND TABLE_TYPE = 'BASE TABLE' )


	BEGIN
		PRINT 'Table OPLM_HISTORY_DATA created successfully.';	
	END
	ELSE
	BEGIN
		PRINT 'ERROR: Failed to create Table OPLM_HISTORY_DATA.';
	END
END
GO




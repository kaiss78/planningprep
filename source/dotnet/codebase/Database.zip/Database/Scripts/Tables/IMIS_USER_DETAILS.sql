/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Table name 			: MSFUser Details
 * --Purpose/Function		: Keeps iMIS User Details from iMISDB
 * --Author					: ZZ
 * --Start Date(MM/DD/YY)	: 01/12/10
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 01/01/10		ZZ		Initial Development				
 * ===================================================================*/

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

DECLARE @AlteredFlag BIT
SELECT @AlteredFlag	= 0;

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.TABLES
			WHERE TABLE_SCHEMA = 'dbo'
				AND TABLE_NAME = 'IMIS_USER_DETAILS'
				AND TABLE_TYPE = 'BASE TABLE' )
-------------------------------------------------------------------------------
--Table already exists - do ALTER condition
-------------------------------------------------------------------------------
-- Here will be the alter statements
-------------------------------------------------------------------------------
BEGIN
	IF NOT EXISTS ( SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'IMIS_USER_DETAILS' AND COLUMN_NAME = 'web_login')
		BEGIN
			ALTER TABLE dbo.IMIS_USER_DETAILS ADD [web_login] [VARCHAR](60) null
			PRINT 'dbo.IMIS_USER_DETAILS.web_login column added.';
			SET @AlteredFlag = 1;
		END	

	IF ( @AlteredFlag = 1 )
	BEGIN
		PRINT 'Table IMIS_USER_DETAILS altered with latest changes.';		
		PRINT 'Table IMIS_USER_DETAILS successfully upgraded.';
	END
	ELSE
	BEGIN
		PRINT 'Table IMIS_USER_DETAILS requires no changes.';
	END
END
ELSE
-------------------------------------------------------------------------------
--Table does not exist - do CREATE condition
-------------------------------------------------------------------------------
BEGIN
	CREATE TABLE [dbo].[IMIS_USER_DETAILS](
		[IMISUserID] [varchar](10) NOT NULL DEFAULT (''),
		[web_login] [varchar](60) NOT NULL DEFAULT (''),
		[FirstName] [varchar](20) NOT NULL DEFAULT (''),
		[LastName] [varchar](30) NOT NULL DEFAULT (''),
		[InstituteName] [varchar](80) NOT NULL DEFAULT (''),
		[InstituteContactId] [varchar](10) NOT NULL DEFAULT (''),
		[PrimaryCouncil] [varchar](25) NOT NULL DEFAULT (''),
		[SecondaryCouncil] [varchar](25) NOT NULL DEFAULT (''),
		[ORG_CODE] [varchar](5) NOT NULL DEFAULT (''),
		[MEMBER_TYPE] [varchar](5) NOT NULL DEFAULT (''),
		[CATEGORY] [varchar](5) NOT NULL DEFAULT (''),
		[STATUS] [varchar](5) NOT NULL DEFAULT (''),
		[MAJOR_KEY] [varchar](15) NOT NULL DEFAULT (''),
		[CO_ID] [varchar](10) NOT NULL DEFAULT (''),
		[LAST_FIRST] [varchar](30) NOT NULL DEFAULT (''),
		[COMPANY_SORT] [varchar](30) NOT NULL  DEFAULT (''),
		[BT_ID] [varchar](10) NOT NULL DEFAULT (''),
		[DUP_MATCH_KEY] [varchar](20) NOT NULL DEFAULT (''),
		[FULL_NAME] [varchar](70) NOT NULL DEFAULT (''),
		[TITLE] [varchar](80) NOT NULL DEFAULT (''),
		[COMPANY] [varchar](80) NOT NULL DEFAULT (''),
		[FULL_ADDRESS] [varchar](255) NOT NULL DEFAULT (''),
		[PREFIX] [varchar](25) NOT NULL DEFAULT (''),
		[MIDDLE_NAME] [varchar](20) NOT NULL DEFAULT (''),
		[SUFFIX] [varchar](10) NOT NULL DEFAULT (''),
		[DESIGNATION] [varchar](20) NOT NULL DEFAULT (''),
		[INFORMAL] [varchar](20) NOT NULL DEFAULT (''),
		[WORK_PHONE] [varchar](25) NOT NULL DEFAULT (''),
		[HOME_PHONE] [varchar](25) NOT NULL DEFAULT (''),
		[FAX] [varchar](25) NOT NULL DEFAULT (''),
		[TOLL_FREE] [varchar](25) NOT NULL DEFAULT (''),
		[CITY] [varchar](40) NOT NULL DEFAULT (''),
		[STATE_PROVINCE] [varchar](15) NOT NULL DEFAULT (''),
		[ZIP] [varchar](10) NOT NULL DEFAULT (''),
		[COUNTRY] [varchar](25) NOT NULL DEFAULT (''),
		[MAIL_CODE] [varchar](5) NOT NULL DEFAULT (''),
		[CRRT] [varchar](40) NOT NULL DEFAULT (''),
		[BAR_CODE] [varchar](14) NOT NULL DEFAULT (''),
		[COUNTY] [varchar](30) NOT NULL DEFAULT (''),
		[MAIL_ADDRESS_NUM] [int] NOT NULL DEFAULT ((0)),
		[BILL_ADDRESS_NUM] [int] NOT NULL DEFAULT ((0)),
		[GENDER] [varchar](1) NOT NULL DEFAULT (''),
		[BIRTH_DATE] [datetime] NULL,
		[US_CONGRESS] [varchar](20) NOT NULL DEFAULT (''),
		[STATE_SENATE] [varchar](20) NOT NULL DEFAULT (''),
		[STATE_HOUSE] [varchar](20) NOT NULL DEFAULT (''),
		[SIC_CODE] [varchar](10) NOT NULL DEFAULT (''),
		[CHAPTER] [varchar](15) NOT NULL DEFAULT (''),
		[FUNCTIONAL_TITLE] [varchar](50) DEFAULT (''),
		[CONTACT_RANK] [int] NOT NULL DEFAULT ((0)),
		[MEMBER_RECORD] [bit] NOT NULL DEFAULT ((0)),
		[COMPANY_RECORD] [bit] NOT NULL DEFAULT ((0)),
		[JOIN_DATE] [datetime] NULL,
		[SOURCE_CODE] [varchar](40) NOT NULL DEFAULT (''),
		[PAID_THRU] [datetime] NULL,
		[MEMBER_STATUS] [varchar](5) NOT NULL DEFAULT (''),
		[MEMBER_STATUS_DATE] [datetime] NULL,
		[PREVIOUS_MT] [varchar](5) NOT NULL DEFAULT (''),
		[MT_CHANGE_DATE] [datetime] NULL,
		[CO_MEMBER_TYPE] [varchar](5) NOT NULL DEFAULT (''),
		[EXCLUDE_MAIL] [bit] NOT NULL DEFAULT ((0)),
		[EXCLUDE_DIRECTORY] [bit] NOT NULL DEFAULT ((0)),
		[DATE_ADDED] [datetime] NULL,
		[LAST_UPDATED] [datetime] NULL,
		[UPDATED_BY] [varchar](60) NOT NULL DEFAULT (''),
		[INTENT_TO_EDIT] [varchar](30) NOT NULL DEFAULT (''),
		[ADDRESS_NUM_1] [int] NOT NULL DEFAULT ((0)),
		[ADDRESS_NUM_2] [int] NOT NULL DEFAULT ((0)),
		[ADDRESS_NUM_3] [int] NOT NULL DEFAULT ((0)),
		[EMAIL] [varchar](100) NOT NULL DEFAULT (''),
		[WEBSITE] [varchar](255) NOT NULL DEFAULT (''),
		[TIME_STAMP] [datetime] NULL,
		[SHIP_ADDRESS_NUM] [int] NOT NULL DEFAULT ((0)),
		[DISPLAY_CURRENCY] [varchar](3) NOT NULL DEFAULT (''),
		CONSTRAINT [PK_IMIS_USER_DETAILS_IMISUserID] PRIMARY KEY CLUSTERED 
		(
			[IMISUserID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
-- Make sure object was created successfully.
	IF EXISTS (	SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'dbo'
					AND TABLE_NAME = 'IMIS_USER_DETAILS'
					AND TABLE_TYPE = 'BASE TABLE' )


	BEGIN
		PRINT 'Table IMIS_USER_DETAILS created successfully.';	
	END
	ELSE
	BEGIN
		PRINT 'ERROR: Failed to create Table IMIS_USER_DETAILS.';
	END
END
GO




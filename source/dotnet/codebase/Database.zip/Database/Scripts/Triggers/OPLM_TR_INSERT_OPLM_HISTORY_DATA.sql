SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF OBJECT_ID ('OPLM_TR_INSERT_OPLM_HISTORY_DATA','TR') IS NOT NULL
BEGIN   
	PRINT 'Dropping trigger OPLM_TR_INSERT_OPLM_HISTORY_DATA';
	DROP TRIGGER OPLM_TR_INSERT_OPLM_HISTORY_DATA
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Trigger name			: OPLM_TR_INSERT_OPLM_HISTORY_DATA
 * --Purpose/Function		: Gets ContactRole objects by ID
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/19/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/19/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE TRIGGER [OPLM_TR_INSERT_OPLM_HISTORY_DATA]
   ON  [dbo].[OPLM_HISTORY_DATA]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @PreviousDTS DATETIME;
	DECLARE @ProjectID BIGINT;
	DECLARE @DataTypeCode TINYINT;
	DECLARE @DataID BIGINT;
	DECLARE @FieldName VARCHAR(50);
	DECLARE @HistoryID BIGINT;
	DECLARE @UserName VARCHAR(60);
	DECLARE @FirstName VARCHAR(30);
	DECLARE @LastName VARCHAR(20);
	DECLARE @DataName VARCHAR(1000);
	DECLARE @UserID BIGINT;

	SELECT @FirstName = UserFirstName FROM INSERTED;
	SELECT @LastName = UserLastName FROM INSERTED;

	IF @FirstName is NULL OR @FirstName = ''
	BEGIN
		IF (SELECT UserName FROM INSERTED) = 'imis_refresh'
		BEGIN
			SET @UserID = -1;
			SET @FirstName = 'iMIS';
			SET @LastName = 'Refresh';
		END

		ELSE
--			IF (SELECT DataTypeCode FROM INSERTED) = 11 --Nomination committee data
--			BEGIN
--				SELECT @FirstName = FirstName, @LastName = LastName FROM dbo.NOMINATOR_OF_COMMITEE_NOMINATION
--					WHERE dbo.NOMINATOR_OF_COMMITEE_NOMINATION.NomineeID = (SELECT NomineeID FROM dbo.NOMINEE_COMMITTEE WHERE NomineeCommitteeID = (SELECT DataID FROM INSERTED)) 
--			END
--			ELSE
			BEGIN
				BEGIN
					SELECT @UserID = UserID, @FirstName = FirstName, @LastName = LastName FROM dbo.OPLM_USER
					WHERE dbo.OPLM_USER.UserName = (SELECT UserName FROM INSERTED)
				END
			END
		END

	SELECT @ProjectID = ProjectID, @DataTypeCode = DataTypeCode, @DataID = DataID, @FieldName = FieldName, @HistoryID = HistoryID
	FROM INSERTED;

	SET @PreviousDTS = (SELECT TOP 1 DTS FROM OPLM_HISTORY_DATA WHERE ProjectID=@ProjectID and DataTypeCode=@DataTypeCode and DataID=@DataID
	and FieldName=@FieldName AND @HistoryID <> HistoryID ORDER BY DTS DESC);

	IF @PreviousDTS is null
	BEGIN
	   SELECT @PreviousDTS = DTS FROM OPLM_PROJECT_MASTER WHERE ProjectID = @ProjectID;
	END
	IF @PreviousDTS is null
	BEGIN
	   SELECT @PreviousDTS = DTS FROM OPLM_HISTORY_DATA WHERE HistoryID = @HistoryID;
	END

	UPDATE dbo.OPLM_HISTORY_DATA 
	SET PreviousDTS = @PreviousDTS,
	--UserId = @UserId,
	UserFirstName = @FirstName,
	UserLastName = @LastName
	WHERE HistoryID = @HistoryID;

	IF (SELECT DataTypeCode FROM INSERTED) = 3
	BEGIN
		DECLARE @StaffName VARCHAR(1000);
		DECLARE @StaffUserID BIGINT;
		SELECT @StaffUserID = UserID FROM dbo.OPLM_PROJECT_STAFF_MEMBER WHERE StaffMemberID = (SELECT DataID FROM INSERTED);
		SELECT @StaffName = (SELECT FirstName + ' ' + LastName FROM dbo.OPLM_USER WHERE dbo.OPLM_USER.UserID = @StaffUserID)
		
		UPDATE dbo.OPLM_HISTORY_DATA 
		SET DataName = @StaffName
	
		WHERE HistoryID = @HistoryID;
	END

	IF (SELECT DataTypeCode FROM INSERTED) = 8 --Nominee data
	BEGIN
		DECLARE @ProjectIDForNominationCommittee BIGINT,@ProjectStepIDForNominationPeriod BIGINT;
		DECLARE @CommitteeID BIGINT, @CommitteeName VARCHAR(1000);
		DECLARE @NomineeName VARCHAR(100);

		SELECT  @CommitteeID = NOMINEE_COMMITTEE.CommitteeID FROM NOMINEE_COMMITTEE WHERE NOMINEE_COMMITTEE.NomineeID = (SELECT DataID FROM INSERTED)
		SELECT @ProjectStepIDForNominationPeriod = ProjectStepIDForNominationPeriod,@ProjectIDForNominationCommittee = ProjectID,@CommitteeName = CommitteeName FROM COMMITTEE WHERE COMMITTEE.CommitteeID = @CommitteeID
		SELECT @NomineeName = FirstName + ' ' + LastName FROM dbo.NOMINEE_OF_COMMITTEE WHERE NomineeID = (SELECT DataID FROM INSERTED)
		DECLARE @ModifiedDataTypeName VARCHAR(1000);
		SELECT @ModifiedDataTypeName = ProjectStepName FROM OPUS_PROJECT_STEPS WHERE ProjectStepID = @ProjectStepIDForNominationPeriod;
		if @ModifiedDataTypeName is null 
			SET @ModifiedDataTypeName = '';
		else
			SET @ModifiedDataTypeName = (SELECT DataTypeName FROM INSERTED) + ' ('+ @ModifiedDataTypeName +')';
				
		UPDATE dbo.OPLM_HISTORY_DATA 
		SET ProjectID = @ProjectIDForNominationCommittee,
		DataTypeName = @ModifiedDataTypeName,
		DataName = @NomineeName
		WHERE HistoryID = @HistoryID;

	END

	IF (SELECT DataTypeCode FROM INSERTED) = 11 --Nomination committee data
	BEGIN
		SELECT  @CommitteeID = NOMINEE_COMMITTEE.CommitteeID FROM NOMINEE_COMMITTEE WHERE NOMINEE_COMMITTEE.NomineeCommitteeID = (SELECT DataID FROM INSERTED)
		
		SELECT @CommitteeName = CommitteeName,@ProjectStepIDForNominationPeriod = ProjectStepIDForNominationPeriod,@ProjectIDForNominationCommittee = ProjectID FROM COMMITTEE WHERE COMMITTEE.CommitteeID = @CommitteeID
		SELECT @NomineeName = FirstName + ' ' + LastName FROM dbo.NOMINEE_OF_COMMITTEE WHERE NomineeID = (SELECT NomineeID FROM INSERTED)
		SELECT @ModifiedDataTypeName = ProjectStepName FROM OPUS_PROJECT_STEPS WHERE ProjectStepID = @ProjectStepIDForNominationPeriod;
		if @ModifiedDataTypeName is null 
			SET @ModifiedDataTypeName = '';
		else
			SET @ModifiedDataTypeName = (SELECT DataTypeName FROM INSERTED) + ' ('+ @ModifiedDataTypeName +')';
		
		UPDATE dbo.OPLM_HISTORY_DATA 
		SET ProjectID = @ProjectIDForNominationCommittee,
		DataTypeName = @ModifiedDataTypeName,
		DataName = @NomineeName + ' (' + @CommitteeName +')'
		WHERE HistoryID = @HistoryID;

	END
	-- Insert statements for trigger here
	IF (SELECT DataTypeCode FROM INSERTED) = 9
	BEGIN	
		UPDATE dbo.OPLM_HISTORY_DATA 
		SET FieldName = 'Nomination Period Name'
		WHERE DataTypeCode = 9 AND FieldName = 'Web Title';
	END

	IF (SELECT DataTypeCode FROM INSERTED) = 13
	BEGIN	
		UPDATE dbo.OPLM_HISTORY_DATA 
		SET FieldName = 'Measure Submission Period Name'
		WHERE DataTypeCode = 13 AND FieldName = 'Web Title';
	END

END
GO
-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF OBJECT_ID ('OPLM_TR_INSERT_OPLM_HISTORY_DATA','TR') IS NOT NULL
BEGIN
	PRINT 'Trigger OPLM_TR_INSERT_OPLM_HISTORY_DATA created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create Trigger OPLM_TR_INSERT_OPLM_HISTORY_DATA.';
END

GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE.';
	DROP PROCEDURE GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_XML_DATA
 * --Purpose/Function		: Retrieves comments by Project ID and StandardID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 02/16/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 02/16/09		MR	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--exec GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE 105
--select * from msf_Submissions
CREATE PROCEDURE [dbo].[GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE] 
(
	@CurrentMeasureStatus INT,
	@ProjectTypeStepID BIGINT
)	
AS
BEGIN

	SELECT 
		ID	
	FROM 
		OPUS_PROJECT_STEPS AS OPS
		INNER JOIN MSF_SUBMISSIONS AS MS ON OPS.ProjectID = MS.ProjectID
	WHERE 
		OPS.ProjectTypeStepID = @ProjectTypeStepID
		AND OPS.StartDate <= GETDATE()
		AND OPS.EndDate >= GETDATE() 
		AND MS.StatusSubmitted = @CurrentMeasureStatus;
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_ELIGIBLE_MEASURES_FOR_AUTO_STATUS_UPDATE.';
END
GO




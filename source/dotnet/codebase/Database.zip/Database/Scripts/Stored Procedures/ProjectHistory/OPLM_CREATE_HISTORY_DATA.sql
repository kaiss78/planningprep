SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_CREATE_HISTORY_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_CREATE_HISTORY_DATA.';
	DROP PROCEDURE OPLM_CREATE_HISTORY_DATA;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_CREATE_HISTORY_DATA
 * --Purpose/Function		: Saves a HistoryData object
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/18/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/18/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_CREATE_HISTORY_DATA](
	  @ProjectID BIGINT
	, @DataTypeName VARCHAR(1000)
	, @DataTypeCode TINYINT
	, @FieldName VARCHAR(1000)
	, @SQLFieldTypeCode TINYINT
	, @BeforeValue SQL_VARIANT
	, @AfterValue SQL_VARIANT
	, @UserID BIGINT
	, @UserName VARCHAR(60)
	, @UserFirstName VARCHAR(30)
	, @UserLastName VARCHAR(20)
	, @DataID BIGINT
	, @DataName VARCHAR(1000)
	, @ReasonForChange VARCHAR(1000)
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	BEGIN
		-- New Record, insert it into the dbo.OPLM_HISTORY_DATA
		INSERT INTO dbo.OPLM_HISTORY_DATA (ProjectID
			, DataTypeName
			, DataTypeCode
			, FieldName
			, SQLFieldTypeCode
			, BeforeValue
			, AfterValue
			, UserID
			, UserName
			, UserFirstName
			, UserLastName
			, DataID
			, DataName
			, DTS
			, ReasonForChange
			)
		VALUES(@ProjectID
			, @DataTypeName
			, @DataTypeCode
			, @FieldName
			, @SQLFieldTypeCode
			, @BeforeValue
			, @AfterValue
			, @UserID
			, @UserName
			, @UserFirstName
			, @UserLastName
			, @DataID
			, @DataName
			, GETDATE()
			, @ReasonForChange
			);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_CREATE_HISTORY_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_CREATE_HISTORY_DATA created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_CREATE_HISTORY_DATA.';
END
GO
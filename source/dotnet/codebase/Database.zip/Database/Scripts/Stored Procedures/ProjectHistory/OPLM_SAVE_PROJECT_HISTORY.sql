SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_HISTORY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_PROJECT_HISTORY.';
	DROP PROCEDURE OPLM_SAVE_PROJECT_HISTORY;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_PROJECT_HISTORY
 * --Purpose/Function		: Saves History data for Project object
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/12/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_SAVE_PROJECT_HISTORY](
	  @ProjectID BIGINT
	, @UserName VARCHAR(60)
	, @ModifiedStartDate DATETIME
	, @ModifiedEndDate DATETIME
	, @ModifiedStatus VARCHAR(1000)
)
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @CurrentVersionNumber BIGINT;
		DECLARE @CurrentStartDate DATETIME;
		DECLARE @CurrentEndDate DATETIME;
		DECLARE @CurrentStatus VARCHAR(1000);
		DECLARE @UserID BIGINT;
		DECLARE @FirstName VARCHAR(30);
		DECLARE @LastName VARCHAR(20);
		DECLARE @ProjectName VARCHAR(255);
		DECLARE @DTS DATETIME;

		SELECT @UserID = UserID, @FirstName = FirstName, @LastName = LastName FROM dbo.OPLM_USER
		WHERE UserName = @UserName

		SELECT @ProjectName = ShortName FROM dbo.OPLM_PROJECT_PRIMARY_DATA
		WHERE ProjectID = @ProjectID

		SELECT @CurrentStartDate = StartDate, @CurrentEndDate = EndDate FROM dbo.OPLM_PROJECT_PRIMARY_DATA
		WHERE ProjectID = @ProjectID

		SELECT @CurrentStatus = ProjectStatus FROM dbo.OPLM_PROJECT_SECONDARY_DATA
		WHERE ProjectID = @ProjectID

		SET @DTS = GETDATE();

		--Do not store history data if the three project field is not changed
		UPDATE 	dbo.OPLM_PROJECT_MASTER	
			SET DTS = getdate(),
			UpdatedBy = @UserName
			WHERE ProjectID = @ProjectID;

		IF @CurrentStatus = @ModifiedStatus AND
		   @CurrentStartDate = @ModifiedStartDate AND
		   @CurrentEndDate = @ModifiedEndDate
		
		   RETURN

		--Save changed data for StartDate in the history table
		IF @CurrentStartDate <> @ModifiedStartDate
		BEGIN
			
			INSERT INTO dbo.OPLM_HISTORY_DATA (
				  ProjectID
				, DataTypeName
				, DataTypeCode
				, FieldName
				, SQLFieldTypeCode
				, BeforeValue
				, AfterValue
				, UserID
				, UserName
				, UserFirstName
				, UserLastName
				, DataID
				, DataName
				, DTS)
			VALUES(
				  @ProjectID
				,  'Project'
				, 1
				, 'Start Date'
				, 4
				, @CurrentStartDate
				, @ModifiedStartDate
				, @UserID
				, @UserName
				, @FirstName
				, @LastName
				, @ProjectID
				, @ProjectName
				, @DTS);
		END

		--Save changed data for EndDate in the history table
		IF @CurrentEndDate <> @ModifiedEndDate
		BEGIN
			
			INSERT INTO dbo.OPLM_HISTORY_DATA (
				  ProjectID
				, DataTypeName
				, DataTypeCode
				, FieldName
				, SQLFieldTypeCode
				, BeforeValue
				, AfterValue
				, UserID
				, UserName
				, UserFirstName
				, UserLastName
				, DataID
				, DataName
				, DTS)
			VALUES(
				  @ProjectID
				, 'Project'
				, 1
				, 'End Date'
				, 4
				, @CurrentEndDate
				, @ModifiedEndDate
				, @UserID
				, @UserName
				, @FirstName
				, @LastName
				, @ProjectID
				, @ProjectName
				, @DTS);
		END

		--Save changed data for Status in the history table
		IF @CurrentStatus <> @ModifiedStatus
		BEGIN
			
			INSERT INTO dbo.OPLM_HISTORY_DATA (
				  ProjectID
				, DataTypeName
				, DataTypeCode
				, FieldName
				, SQLFieldTypeCode
				, BeforeValue
				, AfterValue
				, UserID
				, UserName
				, UserFirstName
				, UserLastName
				, DataID
				, DataName
				, DTS)
			VALUES(
				  @ProjectID
				, 'Project'
				, 1
				, 'Status'
				, 3
				, @CurrentStatus
				, @ModifiedStatus
				, @UserID
				, @UserName
				, @FirstName
				, @LastName
				, @ProjectID
				, @ProjectName
				, @DTS);
		END	


END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_HISTORY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_PROJECT_HISTORY created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_PROJECT_HISTORY.';
END
GO
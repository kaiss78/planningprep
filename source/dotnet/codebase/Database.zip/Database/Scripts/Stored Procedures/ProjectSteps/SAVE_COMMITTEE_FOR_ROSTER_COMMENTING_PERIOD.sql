SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD.';
	DROP PROCEDURE SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD
 * --Purpose/Function		: Saves committees for commenting period
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/17/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/17/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD
  @CommiteeIDList VARCHAR(500),
  @CommentingPeriodID BIGINT
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
		UPDATE dbo.COMMITTEE
	SET ProjectStepIDForCommenting = NULL
	WHERE ProjectStepIDForCommenting = @CommentingPeriodID

	IF @CommiteeIDList <>''
	BEGIN
	UPDATE dbo.COMMITTEE
	SET ProjectStepIDForCommenting = @CommentingPeriodID
	WHERE CommitteeID in (Select id from dbo.SplitId(@CommiteeIDList,','))
	END
		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION				
			END
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_COMMITTEE_FOR_ROSTER_COMMENTING_PERIOD.';
END
GO

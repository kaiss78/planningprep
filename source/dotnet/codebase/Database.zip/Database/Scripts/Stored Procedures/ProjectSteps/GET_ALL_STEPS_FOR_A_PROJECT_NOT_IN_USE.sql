SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_STEPS_FOR_A_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_ALL_STEPS_FOR_A_PROJECT.';
	DROP PROCEDURE GET_ALL_STEPS_FOR_A_PROJECT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: GET_ALL_STEPS_FOR_A_PROJECT
 * --Purpose/Function		: Gets the detail of a project step
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_ALL_STEPS_FOR_A_PROJECT]
 @ProjectID bigint
AS
BEGIN
	BEGIN TRY
		SELECT 
			  ps.[ProjectStepID]
			  ,ps.[ProjectStepName]
			  ,ps.[ParentProjectStepID]
			  ,ps.[stepID]
			  ,ps.[ProjectID]
			  ,pss.[ProjectSetupID]      
			  ,pss.[WebTitle]
			  ,pss.[StartDate]
			  ,pss.[EndDate]
			  ,pss.[BeforePeriodDescription]
			  ,pss.[DuringPeriodDescription]
			  ,pss.[AfterPeriodDescription]
			  ,pss.[Background]
			  ,pss.[ScopeOfActivities]
			  ,pss.[NQFProcess]
			  ,pss.[Instructions]
			  ,pss.[Remarks]
			  ,pss.[UpdatedBy]
			  ,pss.[DTS]
			  ,pss.[Status]
			  ,pss.[DetailPageURL]
		  FROM 
			  [PROJECT_STEPS] ps
		  INNER JOIN
			  [PROJECT_STEP_SETUP] pss
		  ON
				ps.ProjectStepID = pss.ProjectStepID
		  WHERE
				ps.ProjectID = @ProjectID

	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_STEPS_FOR_A_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_ALL_STEPS_FOR_A_PROJECT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_ALL_STEPS_FOR_A_PROJECT.';
END
GO

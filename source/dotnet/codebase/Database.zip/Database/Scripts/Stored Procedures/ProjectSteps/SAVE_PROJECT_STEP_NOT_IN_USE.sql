SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_PROJECT_STEP'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_PROJECT_STEP.';
	DROP PROCEDURE SAVE_PROJECT_STEP;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: SAVE_PROJECT_STEP
 * --Purpose/Function		: Saves project step setup
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_PROJECT_STEP
  @ProjectStepID bigint
, @ProjectStepName varchar(200)
, @ParentProjectStepID bigint
, @StepID bigint
, @ProjectID bigint
, @ProjectTypeID bigint
, @WebTitle varchar(1000)
, @StartDate datetime
, @EndDate datetime
, @BeforePeriodDescription varchar(4000)
, @DuringPeriodDescription varchar(4000)
, @AfterPeriodDescription varchar(4000)
, @Background varchar(4000)
, @ScopeOfActivities varchar(4000)
, @NQFProcess varchar(4000)
, @Instructions varchar(4000)
, @Remarks varchar(4000)
, @UpdatedBy varchar(60)
, @Status int
, @DetailPageURL varchar(2000) = ''
, @ChildStepCode int
, @GeneratedID bigint OUTPUT
AS
BEGIN
	BEGIN TRY
		
		IF @ProjectStepName = ''
		BEGIN
			SET @ProjectStepName = (SELECT StepName FROM STEPS WHERE StepID = @StepID AND ProjectTypeID = @ProjectTypeID)
		END

--		DECLARE @ProjectStepID bigint
--		SET @ProjectStepID = 0
		BEGIN TRANSACTION

		IF EXISTS(SELECT ProjectSetupID FROM PROJECT_STEP_SETUP WHERE ProjectStepID = @ProjectStepID)
		BEGIN			
			--UPDATE
			--SET @ProjectStepID = (SELECT ProjectStepID FROM PROJECT_STEP_SETUP WHERE ProjectSetupID = @ProjectSetupID)
			
			UPDATE PROJECT_STEPS SET ProjectStepName = @ProjectStepName WHERE ProjectStepID = @ProjectStepID

			UPDATE 
				PROJECT_STEP_SETUP
			SET
				WebTitle = @WebTitle
			    ,StartDate = @StartDate
				,EndDate = @EndDate
				,BeforePeriodDescription = @BeforePeriodDescription
				,DuringPeriodDescription = @DuringPeriodDescription
				,AfterPeriodDescription = @AfterPeriodDescription
				,Background = @Background
				,ScopeOfActivities = @ScopeOfActivities
				,NQFProcess = @NQFProcess
				,Instructions = @Instructions
				,Remarks = @Remarks
				,UpdatedBy = @UpdatedBy
				,DTS = getdate()
				,Status = @Status
				,[DetailPageURL] = @DetailPageURL				
			WHERE
				ProjectStepID = @ProjectStepID 
		END
		ELSE
		BEGIN
			--INSERT to table PROJECT_STEPS
			INSERT INTO PROJECT_STEPS
				   (ProjectStepName
				   ,ParentProjectStepID
				   ,stepID
				   ,ProjectID
				   ,ChildStepCode)				  
			 VALUES
				   (@ProjectStepName
				   ,@ParentProjectStepID
				   ,@StepID
				   ,@ProjectID
				   ,@ChildStepCode)
			
			SET @ProjectStepID = SCOPE_IDENTITY()

			--INSERT to table PROJECT_STEP_SETUP
			INSERT INTO 
				PROJECT_STEP_SETUP			
			   ([ProjectStepID]
			   ,[WebTitle]
			   ,[StartDate]
			   ,[EndDate]
			   ,[BeforePeriodDescription]
			   ,[DuringPeriodDescription]
			   ,[AfterPeriodDescription]
			   ,[Background]
			   ,[ScopeOfActivities]
			   ,[NQFProcess]
			   ,[Instructions]
			   ,[Remarks]
			   ,[UpdatedBy]
			   ,[DTS]
			   ,[Status]
			   ,[DetailPageURL])
			VALUES
				(
				@ProjectStepID
				,@WebTitle
				,@StartDate
				,@EndDate
				,@BeforePeriodDescription
				,@DuringPeriodDescription
				,@AfterPeriodDescription
				,@Background
				,@ScopeOfActivities
				,@NQFProcess
				,@Instructions
				,@Remarks
				,@UpdatedBy
				,getdate()
				,@Status
				,@DetailPageURL	
				)

		END

		SET @GeneratedID = @ProjectStepID;

		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION				
			END
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_PROJECT_STEP'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_PROJECT_STEP created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_PROJECT_STEP.';
END
GO

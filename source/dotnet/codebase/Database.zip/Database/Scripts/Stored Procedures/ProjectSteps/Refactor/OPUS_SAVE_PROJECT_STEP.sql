SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPUS_SAVE_PROJECT_STEP'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPUS_SAVE_PROJECT_STEP.';
	DROP PROCEDURE OPUS_SAVE_PROJECT_STEP;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: OPUS_SAVE_PROJECT_STEP
 * --Purpose/Function		: Saves project step setup
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 12/18/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/18/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPUS_SAVE_PROJECT_STEP
  @ProjectStepID bigint
, @ProjectTypeStepID bigint
, @ProjectParentStepID bigint
, @ProjectStepName varchar(200)
, @StartDate datetime
, @EndDate datetime
, @BeforePeriodDescription varchar(8000)
, @DuringPeriodDescription varchar(8000)
, @AfterPeriodDescription varchar(8000)
, @WebTitle varchar(8000)
, @ProjectID bigint
, @GeneratedID bigint OUTPUT
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
		IF @ProjectStepID = 0 -- Create
		BEGIN
			INSERT INTO OPUS_PROJECT_STEPS
				(
				[ProjectTypeStepID]
			   ,[ProjectParentStepID]
			   ,[ProjectStepName]
			   ,[StartDate]
			   ,[EndDate]
			   ,[BeforePeriodDescription]
			   ,[DuringPeriodDescription]
			   ,[AfterPeriodDescription]
			   ,[WebTitle]
			   ,[ProjectID])
			VALUES
			   (
				@ProjectTypeStepID
				,@ProjectParentStepID
				,@ProjectStepName
				,@StartDate
				,@EndDate
				,@BeforePeriodDescription
				,@DuringPeriodDescription
				,@AfterPeriodDescription
				,@WebTitle
				,@ProjectID				
				)
			SET @ProjectStepID = SCOPE_IDENTITY()
		END
		ELSE -- Update
		BEGIN
			UPDATE OPUS_PROJECT_STEPS
			SET 				
			  [ProjectTypeStepID] = @ProjectTypeStepID
			  ,[ProjectParentStepID] = @ProjectParentStepID
			  ,[ProjectStepName] = @ProjectStepName
			  ,[StartDate] = @StartDate
			  ,[EndDate] = @EndDate
			  ,[BeforePeriodDescription] = @BeforePeriodDescription
			  ,[DuringPeriodDescription] = @DuringPeriodDescription
			  ,[AfterPeriodDescription] = @AfterPeriodDescription
			  ,[WebTitle] = @WebTitle
			  ,[ProjectID] = @ProjectID
		 WHERE [ProjectStepID] = @ProjectStepID
		END
		SET @GeneratedID = @ProjectStepID
		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION				
			END
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPUS_SAVE_PROJECT_STEP'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPUS_SAVE_PROJECT_STEP created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPUS_SAVE_PROJECT_STEP.';
END
GO

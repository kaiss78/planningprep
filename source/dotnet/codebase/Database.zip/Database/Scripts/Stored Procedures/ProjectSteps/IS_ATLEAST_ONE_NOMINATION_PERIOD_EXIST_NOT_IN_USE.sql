SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST.';
	DROP PROCEDURE IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST
 * --Purpose/Function		: Saves project step setup
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST
  @CallForNominationID bigint
  ,@retVal bit output
AS
BEGIN
	BEGIN TRY		
		/*** DEV: MHR **** Feedback*/
		-- Check If at Least One Completed Nomination Period is defined
		IF(	(
				--SELECT COUNT(ProjectStepID) FROM PROJECT_STEPS WHERE ParentProjectStepID=@CallForNominationID AND ChildStepCode=1
				SELECT COUNT(PS.ProjectStepID) 
				FROM PROJECT_STEPS PS
				INNER JOIN Project_Step_Setup PSS ON PS.ProjectStepID = PSS.ProjectStepID
				WHERE PS.ParentProjectStepID = @CallForNominationID 
				AND PS.ChildStepCode = 1
				AND ISNULL(PSS.WebTitle, '') <> ''
				AND ISNULL(PSS.BeforePeriodDescription, '') <> ''
				AND ISNULL(PSS.DuringPeriodDescription, '') <> ''
				AND ISNULL(PSS.AfterPeriodDescription, '') <> ''  
				AND PSS.StartDate <= GetDate()
				AND PSS.EndDate >= GetDate()
			) > 0)				
		/*** DEV: MHR *** Feedback Ends */
		BEGIN
			SET @retVal = 1
		END
		ELSE
		BEGIN
			SET @retVal = 0
		END
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION				
			END
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IS_ATLEAST_ONE_NOMINATION_PERIOD_EXIST.';
END
GO

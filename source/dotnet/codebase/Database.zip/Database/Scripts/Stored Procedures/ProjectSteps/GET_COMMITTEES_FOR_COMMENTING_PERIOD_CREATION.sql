SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION.';
	DROP PROCEDURE GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION
 * --Purpose/Function		: Gets the committe list for roster commenting period creation
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/17/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/17/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION
 @ProjectID bigint
AS
BEGIN
	BEGIN TRY
		SELECT 
			COMMITTEE.CommitteeID
			,CommitteeName
			,ProjectStepIDForCommenting
			,ProjectStepIDForNominationPeriod 
			,CommitteeType
		FROM 
			COMMITTEE
		INNER JOIN
			 COMMITTEE_TYPE
		ON
			COMMITTEE.CommitteeTypeID  = COMMITTEE_TYPE.CommitteeTypeID 
		INNER JOIN
			COMMITTEES_WITH_MEETING_DATES
		ON
			COMMITTEES_WITH_MEETING_DATES.CommitteeID = COMMITTEE.CommitteeID
		WHERE 
			ProjectID = @ProjectID 
			AND ISNULL(ProjectStepIDForNominationPeriod,0)<>0
			AND COMMITTEE.IsActive = 1
--			AND COMMITTEE.MeetingStartDate IS NOT NULL
--			AND COMMITTEE.MeetingEndDate IS NOT NULL
			AND COMMITTEE.Background IS NOT NULL
			AND COMMITTEE.CommitteeTypeID IS NOT NULL
			AND COMMITTEE.CommitteeName IS NOT NULL
			AND COMMITTEE.iMISCODE IS NOT NULL			

	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION				
			END
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMITTEES_FOR_COMMENTING_PERIOD_CREATION.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT.';
	DROP PROCEDURE GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT
 * --Purpose/Function		: Gets the latest end date of a step for a project
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/22/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT 
@PerentStepID bigint
,@ChildStepCode int
AS
BEGIN
	BEGIN TRY

		SELECT 
			MAX(pss.EndDate) as EndDate
		FROM 
			PROJECT_STEP_SETUP pss
		INNER JOIN
			PROJECT_STEPS ps
		ON
			pss.ProjectStepID = ps.ProjectStepID
		WHERE
			ps.ParentProjectStepID = @PerentStepID	
			AND ps.ChildStepCode = 	@ChildStepCode			
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION				
			END
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_LATEST_END_DATE_OF_A_STEP_FOR_A_PROJECT.';
END
GO

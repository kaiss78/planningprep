SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_HOLIDAY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IS_HOLIDAY.';
	DROP PROCEDURE IS_HOLIDAY;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: IS_HOLIDAY
 * --Purpose/Function		: Returns if the given date is a US holiday
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/17/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/17/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.IS_HOLIDAY
 -- Add the parameters for the stored procedure here
	@datetimeExamined DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @isHoliday bit;		

	SET @isHoliday = 0;
	
	IF EXISTS(select HolidayID from dbo.US_HOLIDAYS where CONVERT(VARCHAR(10), HolidayDate , 110) = @datetimeExamined AND isApplicable = 1)
	BEGIN
		SET	@isHoliday = 1;	
	END
	 
	if (@isHoliday <> 1)
	BEGIN
		SELECT @isHoliday =1 WHERE DATENAME(dw,@datetimeExamined) in ('Saturday','Sunday')
	END
	--the value will be 1 if the date examined is holiday, 0 if not
	SELECT @isHoliday AS IsHoliday;
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_HOLIDAY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IS_HOLIDAY created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IS_HOLIDAY.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'UPDATE_MEASURE_STATUS_TO_COMMENTING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure UPDATE_MEASURE_STATUS_TO_COMMENTING.';
	DROP PROCEDURE UPDATE_MEASURE_STATUS_TO_COMMENTING;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: UPDATE_MEASURE_STATUS_TO_COMMENTING
 * --Purpose/Function		: Update mesure status from recommended to commenting
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 02/15/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/15/2010		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.UPDATE_MEASURE_STATUS_TO_COMMENTING
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	DECLARE @PROJECT_ID 									BIGINT
	DECLARE @MEASURE_ID 									BIGINT
	DECLARE @MEASURE_TITLE 									VARCHAR (500)
	DECLARE @HITORY_DATA_TYPE_NAME							VARCHAR (500)
	DECLARE @STATUS_CHANGE_ID 								BIGINT
	DECLARE @HISTORY_ID	 									BIGINT
	DECLARE @NOTE_ID	 									BIGINT
	DECLARE @NOTE_TYPE_ID 									BIGINT
	DECLARE @RECOMENDED_MEASURE_STATUS 						INT
	DECLARE @PUBLIC_AND_MEMBER_COMMENTING_MEASURE_STATUS 	INT
	DECLARE @MEASURE_COMMENTING_PERIOD_STEP_ID 				BIGINT

	SET  @NOTE_TYPE_ID = 3
	SET  @RECOMENDED_MEASURE_STATUS = 9
	SET  @PUBLIC_AND_MEMBER_COMMENTING_MEASURE_STATUS = 17
	SET  @MEASURE_COMMENTING_PERIOD_STEP_ID = 13	
	
	DECLARE MEASURE_CURSOR CURSOR FOR 
	SELECT [ID], MS.ProjectID, ISNULL(XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'varchar(256)'),'')
	FROM 
		OPUS_PROJECT_STEPS AS OPS
		INNER JOIN MSF_SUBMISSIONS AS MS ON OPS.ProjectID = MS.ProjectID
	WHERE 
		OPS.ProjectTypeStepID = @MEASURE_COMMENTING_PERIOD_STEP_ID
		AND OPS.StartDate <= GETDATE()
		AND OPS.EndDate >= GETDATE() 
		AND MS.StatusSubmitted = @RECOMENDED_MEASURE_STATUS;

	OPEN MEASURE_CURSOR
		
	FETCH NEXT FROM MEASURE_CURSOR INTO @MEASURE_ID, @PROJECT_ID, @MEASURE_TITLE
	WHILE @@FETCH_STATUS = 0
	BEGIN
		--Give entry for status change
		EXEC MSF_SAVE_CHANGE_STATUS 0, @MEASURE_ID, @PUBLIC_AND_MEMBER_COMMENTING_MEASURE_STATUS, NULL, @STATUS_CHANGE_ID OUTPUT; 
		
		--Update measure status
		EXEC NQF_UPDATE_MSF_ITEM_STATUS @MEASURE_ID, @PUBLIC_AND_MEMBER_COMMENTING_MEASURE_STATUS;

		--Add note for status change
		EXEC MSF_ADD_NOTES 'Status Updated By Scheduler', @STATUS_CHANGE_ID, @PUBLIC_AND_MEMBER_COMMENTING_MEASURE_STATUS, 0, @NOTE_TYPE_ID, @NOTE_ID OUTPUT;
		
		--Add to history data
		SET @HITORY_DATA_TYPE_NAME = 'Measure Status (' + @MEASURE_TITLE + ')';
		EXEC OPLM_CREATE_HISTORY_DATA @PROJECT_ID, @HITORY_DATA_TYPE_NAME, 15, 'Status', 3, 'Recommended','Public and Member Commenting', 0, NULL, '', 'System', @MEASURE_ID, @MEASURE_TITLE, NULL, @HISTORY_ID OUTPUT

	FETCH NEXT FROM MEASURE_CURSOR INTO @MEASURE_ID, @PROJECT_ID, @MEASURE_TITLE
	END
	CLOSE MEASURE_CURSOR
	DEALLOCATE MEASURE_CURSOR	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'UPDATE_MEASURE_STATUS_TO_COMMENTING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure UPDATE_MEASURE_STATUS_TO_COMMENTING created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure UPDATE_MEASURE_STATUS_TO_COMMENTING.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID.';
	DROP PROCEDURE GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID
 * --Purpose/Function		: Get Board Voting Results objects
 * --Author					: MZ
 * --Start Date(MM/DD/YY)	: 02/18/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/18/2010		MZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID](
	
	 @MeetingDateID BIGINT
	, @PageNo INT
	, @PageSize INT	
	, @SortField VARCHAR(256)
	, @SortOrder VARCHAR(4)	   
	
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
	DECLARE @SQL VARCHAR(6000);
	DECLARE @StartRecord BIGINT;
	DECLARE @EndRecord BIGINT;
	DECLARE @TablePrefix VARCHAR(6);
	DECLARE @StatusID VARCHAR(10);
	
	SET @StartRecord = (@PageNo - 1) * @PageSize;
	SET @EndRecord = @PageNo * @PageSize;
	
	SET @StatusID='24';
  
	DECLARE @TotalRecordCount BIGINT;
	

   --&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& @NoteType > 0 &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

     IF @SortField ='PROJECT_NAME'
     BEGIN
      SET @SortField = 'PPD.ShortName '+ @SortOrder+' ,MS.ID'
     END
     ELSE IF @SortField = 'MEASURE_ID'
     BEGIN
       SET @SortField = 'MS.ID'
     END
     ELSE IF @SortField = 'MEASURE_TITLE'
     BEGIN
       SET @SortField = 'isnull(XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(2000)''),'''')'
     END
	 ELSE IF @SortField = 'MEASURE_STATUS'
     BEGIN
       SET @SortField = 'GVR.EntryStatus'
     END
    

     SET @SQL = 'DECLARE @TotalRecordCount BIGINT;
				 WITH AllVotedMeasure AS(	
					SELECT  
							GVR.GroupVotingResultID AS GroupVotingResultID,
							PPD.ProjectID,
							PPD.ShortName AS ProjectName,	
							MS.ID AS SubmissionID,
							isnull(XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(2000)''),'''') as SubmissionTitle,  						  
							ROW_NUMBER() OVER(ORDER BY ' + @SortField + ' ' + @SortOrder + ') AS RowNumber,
							(SELECT count(MSI.ID) from MSF_SUBMISSIONS MSI INNER JOIN GROUP_VOTING_RESULT VMDM ON  
								MSI.ID=VMDM.MeasureID where ProjectID=PPD.ProjectID AND VMDM.MeetingDateID='+CONVERT(VARCHAR(MAX), @MeetingDateID)+' 
								) AS ProjectWiseMeasureCount,
							MSS.Submission_Status_Name AS EntryStatus,
							GVR.EntryStatus AS EntryStatusID,
							GVR.GroupID AS GroupID,
							GVR.Ratify AS Ratify,
							GVR.Overturn AS Overturn,
							GVR.Abstain AS Abstain,
							GVR.CSACSecondVote AS CSACSecondVote
					FROM   dbo.MSF_SUBMISSIONS MS
                        INNER JOIN OPLM_PROJECT_PRIMARY_DATA PPD ON MS.ProjectID = PPD.ProjectID
						INNER JOIN GROUP_VOTING_RESULT GVR ON  MS.ID=GVR.MeasureID  
						INNER JOIN MSF_SUBMISSION_STATUS MSS ON GVR.EntryStatus=MSS.Submission_Status_ID
					WHERE GVR.MeetingDateID='+CONVERT(VARCHAR(MAX), @MeetingDateID)



       SET @SQL = 	@SQL + ')
				SELECT 
					GroupVotingResultID,
					ProjectID,
					ProjectName,
					SubmissionID,
                    SubmissionTitle,
					ProjectWiseMeasureCount,
				    ISNULL(@TotalRecordCount, (SELECT COUNT(SubmissionID) FROM AllVotedMeasure)) AS TotalRecord,
					GroupID,
					EntryStatusID,
					EntryStatus,
					Ratify,
					Overturn,
					Abstain,
					CSACSecondVote
				FROM AllVotedMeasure
					WHERE RowNumber > ' + CAST(@StartRecord AS VARCHAR) + '
					AND RowNumber <= ' + CAST(@EndRecord AS VARCHAR);
       --print (@sql)
       EXEC (@SQL);


-- Exec GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID '4','1','10','PROJECT_NAME','ASC'


END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_BOARD_VOTING_RESULT_BY_MEETING_DATE_ID.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'DELETE_GROUP_MEETING_DATES_FOR_MEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure DELETE_GROUP_MEETING_DATES_FOR_MEASURE.';
	DROP PROCEDURE DELETE_GROUP_MEETING_DATES_FOR_MEASURE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: DELETE_GROUP_MEETING_DATES_FOR_MEASURE
 * --Purpose/Function		: Saves a MeetingDatesForMeasure object
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/12/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/12/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--DELETE_GROUP_MEETING_DATES_FOR_MEASURE 252, 52,0
CREATE PROCEDURE dbo.DELETE_GROUP_MEETING_DATES_FOR_MEASURE(
	@MeetingDateID BIGINT
	, @MeasureID BIGINT	
	, @PreviousChangedStatus INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @MsfStatusChangeID BIGINT
	
	
	DELETE FROM GROUP_MEETING_DATES_FOR_MEASURE 
	WHERE MsfStatusChangeID IN ( SELECT TOP 1 MSFSTATUSCHANGEID 
	FROM MSF_STATUS_CHANGE  WHERE MSF_STATUS_CHANGE.MEASUREID = @MeasureID ORDER BY DTS DESC )


	SELECT @PreviousChangedStatus = PreveiousStatus FROM MSF_STATUS_CHANGE 
	WHERE MsfStatusChangeID IN ( SELECT TOP 1 MSFSTATUSCHANGEID 
	FROM MSF_STATUS_CHANGE  WHERE MSF_STATUS_CHANGE.MEASUREID = @MeasureID ORDER BY DTS DESC )

	SELECT @PreviousChangedStatus
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'DELETE_GROUP_MEETING_DATES_FOR_MEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure DELETE_GROUP_MEETING_DATES_FOR_MEASURE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure DELETE_GROUP_MEETING_DATES_FOR_MEASURE.';
END
GO
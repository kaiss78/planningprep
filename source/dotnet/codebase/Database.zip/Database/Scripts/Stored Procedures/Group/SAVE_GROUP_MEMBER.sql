SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_GROUP_MEMBER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_GROUP_MEMBER.';
	DROP PROCEDURE SAVE_GROUP_MEMBER;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_GROUP_MEMBER
 * --Purpose/Function		: Saves group member
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 02/11/2010		MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[SAVE_GROUP_MEMBER] 
	-- Add the parameters for the stored procedure here
@GroupID bigint
,@MemberID bigint
,@TermStart datetime
,@TermEnd datetime
,@IsActive bit
,@IsChair bit
,@IMISUserID varchar(50)
,@FirstName varchar(200)
,@LastName varchar(200)
,@Title varchar(200)
,@Organization varchar(200)
,@City varchar(200)
,@State varchar(200)
,@ReturnID bigint output
AS
BEGIN
	DECLARE @GroupMemberID bigint
	SET @GroupMemberID = 0		
		
	IF @MemberID <> 0
	BEGIN
		UPDATE MEMBER_DETAILS
		SET FirstName = @FirstName
			, LastName = @LastName
			, Title = @Title
			, Organization = @Organization
			, City = @City
			, State = @State
		WHERE MemberID = @MemberID
		PRINT 'Member details updated'
		IF EXISTS(SELECT @GroupMemberID FROM GROUP_MEMBER_DETAILS WHERE GroupID = @GroupID AND MemberID=@MemberID)
		BEGIN
			SET @GroupMemberID = (SELECT GroupMemberID FROM GROUP_MEMBER_DETAILS WHERE GroupID = @GroupID AND MemberID=@MemberID)
			PRINT @GroupMemberID
			UPDATE 	GROUP_MEMBER_DETAILS 
				SET TermStart = @TermStart
				, TermEnd = @TermEnd
				, IsActive = @IsActive
				, IsChair = @IsChair
			WHERE
				GroupMemberID = @GroupMemberID
			PRINT 'Group member details updated'
		END	
		ELSE
		BEGIN
			INSERT INTO GROUP_MEMBER_DETAILS 
				(GroupID,MemberID,TermStart,TermEnd,IsActive,IsChair)
			VALUES(@GroupID,@MemberID,@TermStart,@TermEnd,@IsActive,@IsChair)
			SET @GroupMemberID = SCOPE_IDENTITY()
		END	
	END
	ELSE
	BEGIN -- select * from MEMBER_DETAILS -- select * from GROUP_MEMBER_DETAILS
		INSERT INTO MEMBER_DETAILS 
			(IMISUserID,FirstName, LastName, Title, Organization, City, State)
		VALUES(@IMISUserID,@FirstName,@LastName,@Title,@Organization,@City,@State)
		SET @MemberID = SCOPE_IDENTITY()
		
		INSERT INTO GROUP_MEMBER_DETAILS
			(GroupID,MemberID,TermStart,TermEnd,IsActive,IsChair)
		VALUES(@GroupID,@MemberID,@TermStart,@TermEnd,@IsActive,@IsChair)
		SET @GroupMemberID = SCOPE_IDENTITY()
	END
	UPDATE GROUPS SET LastRefreshedOn = getdate() WHERE GroupID=@GroupID
	SET @ReturnID = @GroupMemberID	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_GROUP_MEMBER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_GROUP_MEMBER created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_GROUP_MEMBER.';
END
GO






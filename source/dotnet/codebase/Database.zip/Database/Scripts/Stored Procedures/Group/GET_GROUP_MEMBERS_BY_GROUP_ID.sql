SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_GROUP_MEMBERS_BY_GROUP_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_GROUP_MEMBERS_BY_GROUP_ID.';
	DROP PROCEDURE GET_GROUP_MEMBERS_BY_GROUP_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_GROUP_MEMBERS_BY_GROUP_ID
 * --Purpose/Function		: Saves a Measure Submission Information
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 02/11/2010		MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--GET_GROUP_MEMBERS_BY_GROUP_ID 1
CREATE PROCEDURE [dbo].[GET_GROUP_MEMBERS_BY_GROUP_ID] 
	-- Add the parameters for the stored procedure here
	@GroupID bigint
	,@OrderBy varchar(50) = 'FirstName'
	,@OrderDirection varchar(10) = 'ASC'
	--@ReturnID bigint output
AS
BEGIN
	SELECT 
		gmd.GroupMemberID
		,gmd.GroupID
		,gmd.MemberID
		,gmd.TermStart
		,gmd.TermEnd
		,gmd.IsActive
		,gmd.IsChair
		,gd.IMISUserID
		,gd.FirstName
		,gd.LastName
		,gd.Title
		,gd.Organization
		,gd.City
		,gd.State
		
	FROM 
		GROUP_MEMBER_DETAILS gmd
	INNER JOIN
		MEMBER_DETAILS gd
	ON
		gmd.MemberID = gd.MemberID
	WHERE 
		gmd.IsActive = 1
		AND gmd.GroupID = @GroupID
	ORDER BY		
		gmd.IsChair DESC,
		CASE WHEN @OrderBy = 'FirstName' AND @OrderDirection='ASC' THEN gd.FirstName END ASC,
		CASE WHEN @OrderBy = 'FirstName' AND @OrderDirection='DESC' THEN gd.FirstName END DESC,
		CASE WHEN @OrderBy = 'LastName' AND @OrderDirection='ASC' THEN gd.LastName END ASC,
		CASE WHEN @OrderBy = 'LastName' AND @OrderDirection='DESC'THEN gd.LastName END DESC,
		CASE WHEN @OrderBy = 'Organization' AND @OrderDirection='ASC' THEN gd.Organization END ASC,
		CASE WHEN @OrderBy = 'Organization' AND @OrderDirection='DESC' THEN gd.Organization END DESC
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_GROUP_MEMBERS_BY_GROUP_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_GROUP_MEMBERS_BY_GROUP_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_GROUP_MEMBERS_BY_GROUP_ID.';
END
GO






SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT.';
	DROP PROCEDURE GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT
 * --Purpose/Function		: GET VOTING PERTICIPANT INFORMATION FOR AGENDA DRAFT
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 02/17/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/17/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT
	@MeetingDateID bigint = 4
AS
BEGIN

-- Get Voting Perticipant Info
SELECT
	elgu.COUNCIL AS COUNCIL_NAME,
	(Select Count(vrui.UserInfoID) From VOTING_RESULTS vr,VOTING_RESULTS_USER_INFO vrui,
		VW_MEETING_DATES_WITH_MEASURES mdate
		Where vr.VoteUserInfoID=vrui.UserInfoID 
		AND elgu.COUNCIL=vrui.Council 		
		AND mdate.MeasureID = vr.MeasureID
		AND mdate.MeetingDateID = @MeetingDateID
		) AS VOTING,
	Count(IMISUserID) AS ELIGIBLETOVOTE
 
FROM IMIS_ELIGIBLE_VOTERS elgu 
WHERE elgu.COUNCIL IS NOT NULL
GROUP BY COUNCIL
ORDER BY COUNCIL_NAME 


END

GO


-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_VOTING_PERTICIPANT_FOR_AGENDA_DRAFT.';
END
GO

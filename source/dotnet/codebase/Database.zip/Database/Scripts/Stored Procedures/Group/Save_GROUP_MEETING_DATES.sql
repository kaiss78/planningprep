SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Save_GROUP_MEETING_DATES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure Save_GROUP_MEETING_DATES.';
	DROP PROCEDURE Save_GROUP_MEETING_DATES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: Save_GROUP_MEETING_DATES
 * --Purpose/Function		: Saves a MeetingDates object
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/11/2010		SR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.Save_GROUP_MEETING_DATES(
	@MeetingDateID BIGINT
	, @GroupID BIGINT
	, @MeetingTypeID TINYINT
	, @MeetingStartDateTime DATETIME
	, @MeetingEndDateTime DATETIME
	, @MeetingVenue VARCHAR(250)
	, @MeetingStreet VARCHAR(100)
	, @MeetingCity VARCHAR(50)
	, @MeetingZip VARCHAR(20)
	, @MeetingState VARCHAR(50)
	, @MeetingDialInNumber VARCHAR(50)
	, @AgendaDocumentID BIGINT
	, @MeetingStatusID TINYINT
	, @SummaryDocumentID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	IF @AgendaDocumentID = 0
		SET @AgendaDocumentID = null;

	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.GROUP_MEETING_DATES WHERE MeetingDateID = @MeetingDateID)
	BEGIN
		-- Update Existing MeetingDates Information
		UPDATE dbo.GROUP_MEETING_DATES SET
			GroupID = @GroupID
			, MeetingTypeID = @MeetingTypeID
			, MeetingStartDateTime = @MeetingStartDateTime
			, MeetingEndDateTime = @MeetingEndDateTime
			, MeetingVenue = @MeetingVenue
			, MeetingStreet = @MeetingStreet
			, MeetingCity = @MeetingCity
			, MeetingZip = @MeetingZip
			, MeetingState = @MeetingState
			, MeetingDialInNumber = @MeetingDialInNumber
			, AgendaDocumentID = @AgendaDocumentID
			, MeetingStatusID = @MeetingStatusID
			, SummaryDocumentID = @SummaryDocumentID
		WHERE MeetingDateID = @MeetingDateID
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.GROUP_MEETING_DATES
		INSERT INTO dbo.GROUP_MEETING_DATES (GroupID
			, MeetingTypeID
			, MeetingStartDateTime
			, MeetingEndDateTime
			, MeetingVenue
			, MeetingStreet
			, MeetingCity
			, MeetingZip
			, MeetingState
			, MeetingDialInNumber
			, AgendaDocumentID
			, MeetingStatusID
			, SummaryDocumentID)
		VALUES(@GroupID
			, @MeetingTypeID
			, @MeetingStartDateTime
			, @MeetingEndDateTime
			, @MeetingVenue
			, @MeetingStreet
			, @MeetingCity
			, @MeetingZip
			, @MeetingState
			, @MeetingDialInNumber
			, @AgendaDocumentID
			, @MeetingStatusID
			, @SummaryDocumentID);
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Save_GROUP_MEETING_DATES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure Save_GROUP_MEETING_DATES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure Save_GROUP_MEETING_DATES.';
END
GO

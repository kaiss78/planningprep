SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURE_MEETING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_MEASURE_MEETING.';
	DROP PROCEDURE GET_MEASURE_MEETING;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_MEASURE_MEETING
 * --Purpose/Function		: Gets current meeting of the measure
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 02/25/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/25/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_MEASURE_MEETING
	@MeasureID bigint
AS
BEGIN
	SELECT 
		GMD.MeetingDateID
		, GMD.GroupID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingVenue
		, GMD.MeetingStreet
		, GMD.MeetingCity
		, GMD.MeetingZip
		, GMD.MeetingState
		, GMD.MeetingDialInNumber
		, GMD.AgendaDocumentID
		, GMD.SummaryDocumentID
		, GMD.MeetingStatusID
		, ST.MeetingStatusName
		, MT.MeetingTypeName
	FROM 
		MSF_SUBMISSIONS AS MS
		INNER JOIN 
			VW_MEETING_DATES_WITH_MEASURES AS MDM ON MS.ID = MDM.MeasureID
		INNER JOIN
			GROUP_MEETING_DATES AS GMD ON MDM.MeetingDateID = GMD.MeetingDateID
		INNER JOIN 
			MEETING_TYPE AS MT ON GMD.MeetingTypeID = MT.MeetingTypeID
		INNER JOIN 
			MEETING_STATUS AS ST ON ST.MeetingStatusID=GMD.MeetingStatusID
	WHERE 		
		MS.ID = @MeasureID		
	ORDER BY	
		GMD.MeetingEndDateTime	DESC
		
END

GO

-- EXEC GET_MEASURE_MEETING
-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURE_MEETING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_MEASURE_MEETING created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_MEASURE_MEETING.';
END
GO


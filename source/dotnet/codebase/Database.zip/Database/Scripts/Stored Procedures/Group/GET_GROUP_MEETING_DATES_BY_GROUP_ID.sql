SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_GROUP_MEETING_DATES_BY_GROUP_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_GROUP_MEETING_DATES_BY_GROUP_ID.';
	DROP PROCEDURE GET_GROUP_MEETING_DATES_BY_GROUP_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_GROUP_MEETING_DATES_BY_GROUP_ID
 * --Purpose/Function		: Get MeetingDates objects
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/11/2010		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_GROUP_MEETING_DATES_BY_GROUP_ID(
	@GroupID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	--Select Current Meetings
	SELECT GMD.MeetingDateID
		, GMD.GroupID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingVenue
		, GMD.MeetingStreet
		, GMD.MeetingCity
		, GMD.MeetingZip
		, GMD.MeetingState
		, GMD.MeetingDialInNumber
		, GMD.AgendaDocumentID
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, MS.MeetingStatusName
		, (SELECT COUNT(MeasureID) FROM VW_MEETING_DATES_WITH_MEASURES MDM WHERE MDM.MeetingDateID = GMD.MeetingDateID) AS MeasureCount
	FROM 
		dbo.GROUP_MEETING_DATES GMD
	INNER JOIN 
		MEETING_TYPE MT ON MT.MeetingTypeID=GMD.MeetingTypeID
	INNER JOIN 
		MEETING_STATUS MS ON MS.MeetingStatusID=GMD.MeetingStatusID
	WHERE 
		GroupID = @GroupID
		AND GMD.MeetingStartDateTime <= GETDATE() AND GETDATE() <= GMD.MeetingEndDateTime
	ORDER BY
		MeetingStartDateTime;	
	
	--Select Future Meetings
	SELECT GMD.MeetingDateID
		, GMD.GroupID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingVenue
		, GMD.MeetingStreet
		, GMD.MeetingCity
		, GMD.MeetingZip
		, GMD.MeetingState
		, GMD.MeetingDialInNumber
		, GMD.AgendaDocumentID
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, MS.MeetingStatusName
		, (SELECT COUNT(MeasureID) FROM VW_MEETING_DATES_WITH_MEASURES MDM WHERE MDM.MeetingDateID = GMD.MeetingDateID) AS MeasureCount
	FROM 
		dbo.GROUP_MEETING_DATES GMD
	INNER JOIN 
		MEETING_TYPE MT ON MT.MeetingTypeID=GMD.MeetingTypeID
	INNER JOIN 
		MEETING_STATUS MS ON MS.MeetingStatusID=GMD.MeetingStatusID
	WHERE 
		GroupID = @GroupID
		AND GETDATE() < GMD.MeetingStartDateTime
	ORDER BY
		MeetingStartDateTime;

	--Select Past Meetings
	SELECT GMD.MeetingDateID
		, GMD.GroupID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingVenue
		, GMD.MeetingStreet
		, GMD.MeetingCity
		, GMD.MeetingZip
		, GMD.MeetingState
		, GMD.MeetingDialInNumber
		, GMD.AgendaDocumentID
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, MS.MeetingStatusName
		, (SELECT COUNT(MeasureID) FROM VW_MEETING_DATES_WITH_MEASURES MDM WHERE MDM.MeetingDateID = GMD.MeetingDateID) AS MeasureCount
	FROM 
		dbo.GROUP_MEETING_DATES GMD
	INNER JOIN 
		MEETING_TYPE MT ON MT.MeetingTypeID=GMD.MeetingTypeID
	INNER JOIN 
		MEETING_STATUS MS ON MS.MeetingStatusID=GMD.MeetingStatusID
	WHERE 
		GroupID = @GroupID
		AND GETDATE() > GMD.MeetingEndDateTime
	ORDER BY
		MeetingStartDateTime DESC;		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_GROUP_MEETING_DATES_BY_GROUP_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_GROUP_MEETING_DATES_BY_GROUP_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_GROUP_MEETING_DATES_BY_GROUP_ID.';
END
GO
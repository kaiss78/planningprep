SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID.';
	DROP PROCEDURE GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID
 * --Purpose/Function		: Get measure list for boardmeeting email notification
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 02/23/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/23/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID(
	@ProjectID BIGINT	
	, @Date DATETIME
)
AS
BEGIN
	SELECT * FROM
		(SELECT 
				vwMeeting.MeetingDateID as MeetingDateID,
				msf.ID as MeasureID,
				isnull(XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'varchar(2000)'),'') as Title, 
				msf.StatusSubmitted as Status
			FROM 
				MSF_SUBMISSIONS msf
					INNER JOIN VW_MEETING_DATES_WITH_MEASURES vwMeeting ON
						vwMeeting.MeasureID = msf.ID
					INNER JOIN GROUP_MEETING_DATES grp ON
						vwMeeting.MeetingDateID = grp.MeetingDateID	AND
						grp.MeetingEndDateTime < @Date	AND
						grp.GroupID = 1
			WHERE 
				(msf.StatusSubmitted = 20 OR
				 msf.StatusSubmitted = 21 OR
				 msf.StatusSubmitted = 22)
				 AND msf.ProjectID = @ProjectID
				 ) Measures
		WHERE 
		Measures.MeasureID NOT IN 
		(	
			SELECT
				MeasureID 
			FROM			
				EMAIL_NOTIFICATION_FOR_BOARD_MEETING notify
			WHERE
				Measures.MeetingDateID = notify.MeetingDateID
				AND Measures.MeasureID = notify.MeasureID
		)
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_MEASURELIST_FOR_BOARDMEETING_EMAIL_NOTIFICATION_BY_PROJECTID.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURE_MEETING_DATES_BY_PROJECT_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_MEASURE_MEETING_DATES_BY_PROJECT_ID.';
	DROP PROCEDURE GET_MEASURE_MEETING_DATES_BY_PROJECT_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_MEASURE_MEETING_DATES_BY_PROJECT_ID
 * --Purpose/Function		: Get Measures with MeetingDates by projet id
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 02/13/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/13/2010		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_MEASURE_MEETING_DATES_BY_PROJECT_ID(
	@GroupID BIGINT
	, @ProjectID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	--Select Current Meetings
	SELECT 
		GMD.MeetingDateID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, ST.MeetingStatusName
		, MS.ID AS MeasureID
		, ISNULL(MS.XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'VARCHAR(256)'),'') AS MeasureTitle
	FROM 
		MSF_SUBMISSIONS AS MS
		INNER JOIN 
			VW_MEETING_DATES_WITH_MEASURES AS MDM ON MS.ID = MDM.MeasureID
		INNER JOIN
			GROUP_MEETING_DATES AS GMD ON MDM.MeetingDateID = GMD.MeetingDateID
		INNER JOIN 
			MEETING_TYPE AS MT ON GMD.MeetingTypeID = MT.MeetingTypeID
		INNER JOIN 
			MEETING_STATUS AS ST ON ST.MeetingStatusID=GMD.MeetingStatusID
	WHERE 
		GMD.GroupID = @GroupID	
		AND MS.ProjectID = @ProjectID
		AND GMD.MeetingStartDateTime <= GETDATE() AND GETDATE() <= GMD.MeetingEndDateTime
	ORDER BY
		MeetingStartDateTime;	
	
	--Select Future Meetings
	SELECT 
		GMD.MeetingDateID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, ST.MeetingStatusName
		, MS.ID AS MeasureID
		, ISNULL(MS.XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'VARCHAR(256)'),'') AS MeasureTitle
	FROM 
		MSF_SUBMISSIONS AS MS
		INNER JOIN 
			VW_MEETING_DATES_WITH_MEASURES AS MDM ON MS.ID = MDM.MeasureID
		INNER JOIN
			GROUP_MEETING_DATES AS GMD ON MDM.MeetingDateID = GMD.MeetingDateID
		INNER JOIN 
			MEETING_TYPE AS MT ON GMD.MeetingTypeID = MT.MeetingTypeID
		INNER JOIN 
			MEETING_STATUS AS ST ON ST.MeetingStatusID=GMD.MeetingStatusID
	WHERE 
		GMD.GroupID = @GroupID
		AND MS.ProjectID = @ProjectID
		AND GETDATE() < GMD.MeetingStartDateTime
	ORDER BY
		MeetingStartDateTime;

	--Select Past Meetings
	SELECT 
		GMD.MeetingDateID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, ST.MeetingStatusName
		, MS.ID AS MeasureID
		, ISNULL(MS.XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'VARCHAR(256)'),'') AS MeasureTitle
	FROM 
		MSF_SUBMISSIONS AS MS
		INNER JOIN 
			VW_MEETING_DATES_WITH_MEASURES AS MDM ON MS.ID = MDM.MeasureID
		INNER JOIN
			GROUP_MEETING_DATES AS GMD ON MDM.MeetingDateID = GMD.MeetingDateID
		INNER JOIN 
			MEETING_TYPE AS MT ON GMD.MeetingTypeID = MT.MeetingTypeID
		INNER JOIN 
			MEETING_STATUS AS ST ON ST.MeetingStatusID=GMD.MeetingStatusID
	WHERE 
		GMD.GroupID = @GroupID
		AND MS.ProjectID = @ProjectID
		AND GETDATE() > GMD.MeetingEndDateTime
	ORDER BY
		MeetingStartDateTime DESC;	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURE_MEETING_DATES_BY_PROJECT_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_MEASURE_MEETING_DATES_BY_PROJECT_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_MEASURE_MEETING_DATES_BY_PROJECT_ID.';
END
GO
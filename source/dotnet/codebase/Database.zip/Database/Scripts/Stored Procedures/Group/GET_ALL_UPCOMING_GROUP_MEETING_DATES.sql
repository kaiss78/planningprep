SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_UPCOMING_GROUP_MEETING_DATES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_ALL_UPCOMING_GROUP_MEETING_DATES.';
	DROP PROCEDURE GET_ALL_UPCOMING_GROUP_MEETING_DATES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_ALL_UPCOMING_GROUP_MEETING_DATES
 * --Purpose/Function		: Gets MeetingDates objects by ID
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/11/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--EXEC GET_ALL_UPCOMING_GROUP_MEETING_DATES 'MeetingStartDateTime','ASC'
CREATE PROCEDURE dbo.GET_ALL_UPCOMING_GROUP_MEETING_DATES
(
	@SortBy VARCHAR(100)
	, @SortOrder VARCHAR(10)
	,@GroupID bigint
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @SQL VARCHAR(MAX) 
	SET @SQL = 
	'SELECT MeetingDateID
		, GMD.GroupID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime
		, GMD.MeetingVenue
		, GMD.MeetingStreet
		, GMD.MeetingCity
		, GMD.MeetingZip
		, GMD.MeetingState
		, GMD.MeetingDialInNumber
		, GMD.AgendaDocumentID
		, GMD.SummaryDocumentID
		, GMD.MeetingStatusID
		, '''' AS MeetingStatusName
		, MT.MeetingTypeName AS MeetingTypeName
	FROM dbo.GROUP_MEETING_DATES GMD
	LEFT OUTER JOIN MEETING_TYPE MT ON MT.MeetingTypeID = GMD.MeetingTypeID
	WHERE GMD.MeetingStartDateTime > GetDate() 
		AND GMD.MeetingStatusID = 1
		AND GMD.GroupID = '+CAST(@GroupID as varchar(50))+'
	ORDER BY '+@SortBy+' '+@SortOrder	
	PRINT (@SQL);
	EXEC (@SQL);		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_UPCOMING_GROUP_MEETING_DATES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_ALL_UPCOMING_GROUP_MEETING_DATES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_ALL_UPCOMING_GROUP_MEETING_DATES.';
END
GO
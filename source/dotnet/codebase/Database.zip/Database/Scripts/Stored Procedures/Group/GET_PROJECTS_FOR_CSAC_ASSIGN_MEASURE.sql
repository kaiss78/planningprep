SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE.';
	DROP PROCEDURE GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE
 * --Purpose/Function		: Gets Type objects by ID
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/11/2010		SR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @MemberVotingStatus INT
	SET @MemberVotingStatus=18
	DECLARE @SecondVoteStatus INT
	SET @SecondVoteStatus=23

	SELECT DISTINCT PM.ProjectID
				,PD.ShortName
				,ISNULL(SD.ProjectStatusSummary,'') AS ProjectStatusSummary
				,ISNULL(SD.ShortDescription,'') AS ShortDescription
	FROM OPLM_PROJECT_MASTER PM
			INNER JOIN OPLM_PROJECT_PRIMARY_DATA PD 
					ON PD.ProjectID=PM.ProjectID
			LEFT OUTER JOIN OPLM_PROJECT_SECONDARY_DATA SD 
					ON SD.ProjectID=PD.ProjectID			
			INNER JOIN MSF_SUBMISSIONS MS ON MS.ProjectID=PD.ProjectID
			AND  (MS.StatusSubmitted=@MemberVotingStatus OR MS.StatusSubmitted=@SecondVoteStatus)
			ORDER BY PD.ShortName ASC
END

GO

-- EXEC dbo.GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE
-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_PROJECTS_FOR_CSAC_ASSIGN_MEASURE.';
END
GO
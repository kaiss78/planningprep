SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_AGENDA_DRAFT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_AGENDA_DRAFT.';
	DROP PROCEDURE GET_AGENDA_DRAFT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_AGENDA_DRAFT
 * --Purpose/Function		: GET MEASURE AND VOTING INFORMATION FOR AGENDA DRAFT
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/14/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_AGENDA_DRAFT
	@MeetingID bigint = 13
AS
BEGIN

-- Get Project-wise Measures Info
SELECT
		MSF_SUBMISSIONS.ProjectID,
		OPLM_PROJECT_PRIMARY_DATA.ShortName,		
		MSF_SUBMISSIONS.ID,		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'varchar(2000)'),'') as MeaureTitle, 
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewMeasureDescription/text())[1]', 'varchar(max)'),'') as Measuredesc, 
		isnull(XML_DATA.value('(/tabs/tab[@id="7"]/MeasureSteward/MeasureStewardOrganization/text())[1]', 'varchar(2000)'),'') as StewardOrganization, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/MeasureSpecificationNumeratorStatement/text())[1]', 'varchar(max)'),'') as Numerator, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/MeasureSpecificationNumeratorDetails/text())[1]', 'varchar(max)'),'') as NumeratorCoding, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/MeasureSpecificationDenominatorStatement/text())[1]', 'varchar(max)'),'') as Denominator, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/MeasureSpecificationDenominatorDetails/text())[1]', 'varchar(max)'),'') as DenominatorCoding, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/MeasureSpecificationDenominatorExclusions/text())[1]', 'varchar(max)'),'') as Exclusions, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/MeasureSpecificationDenominatorExclusionDetails/text())[1]', 'varchar(max)'),'') as ExclusionCoding, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/SamplingMethodologyDataSource/text())[1]', 'varchar(500)'),'') as DataSource, 		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/ListLevelOfMeasurementOrAnalysis/text())[1]', 'varchar(500)'),'') as LevelOfAnalysis,		
		isnull(XML_DATA.value('(/tabs/tab[@id="2"]/SamplingMethodologyMeasurementLevelCliniciansOther/text())[1]', 'varchar(2000)'),'') as OthervalueLevelOfAnalysis,		

		MSF_SUBMISSIONS.DTS
FROM 
	MSF_SUBMISSIONS 		
		INNER JOIN OPLM_PROJECT_PRIMARY_DATA ON
			OPLM_PROJECT_PRIMARY_DATA.ProjectID = MSF_SUBMISSIONS.ProjectID
		INNER JOIN VW_MEETING_DATES_WITH_MEASURES ON
			VW_MEETING_DATES_WITH_MEASURES.MeasureID = MSF_SUBMISSIONS.ID
			AND VW_MEETING_DATES_WITH_MEASURES.MeetingDateID = @MeetingID
ORDER by 
	OPLM_PROJECT_PRIMARY_DATA.ShortName

END

-- Get Voting Summary Info

CREATE TABLE #allCouncils
(
	ID INT IDENTITY,
	COUNCIL VARCHAR(1000)
)

INSERT INTO #allCouncils SELECT DISTINCT COUNCIL  from dbo.IMIS_ELIGIBLE_VOTERS where council is not null;

WITH VOTINGRESULT AS
(
	SELECT
	vr.VoteResultID as ID,
	vr.VotingDate AS VOTING_DATE,
	vr.MeasureID AS MEASURE_ID,
	ms.ProjectID AS PROJECT_ID,    
    --case vr.MeasureID when 2 then 3 else vr.MeasureID end MEASURE_ID,
	MS.XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 
                      'varchar(2000)') AS MEASURE_NAME,
	vrui.Council COUNCIL_NAME,	
	case vr.Result when 'Approve' then vr.result else null end ApproveResult,
	case vr.Result when 'Disapprove' then vr.result else null end DenyResult,
	case vr.Result when 'Abstain' then vr.result else null end AbstainResult 

	FROM VOTING_RESULTS vr 
		INNER JOIN VOTING_RESULTS_USER_INFO vrui
			On vr.VoteUserInfoID=vrui.UserInfoID
		LEFT OUTER JOIN dbo.MSF_SUBMISSIONS AS MS
			ON vr.MeasureID = MS.ID
		INNER JOIN VW_MEETING_DATES_WITH_MEASURES ON
			VW_MEETING_DATES_WITH_MEASURES.MeasureID = vr.MeasureID
			AND VW_MEETING_DATES_WITH_MEASURES.MeetingDateID = @MeetingID
	WHERE
		(CAST(CONVERT(VARCHAR(20), vr.VotingDate, 101) AS DATETIME) >= '01/01/1900') 
		and (CAST(CONVERT(VARCHAR(20), vr.VotingDate, 101) AS DATETIME) <= '01/01/2099')	
)

SELECT 
	COUNCIL_NAME, 
	MEASURE_ID,
    PROJECT_ID,
	MEASURE_NAME,
	YES,
	No,
	Abstain,
	TotalVotes, 
	case when TotalVotes - Abstain = 0 then null else ROUND(Yes * CAST(100 as FLOAT)/CAST((TotalVotes - Abstain)as FLOAT),0) end 
	PercentResult into #tempTable FROM
	(
		select t1.COUNCIL_NAME,t1.measure_id,t1.PROJECT_ID, t1.MEASURE_NAME, count(t1.ApproveResult) Yes,count(t1.DenyResult) No, count(t1.AbstainResult) Abstain, count(t1.ApproveResult) + (count(t1.DenyResult) + count(t1.AbstainResult)) TotalVotes from VOTINGRESULT t1 INNER join VOTINGRESULT t2
		on t1.ID=t2.ID
		where  t1.MEASURE_ID=t2.MEASURE_ID and
		t1.COUNCIL_NAME=t2.COUNCIL_NAME GROUP BY
		t1.measure_id,t1.PROJECT_ID,t1.COUNCIL_NAME,t1.MEASURE_NAME

	) RESULTQUERY
ORDER by MEASURE_ID,COUNCIL_NAME;

CREATE TABLE #allMeasureIDs
(
	ID INT IDENTITY,
	MEASURE_ID BIGINT, 
    PROJECT_ID BIGINT, 
	MEASURE_NAME VARCHAR(1000)
)
INSERT INTO #allMeasureIDs SELECT DISTINCT MEASURE_ID, PROJECT_ID, MEASURE_NAME FROM #tempTable; 

--SELECT * FROM #tempTable

DECLARE @MeasureIDCount INT, @CouncilCount INT, @MeasureCouter INT, @CouncilCounter INT;
SET @MeasureCouter = 1;

SELECT @MeasureIDCount= MAX(ID) FROM #allMeasureIDs
SELECT @CouncilCount= MAX(ID) FROM #allCouncils

WHILE @MeasureCouter <= @MeasureIDCount
BEGIN
	SET @CouncilCounter = 1;
	WHILE @CouncilCounter <= @CouncilCount
	BEGIN
		DECLARE @CurrentMeasureID BIGINT, @CurrentProjectID BIGINT, @CurrentCouncil VARCHAR(100),@CurrentMeasureName VARCHAR(100)

		SELECT @CurrentMeasureID = MEASURE_ID FROM #allMeasureIDs WHERE ID = @MeasureCouter;
		SELECT @CurrentProjectID = PROJECT_ID FROM #allMeasureIDs WHERE ID = @MeasureCouter;        
		SELECT @CurrentMeasureName = MEASURE_NAME FROM #allMeasureIDs WHERE ID = @MeasureCouter;
		SELECT @CurrentCouncil = COUNCIL FROM #allCouncils WHERE ID = @CouncilCounter;

		IF NOT EXISTS (SELECT * FROM #tempTable WHERE COUNCIL_NAME = @CurrentCouncil AND MEASURE_ID = @CurrentMeasureID)
		BEGIN
			INSERT INTO #tempTable VALUES(@CurrentCouncil,@CurrentMeasureID, @CurrentProjectID,@CurrentMeasureName,0,0,0,0,null)
		END
		SET @CouncilCounter = @CouncilCounter + 1
	END
	SET @MeasureCouter = @MeasureCouter + 1
END;



WITH AVGQuery AS
(
	SELECT MEASURE_ID,TotalYesForMeasure,TotalNoForMeasure,TotalAbstainForMeasure,TotalVotesForMeasure,AvgPercentResultForMeasure,CountOver50,TotalCount,
	case when TotalCount = 0 then null else 100 * CAST(CountOver50 as Float)/CAST(TotalCount as Float) end MeasurePercentageRatio
	FROM
	(
		SELECT  MEASURE_ID,Sum(Yes) TotalYesForMeasure,Sum(No) TotalNoForMeasure,Sum(Abstain) TotalAbstainForMeasure,Sum(TotalVotes) TotalVotesForMeasure, Avg(CAST(PercentResult as Float)) AvgPercentResultForMeasure, Count(case when PercentResult > 50 then PercentResult end) CountOver50, Count(PercentResult) TotalCount FROM
		#tempTable
		GROUP BY MEASURE_ID
	)
	InnerQry
)



SELECT 
		COUNCIL_NAME,MEASURE_ID, 
		PROJECT_ID, 
		OPLM_PROJECT_PRIMARY_DATA.ShortName,  
		MEASURE_NAME, YES,No,Abstain,TotalVotes,PercentResult,
		isnull(MSF_SUBMISSIONS.XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'varchar(2000)'),'') as MeaureTitle, 
		isnull(XML_DATA.value('(/tabs/tab[@id="7"]/MeasureSteward/MeasureStewardOrganization/text())[1]', 'varchar(2000)'),'') as StewardOrganization, 		
		(Select ROUND(AvgPercentResultForMeasure,0) from AVGQuery where AVGQuery.MEASURE_ID = #tempTable.MEASURE_ID) AvgPercentResultForMeasure, 
		(Select ROUND(MeasurePercentageRatio,0) from AVGQuery where AVGQuery.MEASURE_ID = #tempTable.MEASURE_ID) MeasurePercentageRatio 
FROM 
		#tempTable
		INNER JOIN MSF_SUBMISSIONS ON
			MSF_SUBMISSIONS.ID = #tempTable.MEASURE_ID
		INNER JOIN OPLM_PROJECT_PRIMARY_DATA ON
			OPLM_PROJECT_PRIMARY_DATA.ProjectID = #tempTable.PROJECT_ID
ORDER BY 
		OPLM_PROJECT_PRIMARY_DATA.ShortName, MEASURE_ID,COUNCIL_NAME

drop table #tempTable
drop table #allCouncils
drop table #allMeasureIDs

GO


-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_AGENDA_DRAFT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_AGENDA_DRAFT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_AGENDA_DRAFT.';
END
GO

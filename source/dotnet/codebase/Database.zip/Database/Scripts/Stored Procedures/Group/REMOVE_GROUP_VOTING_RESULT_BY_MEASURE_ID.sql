SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID.';
	DROP PROCEDURE REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID
 * --Purpose/Function		: Saves a VotingResult object
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 02/22/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/18/2010		MHA		Initial Development				
 * ===================================================================*/
--SElect * from GROUP_VOTING_RESULT
-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID(	
	@MeasureID BIGINT	
    ,@GroupID BIGINT
	,@MeetingDateID BIGINT = 4
)
AS
BEGIN
	SET NOCOUNT ON;
    DELETE FROM dbo.GROUP_VOTING_RESULT WHERE MeasureID =@MeasureID	AND GroupID = @GroupID AND MeetingDateID = @MeetingDateID
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REMOVE_GROUP_VOTING_RESULT_BY_MEASURE_ID.';
END
GO
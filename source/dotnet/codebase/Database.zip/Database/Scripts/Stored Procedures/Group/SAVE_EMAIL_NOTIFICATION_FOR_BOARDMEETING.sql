SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING.';
	DROP PROCEDURE SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING
 * --Purpose/Function		: Save email notification for boardmeeting
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 02/23/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/23/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING(
	@ProjectID BIGINT
	, @MeetingDateID BIGINT
	, @MeasureID BIGINT
	, @EmailSentDate DATETIME
)
AS
BEGIN
	INSERT INTO [EMAIL_NOTIFICATION_FOR_BOARD_MEETING]
           ([ProjectID]
           ,[MeetingDateID]
		   ,[MeasureID]
           ,[EmailSentDate])
     VALUES
           (@ProjectID, @MeetingDateID, @MeasureID, @EmailSentDate)
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_EMAIL_NOTIFICATION_FOR_BOARDMEETING.';
END
GO
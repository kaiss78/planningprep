SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEETING_DATE_MEASURE_BY_MEASURE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_MEETING_DATE_MEASURE_BY_MEASURE_ID.';
	DROP PROCEDURE GET_MEETING_DATE_MEASURE_BY_MEASURE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_MEETING_DATE_MEASURE_BY_MEASURE_ID
 * --Purpose/Function		: Gets DateMeasure objects by ID
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/12/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/12/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
-- GET_MEETING_DATE_MEASURE_BY_MEASURE_ID 118
CREATE PROCEDURE dbo.GET_MEETING_DATE_MEASURE_BY_MEASURE_ID(
	@MeasureID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
/*
	SELECT MeetingDateID
		, MeasureID
	FROM dbo.VW_MEETING_DATES_WITH_MEASURES
	WHERE MeasureID = @MeasureID;			
*/
	SELECT TOP 1 GMDFM.MeetingDateID , MSC.MeasureID FROM GROUP_MEETING_DATES_FOR_MEASURE GMDFM
	LEFT OUTER JOIN MSF_STATUS_CHANGE MSC ON MSC.MsfStatusChangeID = GMDFM.MsfStatusChangeID
	WHERE 
		MSC.MeasureID=@MeasureID
	ORDER BY MSC.DTS DESC
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEETING_DATE_MEASURE_BY_MEASURE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_MEETING_DATE_MEASURE_BY_MEASURE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_MEETING_DATE_MEASURE_BY_MEASURE_ID.';
END
GO
SET QUOTED_IDENTIFIER OFF;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID.';
	DROP PROCEDURE GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID
 * --Purpose/Function		: Saves a MeetingDates object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/11/2010		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID(
	@MeetingDateID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT GMD.MeetingDateID
		, GMD.GroupID
		, GMD.MeetingTypeID
		, GMD.MeetingStartDateTime
		, GMD.MeetingEndDateTime		
        , GMD.MeetingVenue
		, GMD.MeetingStreet
		, GMD.MeetingCity
		, GMD.MeetingZip
		, GMD.MeetingState
		, GMD.MeetingDialInNumber
		, GMD.AgendaDocumentID
		, GMD.MeetingStatusID
		, MT.MeetingTypeName
		, MS.MeetingStatusName
		, GMD.SummaryDocumentID
	FROM dbo.GROUP_MEETING_DATES GMD
	INNER JOIN MEETING_TYPE MT ON MT.MeetingTypeID=GMD.MeetingTypeID
	INNER JOIN MEETING_STATUS MS ON MS.MeetingStatusID=GMD.MeetingStatusID
	WHERE MeetingDateID = @MeetingDateID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_GROUP_MEETING_DATES_BY_MEETING_DATE_ID.';
END
GO
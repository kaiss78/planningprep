SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW.';
	DROP PROCEDURE IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW
 * --Purpose/Function		: Saves group member
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 02/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 02/11/2010		MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW] 
	-- Add the parameters for the stored procedure here
	@MeasureID bigint
	,@ReturnVal bit output
AS
BEGIN
	SET @ReturnVal = 0
	IF EXISTS(SELECT MeasureID FROM dbo.BOARD_RATIFICATION_ELIGIBLE_MEASURES() WHERE MeasureID=@MeasureID)
	BEGIN
		SET @ReturnVal = 1
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IS_MEASURE_ELIGIBLE_FOR_BOARD_REVIEW.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES.';
	DROP PROCEDURE GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES
 * --Purpose/Function		: Gets SubTaxonomy objects by Taxonomy ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 12/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--EXEC GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES 1, 39
CREATE PROCEDURE dbo.GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES(
	@TaxonomyID BIGINT
	, @ProjectID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT DISTINCT MMT.SubTaxonomyID
	, MST.SubTaxonomyName
	, MST.TaxonomyID
	--, MSF.ID 	
	FROM MSF_SUBMISSIONS MSF
	LEFT OUTER JOIN MSF_MEASURE_TAXONOMY MMT ON MMT.MeasureID = MSF.ID
	LEFT OUTER JOIN MSF_SUB_TAXONOMY MST ON MST.SubTaxonomyID = MMT.SubTaxonomyID
	WHERE MSF.ProjectID = @ProjectID
	AND MSF.StatusSubmitted = 17
	AND MSF.IsDeleted=0
	AND MST.TaxonomyID = @TaxonomyID
	ORDER BY MST.SubTaxonomyName ASC;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_MSF_SUB_TAXONOMY_BY_TAXONOMY_ID_RECOMMENDED_MEASURES.';
END
GO

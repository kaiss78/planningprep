SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Save_PROJECT_VOTING_CHOICE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure Save_PROJECT_VOTING_CHOICE.';
	DROP PROCEDURE Save_PROJECT_VOTING_CHOICE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: Save_PROJECT_VOTING_CHOICE
 * --Purpose/Function		: Saves a VotingChoice object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 02/02/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/02/2010		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.Save_PROJECT_VOTING_CHOICE(
	@ProjectVotingChoiceID BIGINT
	, @ActivityID BIGINT
	, @ProjectID BIGINT
	, @Choice1 VARCHAR(50)
	, @Choice2 VARCHAR(50)
	, @Choice3 VARCHAR(50)
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.PROJECT_VOTING_CHOICE WHERE ProjectID = @ProjectID AND ActivityID=@ActivityID)
	BEGIN
		-- Update Existing VotingChoice Information
		UPDATE dbo.PROJECT_VOTING_CHOICE SET
			ActivityID = @ActivityID
			, ProjectID = @ProjectID
			, Choice1 = @Choice1
			, Choice2 = @Choice2
			, Choice3 = @Choice3
		WHERE ProjectID = @ProjectID AND ActivityID=@ActivityID;

		SET @GeneratedID = (SELECT ProjectVotingChoiceID FROM dbo.PROJECT_VOTING_CHOICE WHERE ProjectID = @ProjectID AND ActivityID=@ActivityID);		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.PROJECT_VOTING_CHOICE
		INSERT INTO dbo.PROJECT_VOTING_CHOICE (ActivityID
			, ProjectID
			, Choice1
			, Choice2
			, Choice3)
		VALUES(@ActivityID
			, @ProjectID
			, @Choice1
			, @Choice2
			, @Choice3);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Save_PROJECT_VOTING_CHOICE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure Save_PROJECT_VOTING_CHOICE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure Save_PROJECT_VOTING_CHOICE.';
END
GO
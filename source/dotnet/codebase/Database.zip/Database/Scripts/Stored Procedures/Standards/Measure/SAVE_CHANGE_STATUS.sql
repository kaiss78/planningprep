SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'MSF_SAVE_CHANGE_STATUS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure MSF_SAVE_CHANGE_STATUS.';
	DROP PROCEDURE MSF_SAVE_CHANGE_STATUS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: MSF_SAVE_CHANGE_STATUS
 * --Purpose/Function		: Saves a committee object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/09/2009		MRZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE MSF_SAVE_CHANGE_STATUS(
	@MsfStatusChangeID BIGINT
	, @MeasureID BIGINT
	, @ChangedStatus TINYINT
	, @OPLMIMISUserID BIGINT
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @PreveiousStatus AS BIGINT
	SET @PreveiousStatus=(SELECT StatusSubmitted FROM MSF_SUBMISSIONS WHERE ID=@MeasureID)

	IF EXISTS(SELECT * FROM dbo.MSF_STATUS_CHANGE WHERE MsfStatusChangeID = @MsfStatusChangeID)
	BEGIN
		-- Update Existing StatusChange Information
		UPDATE dbo.MSF_STATUS_CHANGE SET
			MeasureID = @MeasureID
			, PreveiousStatus = @PreveiousStatus
			, ChangedStatus = @ChangedStatus
			, OPLMIMISUserID = @OPLMIMISUserID
			, DTS = GETDATE()
		WHERE MsfStatusChangeID = @MsfStatusChangeID;
		SET @GeneratedID = @MsfStatusChangeID;		
	END
	ELSE
		BEGIN
		-- New Record, So insert it into the dbo.MSF_STATUS_CHANGE
		INSERT INTO dbo.MSF_STATUS_CHANGE (MeasureID
			, PreveiousStatus
			, ChangedStatus
			, OPLMIMISUserID
			, DTS)
		VALUES(@MeasureID
			, @PreveiousStatus
			, @ChangedStatus
			, @OPLMIMISUserID
			, GETDATE());
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'MSF_SAVE_CHANGE_STATUS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure MSF_SAVE_CHANGE_STATUS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure MSF_SAVE_CHANGE_STATUS.';
END
GO
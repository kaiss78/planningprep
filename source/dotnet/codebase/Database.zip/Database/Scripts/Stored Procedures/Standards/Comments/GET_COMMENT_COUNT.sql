SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_COUNT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMENT_COUNT.';
	DROP PROCEDURE GET_COMMENT_COUNT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMMENT_COUNT
 * --Purpose/Function		: Gets Type objects by ID
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 17/10/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 17/10/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--EXEC GET_COMMENT_COUNT 39, 0, 3
CREATE PROCEDURE GET_COMMENT_COUNT(
	@ProjectID BIGINT
	, @MeasureID BIGINT
	, @CommentType BIGINT
)
AS
BEGIN
	IF( @CommentType = 1)
	BEGIN
		SELECT TotalCount = COUNT ( CommentID )
		FROM MEASURE_COMMENTS 
		WHERE ProjectID = @ProjectID
		AND MeasureID = @MeasureID
	END
	ELSE
	BEGIN
		SELECT TotalCount = COUNT ( CommentID )
		FROM MEASURE_COMMENTS 
		WHERE ProjectID = @ProjectID
		AND CommentType = @CommentType
	END
	
		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_COUNT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMENT_COUNT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMENT_COUNT.';
END
GO
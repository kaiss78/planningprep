SET ANSI_NULLS ON;
SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE.';
	DROP PROCEDURE GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE
 * --Purpose/Function		: Gets Type objects by ID
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 01/19/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/19/2010		MHA		Initial Development				
 * ===================================================================*/
---exec GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE '112218'
-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE
(
 @IMISUserID varchar(50)
)
AS
BEGIN
SELECT DISTINCT Isnull(msf.xml_data.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'varchar(256)'), '') AS title,
                project.shortname,
                project.projectid,
                msf.id                                                                                          measureid,
                (SELECT Count(*)
                 FROM   measure_comments COMMENT
                 WHERE  COMMENT.projectid = project.projectid
                        AND COMMENT.measureid = msf.id
                        AND COMMENT.status = 2)                                                                 waitforresponse
	FROM   msf_submissions msf
		   INNER JOIN oplm_project_primary_data project
			 ON msf.projectid = project.projectid
           INNER JOIN 
           measure_comments msf_comment
           ON
           msf_comment.projectid=project.projectid
         and 
          msf_comment.measureid=msf.id  
	WHERE MSF.IMISUserID = @IMISUserID
	AND MSF.IsDeleted=0
	order  BY project.shortname ASC 
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMENT_BY_PROJECT_AND_MEASURE_WAITING_FOR_RESPONSE.';
END
GO
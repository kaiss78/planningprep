SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_VOTING_RESULTS_ORGANIZER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_VOTING_RESULTS_ORGANIZER.';
	DROP PROCEDURE SAVE_VOTING_RESULTS_ORGANIZER;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_VOTING_RESULTS_ORGANIZER
 * --Purpose/Function		: Saves a ResultsManager object
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/01/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/01/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_VOTING_RESULTS_ORGANIZER(
	@VotingResultOrganizerID BIGINT
	, @ProjectID BIGINT
	, @ActivityID BIGINT
	, @ResultDocumentID BIGINT
	, @CommentDocumentID BIGINT
	, @UploadType INT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE @MSF_NOTES_IDS TABLE
	(
	  NoteID BIGINT
	)

	DECLARE @MSF_STATUS_CHANGE_IDS TABLE
	(
	  MsfStatusChangeID BIGINT
	)
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.VOTING_RESULTS_ORGANIZER WHERE VotingResultOrganizerID = @VotingResultOrganizerID)
	BEGIN
		-- Update Existing ResultsManager Information

		
		IF ( @UploadType = 3 )--for both voting results and comments upload
		BEGIN

			DELETE FROM VOTING_RESULTS
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID

			/*delete of notes*/
			INSERT INTO @MSF_NOTES_IDS 
			SELECT NoteID FROM VOTING_COMMENTS_RELATIONS 				
			WHERE VOTING_COMMENTS_RELATIONS.VotingResultOrganizerID = @VotingResultOrganizerID

			INSERT INTO @MSF_STATUS_CHANGE_IDS 
			SELECT MSF_NOTES.MsfStatusChangeID FROM MSF_NOTES 
			LEFT OUTER JOIN VOTING_COMMENTS_RELATIONS ON MSF_NOTES.NoteID = VOTING_COMMENTS_RELATIONS.NoteID
			WHERE VOTING_COMMENTS_RELATIONS.VotingResultOrganizerID = @VotingResultOrganizerID
			
			
			DELETE FROM VOTING_COMMENTS_RELATIONS 
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID

			DELETE FROM MSF_NOTES 
			WHERE MSF_NOTES.NoteID IN (SELECT NoteID FROM @MSF_NOTES_IDS)

			DELETE FROM MSF_STATUS_CHANGE 
			WHERE MSF_STATUS_CHANGE.MsfStatusChangeID IN (SELECT MsfStatusChangeID FROM @MSF_STATUS_CHANGE_IDS)

			/*delete of notes*/
			
			DELETE FROM VOTING_RESULTS_USER_INFO
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID
			

		END		
		ELSE IF (@UploadType = 1)--for voting result upload only
		BEGIN
			DELETE FROM VOTING_RESULTS
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID

			DELETE FROM VOTING_RESULTS_USER_INFO
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID
				AND UserInfoFor = @UploadType			
		END
		ELSE IF ( @UploadType = 2 )--for voting comments upload only
		BEGIN		

			/*delete of notes*/
			INSERT INTO @MSF_NOTES_IDS 
			SELECT NoteID FROM VOTING_COMMENTS_RELATIONS 				
			WHERE VOTING_COMMENTS_RELATIONS.VotingResultOrganizerID = @VotingResultOrganizerID

			INSERT INTO @MSF_STATUS_CHANGE_IDS 
			SELECT MSF_NOTES.MsfStatusChangeID FROM MSF_NOTES 
			LEFT OUTER JOIN VOTING_COMMENTS_RELATIONS ON MSF_NOTES.NoteID = VOTING_COMMENTS_RELATIONS.NoteID
			WHERE VOTING_COMMENTS_RELATIONS.VotingResultOrganizerID = @VotingResultOrganizerID
			
			
			DELETE FROM VOTING_COMMENTS_RELATIONS 
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID

			DELETE FROM MSF_NOTES 
			WHERE MSF_NOTES.NoteID IN (SELECT NoteID FROM @MSF_NOTES_IDS)

			DELETE FROM MSF_STATUS_CHANGE 
			WHERE MSF_STATUS_CHANGE.MsfStatusChangeID IN (SELECT MsfStatusChangeID FROM @MSF_STATUS_CHANGE_IDS)

			/*delete of notes*/

			DELETE FROM VOTING_RESULTS_USER_INFO
			WHERE VotingResultOrganizerID = @VotingResultOrganizerID
				AND UserInfoFor = @UploadType

			
		END
		
		


		UPDATE dbo.VOTING_RESULTS_ORGANIZER SET
			ProjectID = @ProjectID
			, ActivityID = @ActivityID
			, ResultDocumentID = @ResultDocumentID
			, CommentDocumentID = @CommentDocumentID
		WHERE VotingResultOrganizerID = @VotingResultOrganizerID;
		SET @GeneratedID = @VotingResultOrganizerID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.VOTING_RESULTS_ORGANIZER
		INSERT INTO dbo.VOTING_RESULTS_ORGANIZER (ProjectID
			, ActivityID
			, ResultDocumentID
			, CommentDocumentID)
		VALUES(@ProjectID
			, @ActivityID
			, @ResultDocumentID
			, @CommentDocumentID);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_VOTING_RESULTS_ORGANIZER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_VOTING_RESULTS_ORGANIZER created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_VOTING_RESULTS_ORGANIZER.';
END
GO
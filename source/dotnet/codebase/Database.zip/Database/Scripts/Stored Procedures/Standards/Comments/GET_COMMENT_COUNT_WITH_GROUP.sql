SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_COUNT_WITH_GROUP'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMENT_COUNT_WITH_GROUP.';
	DROP PROCEDURE GET_COMMENT_COUNT_WITH_GROUP;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMMENT_COUNT_WITH_GROUP
 * --Purpose/Function		: GET COMMENT COUNT WITH GROUP
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 01/21/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/13/2010		SR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_COMMENT_COUNT_WITH_GROUP](
	@ProjectID BIGINT
	, @MeasureSubmissionPeriodIDList VARCHAR(1000)
)
AS
BEGIN
	IF @MeasureSubmissionPeriodIDList <> ''
	BEGIN
		SELECT TotalCount = COUNT ( CommentID )
			FROM MEASURE_COMMENTS 
			WHERE ProjectID = @ProjectID
			AND ActivityID in (select id from dbo.SplitId(@MeasureSubmissionPeriodIDList,',')) 
	END

	ELSE
	BEGIN
		SELECT TotalCount = COUNT ( CommentID )
			FROM MEASURE_COMMENTS 
			WHERE ProjectID = @ProjectID
	END
	
END

GO

-- EXEC GET_COMMENT_COUNT_WITH_GROUP 39, 300

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_COUNT_WITH_GROUP'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMENT_COUNT_WITH_GROUP created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMENT_COUNT_WITH_GROUP.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_VOTING_RESULTS_ORGANIZER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_VOTING_RESULTS_ORGANIZER.';
	DROP PROCEDURE GET_VOTING_RESULTS_ORGANIZER;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_VOTING_RESULTS_ORGANIZER
 * --Purpose/Function		: Gets ResultsManager objects by ID
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/01/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/01/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_VOTING_RESULTS_ORGANIZER(
	@VotingResultOrganizerID BIGINT
	, @ProjectID BIGINT
	, @ActivityID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	IF ( @VotingResultOrganizerID > 0)
	BEGIN
		SELECT VotingResultOrganizerID
		, ProjectID
		, ActivityID
		, ResultDocumentID
		, CommentDocumentID
		FROM dbo.VOTING_RESULTS_ORGANIZER
		WHERE VotingResultOrganizerID = @VotingResultOrganizerID;	
	END
	ELSE
	BEGIN
		SELECT VotingResultOrganizerID
		, ProjectID
		, ActivityID
		, ResultDocumentID
		, CommentDocumentID
		FROM dbo.VOTING_RESULTS_ORGANIZER
		WHERE ProjectID = @ProjectID
		AND  ActivityID = @ActivityID;	
	END
			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_VOTING_RESULTS_ORGANIZER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_VOTING_RESULTS_ORGANIZER created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_VOTING_RESULTS_ORGANIZER.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GROUP_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GROUP_COMMENTS.';
	DROP PROCEDURE GROUP_COMMENTS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GROUP_COMMENTS
 * --Purpose/Function		: GROUP COMMENTS 
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 01/19/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/13/2010		SR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GROUP_COMMENTS](
	@CommentIDs VARCHAR(1000)
)

AS
BEGIN

declare @groupID int

set @groupID = (select MAX(GroupID) from dbo.MEASURE_COMMENTS ) + 1

update dbo.MEASURE_COMMENTS set GroupID = @groupID, IsTop = 0 from dbo.MEASURE_COMMENTS where CommentID in 
(
	select CommentID from dbo.MEASURE_COMMENTS where GroupID in
	(
		select GroupID from dbo.MEASURE_COMMENTS where CommentID in (select id from dbo.SplitID(@CommentIDs,',')) and GroupID <> 0
	)
	union
	select CommentID from dbo.MEASURE_COMMENTS where CommentID in (select id from dbo.SplitID(@CommentIDs,',')) and GroupID = 0
)

update dbo.MEASURE_COMMENTS set IsTop = 1 from dbo.MEASURE_COMMENTS where CommentID = 
(
	select Top(1) CommentID from dbo.MEASURE_COMMENTS where DTS = 
	(
		select MAX(DTS) from dbo.MEASURE_COMMENTS where CommentID in (select id from dbo.SplitID(@CommentIDs,','))
	)
	and CommentID in (select id from dbo.SplitID(@CommentIDs,','))
)

END

-- EXEC GROUP_COMMENTS '51,52'
-- EXEC GROUP_COMMENTS '37,40,41'

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GROUP_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GROUP_COMMENTS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GROUP_COMMENTS.';
END
GO
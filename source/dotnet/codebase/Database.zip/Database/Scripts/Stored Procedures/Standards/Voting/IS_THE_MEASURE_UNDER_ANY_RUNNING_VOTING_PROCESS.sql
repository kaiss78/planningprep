
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS.';
	DROP PROCEDURE IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS
 * --Purpose/Function		: IS THE MEASURE UNDER ANY RUNNING VOTING PROCESS
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 01/31/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/31/2010		MHR		Initial Development				
 * ===================================================================*/
--exec IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS 19, 0
  --select * from VOTING_MEASURE_LIST
-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS](
	 @MeasureID BIGINT
    ,@IsRunning BIT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	DECLARE @activityID AS BIGINT
	DECLARE @startDate AS DATETIME
	DECLARE @endDate AS DATETIME
	
    --select * from VOTING_MEASURE_LIST
	IF EXISTS(SELECT VotingMeasureID FROM VOTING_MEASURE_LIST WHERE MeasureID=@MeasureID)
		BEGIN
             
			DECLARE activityid_cursor CURSOR FOR 
             SELECT ActivityID FROM VOTING_MEASURE_LIST WHERE MeasureID=@MeasureID

             OPEN activityid_cursor

             FETCH NEXT FROM activityid_cursor 
             INTO @activityID
             
             WHILE @@FETCH_STATUS = 0
             BEGIN

                    --select * from OPUS_PROJECT_STEPS
                    SELECT @startDate = StartDate, @endDate = EndDate
                          FROM OPUS_PROJECT_STEPS
                    WHERE ProjectStepID = @activityID
                    
                    IF @startDate <= GetDate()  
                    BEGIN
                       SET @IsRunning = 1
                       print 'tes'
                       BREAK
                    END
                    
					FETCH NEXT FROM activityid_cursor 
				    INTO @activityID
             END
 
             CLOSE activityid_cursor
             DEALLOCATE activityid_cursor
             
		END

	SELECT @IsRunning
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IS_THE_MEASURE_UNDER_ANY_RUNNING_VOTING_PROCESS.';
END
GO
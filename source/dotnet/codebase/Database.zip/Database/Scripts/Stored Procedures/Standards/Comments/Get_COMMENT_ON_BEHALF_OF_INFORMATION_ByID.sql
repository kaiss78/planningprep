SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID.';
	DROP PROCEDURE Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID
 * --Purpose/Function		: Gets OnBehalfOfInformation objects by ID
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 01/13/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/13/2010		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID(
	@ID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT ID
		, FirstName
                , LastName
		, Organization
		, Email
		, PhoneNo
		, PrimaryCouncil
	FROM dbo.COMMENT_ON_BEHALF_OF_INFORMATION
	WHERE ID = @ID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure Get_COMMENT_ON_BEHALF_OF_INFORMATION_ByID.';
END
GO 
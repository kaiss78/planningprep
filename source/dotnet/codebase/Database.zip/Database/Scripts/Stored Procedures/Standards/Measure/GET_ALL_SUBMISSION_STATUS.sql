SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_SUBMISSION_STATUS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_ALL_SUBMISSION_STATUS.';
	DROP PROCEDURE GET_ALL_SUBMISSION_STATUS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_ALL_SUBMISSION_STATUS
 * --Purpose/Function		: GET ALL SUBMISSION STATUS
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 12/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/14/2009		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_ALL_SUBMISSION_STATUS	
AS
SELECT 
	[ID],
	[SUBMISSION_STATUS_ID],
	[SUBMISSION_STATUS_NAME]
  FROM 
	[dbo].[MSF_SUBMISSION_STATUS]
WHERE     
	(SUBMISSION_STATUS_ID = 1) 
OR	(SUBMISSION_STATUS_ID = 3) 
OR	(SUBMISSION_STATUS_ID = 11)
OR	(SUBMISSION_STATUS_ID = 12)
OR	(SUBMISSION_STATUS_ID = 10)
OR	(SUBMISSION_STATUS_ID = 9)
OR	(SUBMISSION_STATUS_ID = 13)
OR	(SUBMISSION_STATUS_ID = 7)
OR	(SUBMISSION_STATUS_ID = 14)
OR	(SUBMISSION_STATUS_ID = 15)

GO


-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_SUBMISSION_STATUS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_ALL_SUBMISSION_STATUS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_ALL_SUBMISSION_STATUS.';
END
GO

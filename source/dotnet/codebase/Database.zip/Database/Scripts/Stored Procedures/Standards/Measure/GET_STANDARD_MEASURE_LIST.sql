set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_STANDARD_MEASURE_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_STANDARD_MEASURE_LIST.';
	DROP PROCEDURE GET_STANDARD_MEASURE_LIST;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_STANDARD_MEASURE_LIST
 * --Purpose/Function		: Retrieves Search Property 
 * --Author					: TF
 * --Start Date(MM/DD/YY)	: 10/29/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 10/29/09		TF	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

--exec [GET_STANDARD_MEASURE_LIST] 39,'64,52,13','2,10','2,10','',1,100
--exec [GET_STANDARD_MEASURE_LIST] 39,'','','','',1,100

--exec [GET_STANDARD_MEASURE_LIST] 39,'','',1,100
--exec [GET_STANDARD_MEASURE_LIST] 54,'','','12,15','',1,4
--exec [GET_STANDARD_MEASURE_LIST] '','','','',1,4

CREATE PROCEDURE [dbo].[GET_STANDARD_MEASURE_LIST](		
	@StewardList VARCHAR(MAX)
	, @NPPAreas VARCHAR(MAX)
	, @Conditions VARCHAR(MAX)
	, @SortField VARCHAR(100)	
	, @startPage INT
	, @pageSize INT		
)

As
BEGIN
	DECLARE @startRowIndex int
		, @endRowIndex int
		, @SQL VARCHAR(MAX)
		, @SQL_WHERE VARCHAR(MAX)
		, @SQL_ORDER_BY VARCHAR(MAX)
		, @SQL_STEWARD_ORGANIZATION_MSF_LEFT_JOIN VARCHAR(MAX)
		, @SQL_NPP_AERAS_JOIN VARCHAR(MAX)
		, @SQL_CONDITIONS_JOIN VARCHAR(MAX);

	/*Start of sorting variable set*/
	SET @startRowIndex = (@startPage -1 ) * @pageSize + 1;
	SET @endRowIndex = @startRowIndex + @pageSize -1;
	/*End of sorting variable set*/	


	/*Start of Condition portion*/
	SET @SQL_WHERE = 
	'WHERE ( MSF.StatusSubmitted = 34 OR  MSF.StatusSubmitted = 33 ) 
		AND MSF.IsDeleted=0
		AND MSF.IsPublished=1';	

	SET @SQL_STEWARD_ORGANIZATION_MSF_LEFT_JOIN = '';
	IF (LEN ( @StewardList ) > 0)
	BEGIN
		SET @SQL_WHERE = @SQL_WHERE + ' AND STEWARD_ORGANIZATION_MSF.STEWARD_ID IN ( ' + @StewardList + ')';
		SET @SQL_STEWARD_ORGANIZATION_MSF_LEFT_JOIN = 'LEFT OUTER JOIN STEWARD_ORGANIZATION_MSF ON STEWARD_ORGANIZATION_MSF.SUBMISSION_ID = MSF.ID';
	END 

	SET @SQL_NPP_AERAS_JOIN = '';
	IF (LEN ( @NPPAreas ) > 0)
	BEGIN
		--SET @SQL_WHERE = @SQL_WHERE + ' AND STEWARD_ORGANIZATION_MSF.STEWARD_ID IN ( ' + @StewardList + ')';
		SET @SQL_NPP_AERAS_JOIN = 'INNER JOIN ( SELECT DISTINCT MeasureID FROM MSF_MEASURE_TAXONOMY WHERE SubTaxonomyID IN ( ' + @NPPAreas + ' ) ) AS MSF_TAX_NPP ON MSF_TAX_NPP.MeasureID = MSF.ID';
	END 

	SET @SQL_CONDITIONS_JOIN = '';
	IF (LEN ( @Conditions ) > 0)
	BEGIN
		--SET @SQL_WHERE = @SQL_WHERE + ' AND STEWARD_ORGANIZATION_MSF.STEWARD_ID IN ( ' + @StewardList + ')';
		SET @SQL_CONDITIONS_JOIN = 'INNER JOIN ( SELECT DISTINCT MeasureID FROM MSF_MEASURE_TAXONOMY WHERE SubTaxonomyID IN ( ' + @Conditions + ' ) ) AS MSF_TAX_CON ON MSF_TAX_CON.MeasureID = MSF.ID';
	END 

	/*End of Condition portion*/

	/*Start of order By portion*/
	SELECT @SQL_ORDER_BY = CASE @SortField 
							WHEN 'measurenumber' THEN 'MSF.ID ASC'
							WHEN 'date' THEN 'MSF.DTS DESC'
							WHEN 'title' THEN 'dbo.HtmlDecode ( ISNULL(MSF.XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(256)''),'''')) ASC'
							WHEN 'steward' THEN 'dbo.HtmlDecode ( ISNULL(MSF.XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureSteward/MeasureStewardOrganization/text())[1]'', ''varchar(500)''),'''')) ASC'
							ELSE 'MSF.ID ASC'
						   END;
	
	/*End of order By portion*/

	/*Start of Select portion*/
	SET @SQL = 
	'SELECT * FROM
	(
		SELECT MSF.ID
		, dbo.HtmlDecode ( ISNULL(MSF.XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(256)''),'''')) as Title
		, dbo.HtmlDecode ( ISNULL(MSF.XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureSteward/MeasureStewardOrganization/text())[1]'', ''varchar(500)''),'''')) as stewards
		, CommentCount = ( SELECT COUNT (MeasureID) FROM MEASURE_COMMENTS WHERE MeasureID = MSF.ID )
		, ROW_NUMBER() OVER (ORDER BY ' + @SQL_ORDER_BY + ' ) as RowNum 
		FROM MSF_SUBMISSIONS MSF		
		'+ @SQL_STEWARD_ORGANIZATION_MSF_LEFT_JOIN + '
		'+ @SQL_NPP_AERAS_JOIN + '
		'+ @SQL_CONDITIONS_JOIN + '
		'+ @SQL_WHERE +	'
		
	)
	AS Submission
	WHERE RowNum BETWEEN ' + CAST(@startRowIndex  AS varchar) + ' AND '+ CAST(@endRowIndex AS varchar)+' 	
	--FOR XML AUTO, ROOT(''Submissions''), ELEMENTS;


	SELECT COUNT(MSF.ID) TotalCount FROM MSF_SUBMISSIONS MSF
	'+ @SQL_STEWARD_ORGANIZATION_MSF_LEFT_JOIN + '
	'+ @SQL_NPP_AERAS_JOIN + '
	'+ @SQL_CONDITIONS_JOIN + '
	'+ @SQL_WHERE +	';'	
	/*End of Select portion*/


	PRINT @SQL;
	EXEC (@SQL);

END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_STANDARD_MEASURE_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_STANDARD_MEASURE_LIST.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_STANDARD_MEASURE_LIST.';
END
GO
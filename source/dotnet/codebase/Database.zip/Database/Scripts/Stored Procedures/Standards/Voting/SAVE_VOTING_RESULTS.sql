SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_VOTING_RESULTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_VOTING_RESULTS.';
	DROP PROCEDURE SAVE_VOTING_RESULTS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_VOTING_RESULTS
 * --Purpose/Function		: Saves a Results object
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/02/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/02/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_VOTING_RESULTS(
	@VoteResultID BIGINT
	, @VotingResultOrganizerID BIGINT
	, @ProjectID BIGINT
	, @ActivityID BIGINT
	, @MeasureID BIGINT
	, @VoterIMISUserID VARCHAR(11)
	, @VoteUserInfoID UNIQUEIDENTIFIER
	, @VotingDate DATETIME
	, @Result VARCHAR(255)
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.VOTING_RESULTS WHERE VoteResultID = @VoteResultID)
	BEGIN
		-- Update Existing Results Information
		UPDATE dbo.VOTING_RESULTS SET
			VotingResultOrganizerID = @VotingResultOrganizerID
			, ProjectID = @ProjectID
			, ActivityID = @ActivityID
			, MeasureID = @MeasureID
			, VoterIMISUserID = @VoterIMISUserID
			, VoteUserInfoID = @VoteUserInfoID
			, VotingDate = @VotingDate
			, Result = @Result
		WHERE VoteResultID = @VoteResultID;
		SET @GeneratedID = @VoteResultID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.VOTING_RESULTS
		INSERT INTO dbo.VOTING_RESULTS (VotingResultOrganizerID
			, ProjectID
			, ActivityID
			, MeasureID
			, VoterIMISUserID
			, VoteUserInfoID
			, VotingDate
			, Result)
		VALUES(@VotingResultOrganizerID
			, @ProjectID
			, @ActivityID
			, @MeasureID
			, @VoterIMISUserID
			, @VoteUserInfoID
			, @VotingDate
			, @Result);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_VOTING_RESULTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_VOTING_RESULTS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_VOTING_RESULTS.';
END
GO
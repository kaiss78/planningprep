SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_MSF_FORWARD_MEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_MSF_FORWARD_MEASURE.';
	DROP PROCEDURE SAVE_MSF_FORWARD_MEASURE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_MSF_FORWARD_MEASURE
 * --Purpose/Function		: Saves a ForwardMeasure object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 12/13/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/13/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_MSF_FORWARD_MEASURE(
	@ForwardID BIGINT
	, @MsfStatusChangeID BIGINT
	, @CommitteeID BIGINT
	, @MemberID BIGINT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.MSF_FORWARD_MEASURE WHERE ForwardID = @ForwardID)
	BEGIN
		-- Update Existing ForwardMeasure Information
		UPDATE dbo.MSF_FORWARD_MEASURE SET
			MsfStatusChangeID = @MsfStatusChangeID
			, CommitteeID = @CommitteeID
			, MemberID = @MemberID
		WHERE ForwardID = @ForwardID;
		SET @GeneratedID = @ForwardID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.MSF_FORWARD_MEASURE
		INSERT INTO dbo.MSF_FORWARD_MEASURE (MsfStatusChangeID
			, CommitteeID
			, MemberID)
		VALUES(@MsfStatusChangeID
			, @CommitteeID
			, @MemberID);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_MSF_FORWARD_MEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_MSF_FORWARD_MEASURE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_MSF_FORWARD_MEASURE.';
END
GO

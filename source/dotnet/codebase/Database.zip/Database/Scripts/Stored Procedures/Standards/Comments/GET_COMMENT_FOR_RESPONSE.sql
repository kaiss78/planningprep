SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_FOR_RESPONSE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMENT_FOR_RESPONSE.';
	DROP PROCEDURE GET_COMMENT_FOR_RESPONSE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMMENT_FOR_RESPONSE
 * --Purpose/Function		: Gets Type objects by ID
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 01/19/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/19/2010		MHA		Initial Development				
 * 01/21/2010		WM		Changed for Ordering
 * ===================================================================*/
---exec GET_COMMENT_FOR_RESPONSE 57
-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
-- GET_COMMENT_FOR_RESPONSE 163
CREATE PROCEDURE GET_COMMENT_FOR_RESPONSE
(
 @CommentID BIGINT
)
AS
BEGIN

DECLARE @IsGroupedComment BIT
DECLARE @GroupID BIGINT
DECLARE @IsTop BIT

SELECT @GroupID = GroupID, @IsTop = IsTop FROM MEASURE_COMMENTS WHERE CommentID=@CommentID

IF @GroupID > 0 AND @IsTop = 1
BEGIN
 SET @IsGroupedComment =1
END
ELSE
BEGIN
 SET @IsGroupedComment =0
END



DECLARE @DYNAMIC_SQL VARCHAR(2500)

SET @DYNAMIC_SQL = '
SELECT comments.COMMENT,
       project.ShortName ProjectName,
       Isnull(msf.xml_data.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(256)''), '''') AS MeasureTitle,                
       on_behalf.firstname      onbehalffirstname,
       on_behalf.lastname       onbehalflastname,
       on_behalf.organization   onbehalforganization,
       on_behalf.email          onbehalfemail,
       on_behalf.phoneno        onbehalfphoneno,
       on_behalf.primarycouncil onbehalfprimarycouncil,
       usr.firstname            commenterfirstname,
       usr.lastname             commenterlastname,
       usr.institutename        commenterorganization,
       usr.email                commenteremail,
       usr.work_phone           commenterphoneno,
       usr.primarycouncil       commenterprimarycouncil,
       (SELECT TOP 1 staffnotes
        FROM   staff_notes_on_comments
        WHERE  commentid = '+ CAST(@CommentID AS VARCHAR)+'
        ORDER  BY dts DESC)     staffnotes,
		comments.IsTop,
		comments.DTS
FROM   measure_comments comments
       INNER JOIN IMIS_USER_DETAILS usr
         ON usr.imisuserid = Convert(VARCHAR(10), comments.submitterimisuserid)      
       INNER JOIN OPLM_PROJECT_PRIMARY_DATA project
         ON comments.ProjectID = project.ProjectID
       INNER JOIN MSF_SUBMISSIONS msf
         on comments.MeasureID = msf.ID
       LEFT JOIN comment_on_behalf_of_information on_behalf
         ON comments.onbehalfid = on_behalf.id'


IF @IsGroupedComment =1
BEGIN
  -- @#$@#$@#$ @#$@#$@#$ @#$@#$@#$  G R O U P E D   C O M M E N T S   B E G I N S @#$@#$@#$ @#$@#$@#$ @#$@#$@#$ @#$@#$@#$ 

SET @DYNAMIC_SQL = @DYNAMIC_SQL+ ' WHERE msf.IsDeleted=0 AND comments.groupid = '+ CAST(@GroupID AS VARCHAR)  


  -- @#$@#$@#$ @#$@#$@#$ @#$@#$@#$  G R O U P E D   C O M M E N T S   E N D S @#$@#$@#$ @#$@#$@#$ @#$@#$@#$ @#$@#$@#$ 
END
ELSE
BEGIN
 -- !^!=!^!=!^!=  ^!=!^!=!^!= S I N G L E    C O M M E N T S    B E G I N S ^!=!^!=!^!=   ^!=!^!=!^!=   ^!=!^!=!^!= 


SET @DYNAMIC_SQL = @DYNAMIC_SQL+ ' WHERE msf.IsDeleted=0 AND comments.commentid = '+ CAST(@CommentID AS VARCHAR)

-- !^!=!^!=!^!=  ^!=!^!=!^!= S I N G L E    C O M M E N T S    E N D S ^!=!^!=!^!=   ^!=!^!=!^!=   ^!=!^!=!^!= 

END

SET @DYNAMIC_SQL = @DYNAMIC_SQL + ' ORDER BY IsTop DESC, DTS DESC'

EXEC(@DYNAMIC_SQL)
PRINT(@DYNAMIC_SQL)


END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_FOR_RESPONSE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMENT_FOR_RESPONSE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMENT_FOR_RESPONSE.';
END
GO
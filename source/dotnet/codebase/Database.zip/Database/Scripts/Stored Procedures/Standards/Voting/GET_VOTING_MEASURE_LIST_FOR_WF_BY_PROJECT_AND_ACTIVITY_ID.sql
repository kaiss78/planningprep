
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID.';
	DROP PROCEDURE GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID
 * --Purpose/Function		: Saves a MeasureList object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 01/31/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/31/2010		MHR		Initial Development				
 * ===================================================================*/
--exec [GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID] 45,3
-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID](
	@ProjectID BIGINT,
    @ActivityID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	DECLARE @MemberVotingStatus AS BIGINT
	SET @MemberVotingStatus =18
	DECLARE @CurrentStatus AS VARCHAR(20)
	SET @CurrentStatus='Member Voting'

		BEGIN
			SELECT MS.ID as MeasureID
			FROM dbo.VOTING_MEASURE_LIST VML
			INNER JOIN dbo.MSF_SUBMISSIONS MS ON VML.MeasureID=MS.ID
			WHERE MS.StatusSubmitted=@MemberVotingStatus
				AND VML.ProjectID = @ProjectID
				AND VML.ActivityID = @ActivityID
				AND MS.CurrentStatus<>@CurrentStatus	
		END

	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_VOTING_MEASURE_LIST_FOR_WF_BY_PROJECT_AND_ACTIVITY_ID.';
END
GO
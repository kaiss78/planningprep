
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Save_VOTING_MEASURE_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure Save_VOTING_MEASURE_LIST.';
	DROP PROCEDURE Save_VOTING_MEASURE_LIST;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: Save_VOTING_MEASURE_LIST
 * --Purpose/Function		: Saves a MeasureList object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 01/31/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/31/2010		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.Save_VOTING_MEASURE_LIST(
	@VotingMeasureID BIGINT
	, @ProjectID BIGINT
	, @MeasureID BIGINT
	, @MeasureTitle VARCHAR(500)
	, @IsCommentingAllowed BIT
	, @SortOrder BIGINT
	, @XmlData xml
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	BEGIN

	/*****  Getting Inserted datarow ********************/
	SELECT  dsData.ROW.value('@ProjectID','bigint') as [ProjectID], 
			dsData.ROW.value('@MeasureID','bigint') as [MeasureID],
			dsData.ROW.value('@MeasureTitle','Varchar(500)') as [MeasureTitle],
			dsData.ROW.value('@IsCommentingAllowed','bit') as [IsCommentingAllowed],
			dsData.ROW.value('@SortOrder','int') as [SortOrder]			
	INTO #VotingMeasureListInsert
			FROM @XmlData.nodes('/dsData/InsertData') dsData(ROW)


	/*****  Getting Updatedatarow ********************/
	SELECT  dsData.ROW.value('@ProjectID','bigint') as [ProjectID], 
			dsData.ROW.value('@MeasureID','bigint') as [MeasureID],
			dsData.ROW.value('@MeasureTitle','Varchar(500)') as [MeasureTitle],
			dsData.ROW.value('@IsCommentingAllowed','bit') as [IsCommentingAllowed],
			dsData.ROW.value('@SortOrder','int') as [SortOrder]			
	INTO #VotingMeasureListUpdate
			FROM @XmlData.nodes('/dsData/UpdateData') dsData(ROW)
		
	/*****  Getting deletedatarow ********************/
	SELECT dsDiagrams.ROW.value('@VotingMeasureID','int') as [VotingMeasureID],	
            dsData.ROW.value('@ProjectID','bigint') as [ProjectID], 
			dsData.ROW.value('@MeasureID','bigint') as [MeasureID],
			dsData.ROW.value('@MeasureTitle','Varchar(500)') as [MeasureTitle],
			dsData.ROW.value('@IsCommentingAllowed','bit') as [IsCommentingAllowed],
			dsData.ROW.value('@SortOrder','int') as [SortOrder]			
	INTO #VotingMeasureListDelete
		FROM @XmlData.nodes('/dsData/DeleteData') dsDiagrams(ROW)

	/*****  insert********************/
	INSERT INTO  VOTING_MEASURE_LIST
			(  ProjectID, MeasureID, MeasureTitle, IsCommentingAllowed, SortOrder)
			SELECT  
				 I.ProjectID
				,I.MeasureID
				,I.MeasureTitle
				,I.IsCommentingAllowed
				,I.SortOrder
			FROM 	#VotingMeasureListInsert I

	/*****  update********************/
	UPDATE VOTING_MEASURE_LIST
			SET
			 ProjectID=U.ProjectID
			,MeasureID=U.MeasureID 
			,MeasureTitle=U.MeasureTitle
			,IsCommentingAllowed=U.IsCommentingAllowed
			,SortOrder=U.SortOrder
					
		FROM 	#VotingMeasureListUpdate U  
		WHERE FI_FinancingDetail.FinancingDetailID=U.FinancingDetailID

	/*****  Delete********************/
		DELETE 	FROM VOTING_MEASURE_LIST 
		 	WHERE 	VOTING_MEASURE_LIST.VotingMeasureID IN(SELECT VotingMeasureID FROM #VotingMeasureListDelete)

    
      --------------------UPDATE STATUS TO VOTING-----------------
    DECLARE @PROJECT_ID 									BIGINT
	DECLARE @MEASURE_ID 									BIGINT
	DECLARE @MEASURE_TITLE 									VARCHAR (500)
	DECLARE @HITORY_DATA_TYPE_NAME							VARCHAR (500)
	DECLARE @STATUS_CHANGE_ID 								BIGINT
	DECLARE @HISTORY_ID	 									BIGINT
	DECLARE @NOTE_ID	 									BIGINT
	DECLARE @NOTE_TYPE_ID 									BIGINT
	
	DECLARE @MEMBER_VOTING_STATUS 	INT
    DECLARE @PREVIOUS_STATUS VARCHAR (500)


	SET  @NOTE_TYPE_ID = 3	
	SET  @MEMBER_VOTING_STATUS = 18


    DECLARE MEASURE_CURSOR CURSOR FOR 
       SELECT measureid,
              projectid,
              measuretitle
       FROM   #VotingMeasureListInsert
       
       

 
	OPEN MEASURE_CURSOR
		
	FETCH NEXT FROM MEASURE_CURSOR INTO @MEASURE_ID, @PROJECT_ID, @MEASURE_TITLE
	WHILE @@FETCH_STATUS = 0
	BEGIN
         
         SELECT @PREVIOUS_STATUS = mss.submission_status_name
		 FROM   msf_submissions ms
				INNER JOIN msf_submission_status mss
				  ON ms.statussubmitted = mss.submission_status_id
		 WHERE  ms.id = @MEASURE_ID 
		--Give entry for status change
		EXEC MSF_SAVE_CHANGE_STATUS 0, @MEASURE_ID, @MEMBER_VOTING_STATUS, NULL, @STATUS_CHANGE_ID OUTPUT; 
		
		--Update measure status
		EXEC NQF_UPDATE_MSF_ITEM_STATUS @MEASURE_ID, @MEMBER_VOTING_STATUS;

		--Add note for status change
		EXEC MSF_ADD_NOTES 'Status Updated Voting Process', @STATUS_CHANGE_ID, @MEMBER_VOTING_STATUS, 0, @NOTE_TYPE_ID, @NOTE_ID OUTPUT;
		
		--Add to history data
		SET @HITORY_DATA_TYPE_NAME = 'Measure Status (' + @MEASURE_TITLE + ')';
		EXEC OPLM_CREATE_HISTORY_DATA @PROJECT_ID, @HITORY_DATA_TYPE_NAME, 15, 'Status', 3, @PREVIOUS_STATUS,'Member Voting', 0, NULL, '', 'System', @MEASURE_ID, @MEASURE_TITLE, NULL, @HISTORY_ID OUTPUT

	FETCH NEXT FROM MEASURE_CURSOR INTO @MEASURE_ID, @PROJECT_ID, @MEASURE_TITLE
	END
	CLOSE MEASURE_CURSOR
	DEALLOCATE MEASURE_CURSOR
    ------------------- UPDATE STATUS TO VOTING-----------------



		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'Save_VOTING_MEASURE_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure Save_VOTING_MEASURE_LIST created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure Save_VOTING_MEASURE_LIST.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_STAFF_NOTES_ON_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_STAFF_NOTES_ON_COMMENTS.';
	DROP PROCEDURE SAVE_STAFF_NOTES_ON_COMMENTS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_STAFF_NOTES_ON_COMMENTS
 * --Purpose/Function		: Saves a NotesOnComments object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 01/19/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/19/2010		MR		Initial Development				
 * ===================================================================
 * Date				Name	Comments
 * 01/31/2010		MR		Updated due to change of final response
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_STAFF_NOTES_ON_COMMENTS(
	@StaffNoteID BIGINT
	, @StaffNotes NVARCHAR(MAX)
	, @IsFinalRemark BIT
	, @CommentID BIGINT
	, @OPLMUSERID BIGINT
	, @FinalResponseOPLMUserID BIGINT
	, @FinalRemark NVARCHAR(MAX)
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.STAFF_NOTES_ON_COMMENTS WHERE StaffNoteID = @StaffNoteID)
	BEGIN
		-- Update Existing NotesOnComments Information
		UPDATE dbo.STAFF_NOTES_ON_COMMENTS SET
			StaffNotes = @StaffNotes
			, IsFinalRemark = @IsFinalRemark
			, FinalRemark = @FinalRemark
			, CommentID = @CommentID
			, OPLMUSERID = @OPLMUSERID
			, FinalResponseOPLMUserID = @FinalResponseOPLMUserID
			, DTS = GETDATE()--@DTS
		WHERE StaffNoteID = @StaffNoteID;
		SET @GeneratedID = @StaffNoteID;		
	END
	ELSE IF EXISTS(SELECT * FROM dbo.STAFF_NOTES_ON_COMMENTS WHERE CommentID = @CommentID)
	BEGIN
		-- Update Existing NotesOnComments Information
		UPDATE dbo.STAFF_NOTES_ON_COMMENTS SET
			StaffNotes = @StaffNotes
			, OPLMUSERID = @OPLMUSERID
			, DTS = GETDATE()--@DTS
		WHERE CommentID = @CommentID;
		SET @GeneratedID = @StaffNoteID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.STAFF_NOTES_ON_COMMENTS
		INSERT INTO dbo.STAFF_NOTES_ON_COMMENTS (StaffNotes
			, IsFinalRemark
			, CommentID
			, OPLMUSERID
			, FinalResponseOPLMUserID
			, DTS
			, FinalRemark)
		VALUES(@StaffNotes
			, @IsFinalRemark
			, @CommentID
			, @OPLMUSERID
			, @FinalResponseOPLMUserID
			, GETDATE()
			, @FinalRemark);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_STAFF_NOTES_ON_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_STAFF_NOTES_ON_COMMENTS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_STAFF_NOTES_ON_COMMENTS.';
END
GO

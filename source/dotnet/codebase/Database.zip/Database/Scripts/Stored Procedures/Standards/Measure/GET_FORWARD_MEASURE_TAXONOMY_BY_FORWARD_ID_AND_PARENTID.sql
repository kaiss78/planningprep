SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID.';
	DROP PROCEDURE GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID
 * --Purpose/Function		: Gets ForwardMeasure Taxonomy objects by Forward ID and Parent Taxonomy ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 12/17/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/17/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID(
	@MeasureID BIGINT
	, @taxonomyID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT ID
		, MeasureID
		, MSF_SUB_TAXONOMY.SubTaxonomyID
		, MSF_SUB_TAXONOMY.SubTaxonomyName
	FROM dbo.MSF_MEASURE_TAXONOMY
	INNER JOIN MSF_SUB_TAXONOMY 
		ON MSF_MEASURE_TAXONOMY.SubTaxonomyID = MSF_SUB_TAXONOMY.SubTaxonomyID
	WHERE
		MeasureID = @MeasureID
		AND MSF_SUB_TAXONOMY.TaxonomyID = @taxonomyID
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_FORWARD_MEASURE_TAXONOMY_BY_FORWARD_ID_AND_PARENTID.';
END
GO

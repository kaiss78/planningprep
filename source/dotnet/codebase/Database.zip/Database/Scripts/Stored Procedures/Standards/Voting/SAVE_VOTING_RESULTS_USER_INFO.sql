SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_VOTING_RESULTS_USER_INFO'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_VOTING_RESULTS_USER_INFO.';
	DROP PROCEDURE SAVE_VOTING_RESULTS_USER_INFO;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_VOTING_RESULTS_USER_INFO
 * --Purpose/Function		: Saves a ResultsUserInfo object
 * --Author					: HA
 * --Start Date(MM/DD/YY)	: 02/01/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/01/2010		HA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_VOTING_RESULTS_USER_INFO(
	@UserInfoID UNIQUEIDENTIFIER
	, @VotingResultOrganizerID BIGINT
	, @IMISUserID VARCHAR(11)
	, @FirstName VARCHAR(255)
	, @LastName VARCHAR(255)
	, @OrganizationID VARCHAR(50)
	, @Organization VARCHAR(500)
	, @CouncilID VARCHAR(255)
	, @Council VARCHAR(500)
	, @UserInfoFor TINYINT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.VOTING_RESULTS_USER_INFO WHERE UserInfoID = @UserInfoID)
	BEGIN
		-- Update Existing ResultsUserInfo Information
		UPDATE dbo.VOTING_RESULTS_USER_INFO SET
			VotingResultOrganizerID = @VotingResultOrganizerID
			, IMISUserID = @IMISUserID
			, FirstName = @FirstName
			, LastName = @LastName
			, OrganizationID = @OrganizationID
			, Organization = @Organization
			, CouncilID = @CouncilID
			, Council = @Council
			, UserInfoFor = @UserInfoFor
		WHERE UserInfoID = @UserInfoID;
		--SET @GeneratedID = @UserInfoID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.VOTING_RESULTS_USER_INFO
		INSERT INTO dbo.VOTING_RESULTS_USER_INFO (
			 UserInfoID 
			, VotingResultOrganizerID
			, IMISUserID
			, FirstName
			, LastName
			, OrganizationID
			, Organization
			, CouncilID
			, Council
			, UserInfoFor)
		VALUES(
			 @UserInfoID
			, @VotingResultOrganizerID
			, @IMISUserID
			, @FirstName
			, @LastName
			, @OrganizationID
			, @Organization
			, @CouncilID
			, @Council
			, @UserInfoFor);
		--SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_VOTING_RESULTS_USER_INFO'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_VOTING_RESULTS_USER_INFO created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_VOTING_RESULTS_USER_INFO.';
END
GO
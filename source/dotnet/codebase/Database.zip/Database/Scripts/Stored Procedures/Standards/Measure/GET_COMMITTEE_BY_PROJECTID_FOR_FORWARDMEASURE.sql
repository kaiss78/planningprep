SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE.';
	DROP PROCEDURE GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPLM
 * --Procedure name			: GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE
 * --Purpose/Function		: Gets Document objects by related with provided project id
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 10/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/13/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE(
	@ProjectID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
    C.CommitteeID,
    C.CommitteeTypeID,
    C.ProjectID,
    C.CommitteeName,
    C.ProjectStepIDForCommenting,
    C.ProjectStepIDForNominationPeriod,
    C.CreateWebLink,
    C.MeetingStartDate,
    C.MeetingEndDate,
    C.Background,
    C.iMISCode,
	C.IsActive,
    T.CommitteeType
		FROM dbo.COMMITTEE C
			INNER JOIN COMMITTEE_TYPE T ON C.CommitteeTypeID = T.CommitteeTypeID
	WHERE ProjectID = @ProjectID
	AND CommitteeID IN(SELECT CommitteeID FROM COMMITTEE_MEETING_DATES WHERE CMeetingDate>getdate())
	AND IsActive='true'
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMITTEE_BY_PROJECTID_FOR_FORWARDMEASURE.';
END
GO
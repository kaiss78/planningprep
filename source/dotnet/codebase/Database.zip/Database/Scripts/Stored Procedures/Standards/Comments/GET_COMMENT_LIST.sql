SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMENT_LIST.';
	DROP PROCEDURE GET_COMMENT_LIST;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMMENT_LIST
 * --Purpose/Function		: GET COMMENT LIST
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 01/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/13/2010		SR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_COMMENT_LIST](
	@ProjectID BIGINT,
	@FromDate VARCHAR(20),
	@ToDate VARCHAR(20),
	@SubmitterIDList VARCHAR(1000),
	@SubmitterOrganizationList VARCHAR(1000),
	@CommentingPeriodList VARCHAR(1000),
	@TypeOfCommentList VARCHAR(1000),
	@CommentByList VARCHAR(1000),
	@MeasureIDList VARCHAR(1000),
	@CommentStatusList VARCHAR(1000),
	@OrderBy VARCHAR(200),
	@OrderType VARCHAR(20)
)
AS
BEGIN

-- Declare variables
DECLARE @Sqry VARCHAR(MAX)
DECLARE @SubmitterIDString VARCHAR(1000)
DECLARE @SubmitterOrganizationString VARCHAR(1000)
DECLARE @CommentingPeriodString VARCHAR(1000)
DECLARE @TypeOfCommentString VARCHAR(1000)
DECLARE @CommentByString VARCHAR(1000)
DECLARE @MeasureIDString VARCHAR(1000)
DECLARE @CommentStatusString VARCHAR(1000)

-- Set sorting condition 
IF @OrderBy = 'DATE'
BEGIN
	SET @OrderBy = 'DateSubmitted'
END
ELSE IF @OrderBy = 'ONBEHALFOFORGANIZATION'
BEGIN
	SET @OrderBy = 'OnBehalfOrganization'
END
ELSE IF @OrderBy = 'ONBEHALFOFPRIMARYCOUNCIL'
BEGIN
	SET @OrderBy = 'OnBehalfMemberCouncil'
END
ELSE
BEGIN
	SET @OrderBy = 'DateSubmitted'
END

-- Set filtering condition
IF @FromDate = ''
BEGIN
	SET @FromDate = '01/01/1900'
END

IF @ToDate = ''
BEGIN
	SET @ToDate = '01/01/2099'
END

DECLARE @SubmitterID VARCHAR (1000)
SET @SubmitterID = 'select SubmitterID from VW_COMMENT_LIST '
SET @SubmitterIDString = ''
IF @SubmitterIDList <> ''
BEGIN
	SET @SubmitterIDString = 'and SubmitterID in (' + @SubmitterIDList + ')'
END

DECLARE @SubmitterOrganization VARCHAR (1000)
SET @SubmitterOrganization = 'select SubmitterOrganization from VW_COMMENT_LIST '
SET @SubmitterOrganizationString = ''
IF @SubmitterOrganizationList <> ''
BEGIN
	DECLARE @SplitSubmitterOrganization VARCHAR (1000)
	SET @SplitSubmitterOrganization = 'select id from dbo.SplitId ('''+@SubmitterOrganizationList+''','','')'
	SET @SubmitterOrganizationString = 'and SubmitterOrganization in (' + @SplitSubmitterOrganization + ')'
END

DECLARE @CommentingPeriod VARCHAR (1000)
SET @CommentingPeriod = 'select CommentingPeriod from VW_COMMENT_LIST '
SET @CommentingPeriodString = ''
IF @CommentingPeriodList <> ''
BEGIN
	SET @CommentingPeriodString = 'and CommentingPeriod in (' + @CommentingPeriodList + ')'
END

DECLARE @TypeOfComment VARCHAR (1000)
SET @TypeOfComment = 'select CommentType from VW_COMMENT_LIST '
SET @TypeOfCommentString = ''
IF @TypeOfCommentList <> ''
BEGIN
	SET @TypeOfCommentString = 'and CommentType in (' + @TypeOfCommentList + ')'
END

DECLARE @CommentBy VARCHAR (1000)
SET @CommentBy = 'select CommentBy from VW_COMMENT_LIST '
SET @CommentByString = ''
IF @CommentByList <> ''
BEGIN
	SET @CommentByString = 'and CommentBy in (' + @CommentByList + ')'
END

DECLARE @MeasureID VARCHAR (1000)
SET @MeasureID = 'select MeasureID from VW_COMMENT_LIST '
SET @MeasureIDString = ''
IF @MeasureIDList <> ''
BEGIN
	SET @MeasureIDString = 'and MeasureID in (' + @MeasureIDList + ')'
END

SET @CommentStatusString = ''
IF @CommentStatusList <> ''
BEGIN
	IF @CommentStatusList = '2'
	BEGIN
		SET @CommentStatusString = 'and CommentStatus in (' + @CommentStatusList + ')'
	END
	ELSE
	BEGIN
		SET @CommentStatusString = 'and CommentStatus in (' + @CommentStatusList + ') and IsFinalRemark = 0 '
	END
END

-- Main query
SET @Sqry = 
'SELECT 
	v1.ProjectID
	,v1.CommentID
	,v1.CommentType
	,v1.CommentStatus
	,v1.MeasureID
	,v1.MeasureTitle
	,v1.DateSubmitted
	,v1.CommentByName
	,v1.CommentByOrganization
	,v1.CommentByMemberCouncil
	,v1.CommentByEmail
	,v1.Comment
	,v1.OnBehalfName
	,v1.OnBehalfOrganization
	,v1.OnBehalfMemberCouncil
	,v1.OnBehalfEmail
	,v1.IsMemberComment
	,v1.IsFinalRemark
	,v1.GroupID
	,v1.IsTop 

FROM
	VW_COMMENT_LIST v1 

WHERE
	(CAST(CONVERT(VARCHAR(20), DATESUBMITTED, 101) AS DATETIME) >= ''' + @FromDate + ''') 
	and (CAST(CONVERT(VARCHAR(20), DATESUBMITTED, 101) AS DATETIME) <= ''' + @ToDate + ''')
	' + @SubmitterIDString + '
	' + @SubmitterOrganizationString + '
	' + @CommentingPeriodString + '
	' + @TypeOfCommentString + '
	' + @CommentByString + '
	' + @MeasureIDString + '
	' + @CommentStatusString + '
	and v1.GroupID = 0
	and v1.ProjectID = ' + Cast(@ProjectID as varchar(100)) + '

UNION ALL

SELECT
	v1.ProjectID
	,v1.CommentID
	,v1.CommentType
	,v1.CommentStatus
	,v1.MeasureID
	,v1.MeasureTitle
	,v1.DateSubmitted
	,v1.CommentByName
	,v1.CommentByOrganization
	,v1.CommentByMemberCouncil
	,v1.CommentByEmail
	,v1.Comment
	,v1.OnBehalfName
	,v1.OnBehalfOrganization
	,v1.OnBehalfMemberCouncil
	,v1.OnBehalfEmail
	,v1.IsMemberComment
	,v1.IsFinalRemark
	,v1.GroupID
	,v1.IsTop 

FROM
	VW_COMMENT_LIST v1 

INNER JOIN
(
SELECT
	DISTINCT v2.GroupID

FROM 
	VW_COMMENT_LIST v2

WHERE
	(CAST(CONVERT(VARCHAR(20), DATESUBMITTED, 101) AS DATETIME) >= ''' + @FromDate + ''') 
	and (CAST(CONVERT(VARCHAR(20), DATESUBMITTED, 101) AS DATETIME) <= ''' + @ToDate + ''')
	' + @SubmitterIDString + '
	' + @SubmitterOrganizationString + '
	' + @CommentingPeriodString + '
	' + @TypeOfCommentString + '
	' + @CommentByString + '
	' + @MeasureIDString + '
	' + @CommentStatusString + '
	and v2.ProjectID = ' + Cast(@ProjectID as varchar(100)) + '
)v2

ON
	v1.GroupID = v2.GroupID

WHERE
	v2.GroupID <> 0

ORDER BY IsTop DESC, ' + @OrderBy + ' ' + @OrderType +'
'

print(@Sqry)
EXEC(@Sqry)

-- select * from VW_COMMENT_LIST 

-- EXEC GET_COMMENT_LIST 39, '01/11/2010', '01/12/2010', '112218, 112216', 'NQF TEST,BBB,CCC', '229, 123', '1,2,3', '112202, 112204', '62, 60', 'ONBEHALFOFORGANIZATION', 'DESC'
-- EXEC GET_COMMENT_LIST 39, '', '', '', '', '', '', '', '', '1,2,3', 'DATE', 'DESC'
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMENT_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMENT_LIST created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMENT_LIST.';
END
GO
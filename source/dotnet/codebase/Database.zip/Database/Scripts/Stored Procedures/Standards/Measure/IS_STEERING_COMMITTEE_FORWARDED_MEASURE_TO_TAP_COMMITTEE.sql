SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE.';
	DROP PROCEDURE IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE
 * --Purpose/Function		: Gets ProjectDocument objects by ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 12/24/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/24/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE]
(
 @MeasureID BIGINT
 , @PreveiousStatusID TINYINT
 , @ChangedStatusID TINYINT
 , @IsExists BIT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;

IF EXISTS(SELECT *
          FROM
			MSF_STATUS_CHANGE
          WHERE  
				PreveiousStatus = @PreveiousStatusID
                AND ChangedStatus = @ChangedStatusID
				AND MeasureID = @MeasureID)
  BEGIN
      SET @IsExists = 1
  END
ELSE
  BEGIN
      SET @IsExists = 0
  END 

END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IS_STEERING_COMMITTEE_FORWARDED_MEASURE_TO_TAP_COMMITTEE.';
END
GO
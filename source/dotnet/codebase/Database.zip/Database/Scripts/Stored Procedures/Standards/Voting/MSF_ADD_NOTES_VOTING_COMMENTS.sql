SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'MSF_ADD_NOTES_VOTING_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure MSF_ADD_NOTES_VOTING_COMMENTS.';
	DROP PROCEDURE MSF_ADD_NOTES_VOTING_COMMENTS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: MSF_ADD_NOTES_VOTING_COMMENTS
 * --Purpose/Function		: ADD MSF NOTES
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 12/09/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/09/2009		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--EXEC MSF_ADD_NOTES_VOTING_COMMENTS 23, '111134', 'ASDF','1/1/1', 4, 3
CREATE PROCEDURE [dbo].[MSF_ADD_NOTES_VOTING_COMMENTS]
	 @MeasureID bigint
	, @IMISUserID bigint
	, @Note varchar(MAX)
	, @NoteDate	DATETIME
	, @NoteTypeID bigint
	, @VotingResultOrganizerID BIGINT
	, @UserInfoID UNIQUEIDENTIFIER
	, @GeneratedID INT OUTPUT
AS
BEGIN
	DECLARE @GeneratedStatusChangeID BIGINT
		, @PreveiousStatus int
		, @ChangedStatus int;

	SELECT @PreveiousStatus = StatusSubmitted FROM MSF_SUBMISSIONS WHERE ID = @MeasureID
	SET @ChangedStatus = @PreveiousStatus;

	INSERT INTO dbo.MSF_STATUS_CHANGE (MeasureID
		, PreveiousStatus
		, ChangedStatus
		, OPLMIMISUserID
		, DTS)
	VALUES(@MeasureID
		, @PreveiousStatus
		, @ChangedStatus
		, @IMISUserID
		, GETDATE());
	SET @GeneratedStatusChangeID = SCOPE_IDENTITY();		


	INSERT INTO [dbo].[MSF_NOTES]
           ( [Note]
           , [NoteFor] 
		   , MsfStatusChangeID
		   , DTS
           , [NoteTypeID]
			,IsAdhoc)
     VALUES
           (@Note
			, @ChangedStatus
			, @GeneratedStatusChangeID
			, @NoteDate         
			, @NoteTypeID
			, 0)
	SET @GeneratedID = SCOPE_IDENTITY();


	INSERT INTO dbo.VOTING_COMMENTS_RELATIONS (NoteID
			, UserInfoID
			, VotingResultOrganizerID
			, MsfStatusChangeID)
		VALUES(@GeneratedID
			, @UserInfoID
			, @VotingResultOrganizerID
			, @GeneratedStatusChangeID);
END
GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'MSF_ADD_NOTES_VOTING_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure MSF_ADD_NOTES_VOTING_COMMENTS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure MSF_ADD_NOTES_VOTING_COMMENTS.';
END
GO

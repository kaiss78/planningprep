SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURE_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_MEASURE_LIST.';
	DROP PROCEDURE GET_MEASURE_LIST;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_MEASURE_LIST
 * --Purpose/Function		: GET THE MEASURE LISTING PAGE
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 12/10/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/10/2009		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_MEASURE_LIST	
	@ProjectID bigint = 1029,
	@StatusList varchar(500) = '',
	@CommentingPeriodList varchar(500) = '',
	@SubmissionPeriodList varchar(500) = '',
	@CommitteeList varchar(500) = '',
	@OrderBy varchar(200) = 'ID',
	@OrderType varchar(20) = 'Asc',
	@StartIndex int = 1,
	@EndIndex int = 20
	
AS
BEGIN

-- Declare variables
DECLARE @Sqry varchar(MAX)
DECLARE @SqryTotal varchar(MAX)
DECLARE @StatusFilterString varchar(1000)
DECLARE @SubmissionPeriodString varchar(1000)
DECLARE @CommentingPeriodListString varchar(1000)
DECLARE @CommitteeString varchar(1000)


-- Create status list string
SET @StatusFilterString = ''
IF @StatusList <> ''
BEGIN
	SET @StatusFilterString = ' AND vw_MSFSubmissionStatus.SUBMISSION_STATUS_ID in (' + @StatusList + ')'		
END


-- Create Commenting Period List string
SET @CommentingPeriodListString = ''
IF @CommentingPeriodList <> ''
BEGIN
	SET @CommentingPeriodListString = ' 
		INNER JOIN
		(
			SELECT distinct  MeasureID
			FROM MEASURE_COMMENTS WHERE ActivityID in (' + @CommentingPeriodList + ')
		)
		MeasureCommentInnerJoinTable on MeasureCommentInnerJoinTable.MeasureID = MSF_SUBMISSIONS.ID '

-- SET @CommentingPeriodListString = ' INNER JOIN MEASURE_COMMENTS on MEASURE_COMMENTS.MeasureID = MSF_SUBMISSIONS.ID and MEASURE_COMMENTS.ActivityID in (' + @CommentingPeriodList + ')'
END


-- Create Committee list string
DECLARE @ForwardStatus1 TINYINT
DECLARE @ForwardStatus2 TINYINT
SET @ForwardStatus1 = 11
SET @ForwardStatus2 = 12
SET @CommitteeString = ''
IF @CommitteeList <> ''
BEGIN
	SET @CommitteeString = ' 
		INNER JOIN
			(
				SELECT DISTINCT MeasureID from 
				(
					SELECT MSF_FORWARD_MEASURE.CommitteeID, 
						MSF_LATEST_WITH_CHANGEID.MeasureID FROM
						(SELECT MSF_STATUS_CHANGE.MsfStatusChangeID, MSF_LATEST.MeasureID, MSF_LATEST.DTS  FROM
						(SELECT max(DTS) as DTS, MeasureID FROM 
										MSF_STATUS_CHANGE 
										WHERE ChangedStatus = ' + CAST(@ForwardStatus1 AS varchar(7)) + ' OR ChangedStatus = ' + CAST(@ForwardStatus2 AS varchar(7)) + ' AND PreveiousStatus<>ChangedStatus
										GROUP BY MeasureID) MSF_LATEST inner join MSF_STATUS_CHANGE ON 
					MSF_STATUS_CHANGE.DTS = MSF_LATEST.DTS and MSF_STATUS_CHANGE.MeasureID = MSF_LATEST.MeasureID)
					MSF_LATEST_WITH_CHANGEID inner join MSF_FORWARD_MEASURE ON MSF_LATEST_WITH_CHANGEID.MsfStatusChangeID = MSF_FORWARD_MEASURE.MsfStatusChangeID
					and MSF_FORWARD_MEASURE.CommitteeID in (' + @CommitteeList + ')					
				) MSF_COMMITTEE
			)
			CommiteeTable on CommiteeTable.MeasureID = MSF_SUBMISSIONS.ID'
END


-- Create Submission period list string
SET @SubmissionPeriodString = ''
IF @SubmissionPeriodList <> ''
BEGIN
	SET @SubmissionPeriodString = ' AND MSF_SUBMISSIONS.ActivityID in (' + @SubmissionPeriodList + ')'	
	--AND MSF_SUBMISSION_STATUS.SUBMISSION_STATUS_ID not in (0,2,4)
END


-- Order by 
IF @OrderBy = 'DATE'
BEGIN
	SET @OrderBy = 'DTS'
END
ELSE IF @OrderBy = 'SUBMITTERORGANIZATION'
BEGIN
	SET @OrderBy = 'isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/Submitter/SubmitterOrganization/text())[1]'', ''varchar(256)''),'''')'
END
ELSE IF @OrderBy = 'TITLE'
BEGIN
	SET @OrderBy = 'isnull(XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(256)''),'''')'
END
ELSE IF @OrderBy = 'STEWARDORGANIZATION'
BEGIN
	SET @OrderBy = 'isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureSteward/MeasureStewardOrganization/text())[1]'', ''varchar(256)''),'''')'
END
ELSE IF @OrderBy = 'STATUS'
BEGIN
	SET @OrderBy = 'vw_MSFSubmissionStatus.SUBMISSION_STATUS_NAME'
END
ELSE
BEGIN
	SET @OrderBy = 'MSF_SUBMISSIONS.ID'
END

-- Query for paged data
SET @Sqry = 'SELECT * from (
	SELECT 	
		ROW_NUMBER() OVER (
		ORDER BY ' + @OrderBy + ' ' + @OrderType + ' 
		) AS RowNumber,
		MSF_SUBMISSIONS.ID,
		MSF_SUBMISSIONS.DTS,
		isnull(XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', ''varchar(2000)''),'''') as SubmissionTitle, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureSteward/MeasureStewardOrganization/text())[1]'', ''varchar(2000)''),'''') as StewardOrganization, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureStewardPointofContact/MeasureStewardContactEmailAddress/text())[1]'', ''varchar(500)''),'''') as StewardEmail, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureStewardPointofContact/MeasureStewardContactFirstName/text())[1]'', ''varchar(500)''),'''') as StewardFname, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureStewardPointofContact/MeasureStewardContactLastName/text())[1]'', ''varchar(500)''),'''') as StewardLname, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureStewardPointofContact/MeasureStewardContactPhone/text())[1]'', ''varchar(256)''),'''') as StewardPhone, 

		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/Submitter/SubmitterOrganization/text())[1]'', ''varchar(2000)''),'''') as SubmitterOrganization, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/Submitter/SubmitterEmailAddress/text())[1]'', ''varchar(500)''),'''') as SubmitterEmail, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/Submitter/SubmitterFirstName/text())[1]'', ''varchar(500)''),'''') as SubmitterFname, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/Submitter/SubmitterLastName/text())[1]'', ''varchar(500)''),'''') as SubmitterLname, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/Submitter/SubmitterPhone/text())[1]'', ''varchar(256)''),'''') as SubmitterPhone, 

		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureDeveloper/MeasureDeveloperOrganization/text())[1]'', ''varchar(2000)''),'''') as DeveloperOrganization, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureDeveloperPointofContact/MeasureDeveloperContactEmailAddress/text())[1]'', ''varchar(500)''),'''') as DeveloperEmail, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureDeveloperPointofContact/MeasureDeveloperContactFirstName/text())[1]'', ''varchar(500)''),'''') as DeveloperFname, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureDeveloperPointofContact/MeasureDeveloperContactLastName/text())[1]'', ''varchar(500)''),'''') as DeveloperLname, 
		isnull(XML_DATA.value(''(/tabs/tab[@id="7"]/MeasureDeveloperPointofContact/MeasureDeveloperContactPhone/text())[1]'', ''varchar(256)''),'''') as DeveloperPhone, 

		isnull(XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewMeasureDescription/text())[1]'', ''varchar(max)''),'''') as Measuredesc, 
		StatusSubmittedReadOnly as Statussubmitted, 
		MSF_SUBMISSIONS.XML_UI_SCHEMA_ID as SchemaID,
		OPLM_MSF.Version as Version,
		isnull(MSF_USERS.LastName, '''') as LastName, 
		isnull(MSF_USERS.FirstName, '''') as FirstName, 
		vw_MSFSubmissionStatus.SUBMISSION_STATUS_NAME  as Status,
		isNULL(CommentTable.CommentCount,0) as CommentCount
	FROM MSF_SUBMISSIONS 		
		INNER JOIN vw_MSFSubmissionStatus on 
		vw_MSFSubmissionStatus.SUBMISSION_STATUS_ID = MSF_SUBMISSIONS.StatusSubmittedReadOnly		
		' + @StatusFilterString + '
		' + @CommitteeString + '
		' + @CommentingPeriodListString + '		
		INNER JOIN OPLM_MSF on  OPLM_MSF.MSF_ID = MSF_SUBMISSIONS.XML_UI_SCHEMA_ID
		LEFT OUTER JOIN MSF_USERS on  MSF_USERS.IMISUserID = MSF_SUBMISSIONS.LastEditorIMISUserID
		LEFT OUTER JOIN 
			(
				SELECT count(CommentID) as CommentCount, MeasureID
				FROM MEASURE_COMMENTS  WHERE IsTop = 1
				GROUP BY MeasureID
			)
			CommentTable on CommentTable.MeasureID = MSF_SUBMISSIONS.ID
	WHERE MSF_SUBMISSIONS.IsDeleted=0 AND MSF_SUBMISSIONS.ProjectID = ' + CAST(@ProjectID AS varchar(7)) + '
	' + @SubmissionPeriodString + '
	) Measures WHERE RowNumber between ' + CAST(@StartIndex AS varchar(7)) + ' and ' + CAST(@EndIndex AS varchar(7)) + '';
	--) Measures WHERE RowNumber between ' + CAST(@StartIndex AS varchar(7)) + ' and ' + CAST(@EndIndex AS varchar(7)) + ' FOR XML AUTO, ROOT(''ROOT''), ELEMENTS';


-- Query for total count
SET @SqryTotal = 'SELECT 	
		count(MSF_SUBMISSIONS.ID) as TotalCount

	FROM MSF_SUBMISSIONS 
		INNER JOIN vw_MSFSubmissionStatus on 
		vw_MSFSubmissionStatus.SUBMISSION_STATUS_ID = MSF_SUBMISSIONS.StatusSubmittedReadOnly		
		' + @StatusFilterString + '
		' + @CommitteeString + '
		' + @CommentingPeriodListString + '
		INNER JOIN OPLM_MSF on  OPLM_MSF.MSF_ID = MSF_SUBMISSIONS.XML_UI_SCHEMA_ID
		LEFT OUTER JOIN MSF_USERS on  MSF_USERS.IMISUserID = MSF_SUBMISSIONS.LastEditorIMISUserID
		LEFT OUTER JOIN 
			(
				SELECT count(CommentID) as CommentCount, MeasureID
				FROM MEASURE_COMMENTS WHERE IsTop = 1
				GROUP BY MeasureID
			)
		CommentTable on CommentTable.MeasureID = MSF_SUBMISSIONS.ID
	WHERE MSF_SUBMISSIONS.IsDeleted=0 AND MSF_SUBMISSIONS.ProjectID = ' + CAST(@ProjectID AS varchar(7)) + ' ' + @SubmissionPeriodString + '' ;
	
	-- Execute the paged data query
	print(@Sqry)
	EXEC(@Sqry)
	
	-- Execute the total count query
	print(@SqryTotal)
	EXEC(@SqryTotal)

END
GO


-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_MEASURE_LIST'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_MEASURE_LIST created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_MEASURE_LIST.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT.';
	DROP PROCEDURE OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT
 * --Purpose/Function		: OPLM GET COMMITTEE BY PROJECTID WITH MEASURECOUNT
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 01/10/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/10/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT](
	@ProjectID BIGINT
)
AS
BEGIN	

DECLARE @ForwardStatus1 TINYINT
DECLARE @ForwardStatus2 TINYINT
SET @ForwardStatus1 = 11
SET @ForwardStatus2 = 12

	SELECT 
    C.CommitteeID,
    C.CommitteeTypeID,
    C.ProjectID,
    C.CommitteeName,
    C.ProjectStepIDForCommenting,
    C.ProjectStepIDForNominationPeriod,
    C.CreateWebLink,
    C.MeetingStartDate,
    C.MeetingEndDate,
    C.Background,
    C.iMISCode,
	C.IsActive,
	Measures.MeasureCount,
    T.CommitteeType
		FROM COMMITTEE C
			INNER JOIN COMMITTEE_TYPE T ON C.CommitteeTypeID = T.CommitteeTypeID
			INNER JOIN
				(
					SELECT Count(DISTINCT MeasureID) as MeasureCount, CommitteeID from 
					(
						SELECT MSF_FORWARD_MEASURE.CommitteeID, 
							MSF_LATEST_WITH_CHANGEID.MeasureID FROM
							(SELECT MSF_STATUS_CHANGE.MsfStatusChangeID, MSF_LATEST.MeasureID, MSF_LATEST.DTS  FROM
							(SELECT max(DTS) as DTS, MeasureID FROM 
											MSF_STATUS_CHANGE 
											WHERE ChangedStatus = @ForwardStatus1 OR ChangedStatus = @ForwardStatus2 AND PreveiousStatus<>ChangedStatus
											GROUP BY MeasureID) MSF_LATEST inner join MSF_STATUS_CHANGE ON 
						MSF_STATUS_CHANGE.DTS = MSF_LATEST.DTS and MSF_STATUS_CHANGE.MeasureID = MSF_LATEST.MeasureID)
						MSF_LATEST_WITH_CHANGEID inner join MSF_FORWARD_MEASURE ON MSF_LATEST_WITH_CHANGEID.MsfStatusChangeID = MSF_FORWARD_MEASURE.MsfStatusChangeID					
					) MSF_COMMITTEE	group by MSF_COMMITTEE.CommitteeID				
					

				)
				Measures on Measures.CommitteeID = C.CommitteeID
	WHERE ProjectID = @ProjectID;
END
GO


-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_COMMITTEE_BY_PROJECTID_WITH_MEASURECOUNT.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_USER_COMMENT_BY_PROJECT_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_USER_COMMENT_BY_PROJECT_ID.';
	DROP PROCEDURE GET_USER_COMMENT_BY_PROJECT_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_USER_COMMENT_BY_PROJECT_ID
 * --Purpose/Function		: Get USER COMMENT BY PROJECT ID
 * --Author					: WM
 * --Start Date(MM/DD/YY)	: 17/10/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 17/10/2010		WM		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE GET_USER_COMMENT_BY_PROJECT_ID
	@ProjectID bigint
AS
BEGIN
SELECT
	DISTINCT
	IMIS_USER_DETAILS.IMISUserID,
	IMIS_USER_DETAILS.COMPANY,	
	IMIS_USER_DETAILS.FirstName,
	IMIS_USER_DETAILS.LastName,
	IMIS_USER_DETAILS.InstituteName	
FROM 
	MEASURE_COMMENTS 
	INNER JOIN IMIS_USER_DETAILS 
	on MEASURE_COMMENTS.SubmitterIMISUserID = IMIS_USER_DETAILS.IMISUserID
WHERE MEASURE_COMMENTS.ProjectID = @ProjectID
ORDER By IMIS_USER_DETAILS.FirstName, IMIS_USER_DETAILS.LastName
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_USER_COMMENT_BY_PROJECT_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_USER_COMMENT_BY_PROJECT_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_USER_COMMENT_BY_PROJECT_ID.';
END
GO
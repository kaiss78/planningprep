SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_IS_STAFF_ASSIGNED_TO_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_IS_STAFF_ASSIGNED_TO_PROJECT.';
	DROP PROCEDURE OPLM_IS_STAFF_ASSIGNED_TO_PROJECT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPLM
 * --Function name			: OPLM_IS_STAFF_ASSIGNED_TO_PROJECT
 * --Purpose/Function		: Checks if a staff is assigned to a project
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 10/20/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 * This stored procedure will be used to log all user activity in the site
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 10/20/2009	MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_IS_STAFF_ASSIGNED_TO_PROJECT]
@UserID bigint
,@ProjectID bigint
,@IsAssigned bit output
AS
BEGIN
	BEGIN TRY
		SET @IsAssigned = 0
		IF EXISTS(SELECT 
					StaffMemberID 
				FROM 
					OPLM_PROJECT_STAFF_MEMBER
				WHERE
					UserID = @UserID
					AND ProjectID = @ProjectID
					AND IsStaffActive = 1
					AND EndDate>=getdate())
		BEGIN
			SET @IsAssigned = 1
		END
		
		
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END	

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_IS_STAFF_ASSIGNED_TO_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_IS_STAFF_ASSIGNED_TO_PROJECT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_IS_STAFF_ASSIGNED_TO_PROJECT.';
END
GO






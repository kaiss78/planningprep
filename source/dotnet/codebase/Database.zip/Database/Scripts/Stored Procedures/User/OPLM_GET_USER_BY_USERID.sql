SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_USER_BY_USERID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_USER_BY_USERID.';
	DROP PROCEDURE OPLM_GET_USER_BY_USERID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: OPLM
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_USER_BY_USERID
 * --Purpose/Function		: Retrieves users by USERID
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 06/06/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 01/10/09		AFS	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_GET_USER_BY_USERID]
(
	@UserID bigint
)
As
BEGIN
	SELECT   
		OU.UserID as UserID,
		IU.IMISUserID AS IMISUserID, 
		IU.IMISUserName AS UserName, 
		OU.FirstName, 
		OU.LastName, 
		OU.Email, 
		OU.Title, 
		OU.Active,
		IU.MemberType, 
		IU.OPLMIMISUserID,
		OPR.RoleName,
		UR.RoleID
		FROM   OPLM_USER OU INNER JOIN OPLM_IMIS_USER IU ON IU.OPLMIMISUserID=OU.OPLMIMISUserID
			   INNER JOIN OPLM_USER_ROLE UR ON UR.UserID=OU.UserID
			   INNER JOIN OPLM_ROLE OPR ON OPR.RoleID=UR.RoleID
		WHERE  OU.UserID = @UserID 
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_USER_BY_USERID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_USER_BY_USERID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_USER_BY_USERID.';
END
GO




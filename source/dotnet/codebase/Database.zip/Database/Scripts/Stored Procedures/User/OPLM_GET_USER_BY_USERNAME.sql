SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_USER_BY_USERNAME'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_USER_BY_USERNAME.';
	DROP PROCEDURE OPLM_GET_USER_BY_USERNAME;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: OPLM
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_USER_BY_USERNAME
 * --Purpose/Function		: Retrieves users by username
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 06/06/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 01/10/09		AFS	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_GET_USER_BY_USERNAME]
(
	@UserName varchar(60)
)
As
BEGIN
--	SELECT   UserID, UserName, FirstName, LastName, Email, Title, Active, OPLMIMISUserID
--	FROM     OPLM_USER
--	WHERE    UserName = @UserName
--	ORDER BY UserID DESC;

	SELECT   
		OU.UserID as UserID,
		IU.IMISUserID AS IMISUserID, 
		IU.IMISUserName AS UserName, 
		IU.MemberType,
		OU.FirstName, 
		OU.LastName, 
		OU.Email, 
		OU.Title, 
		OU.Active, 
		IU.OPLMIMISUserID,
		OPR.RoleName,
		UR.RoleID
		FROM   OPLM_USER OU INNER JOIN OPLM_IMIS_USER IU ON IU.OPLMIMISUserID=OU.OPLMIMISUserID
			   INNER JOIN OPLM_USER_ROLE UR ON UR.UserID=OU.UserID
			   INNER JOIN OPLM_ROLE OPR ON OPR.RoleID=UR.RoleID
		WHERE  IU.IMISUserName = @UserName 
		
		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_USER_BY_USERNAME'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_USER_BY_USERNAME created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_USER_BY_USERNAME.';
END
GO




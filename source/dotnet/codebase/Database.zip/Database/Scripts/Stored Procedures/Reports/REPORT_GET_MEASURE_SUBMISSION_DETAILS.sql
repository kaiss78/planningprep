SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_MEASURE_SUBMISSION_DETAILS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REPORT_GET_MEASURE_SUBMISSION_DETAILS.';
	DROP PROCEDURE REPORT_GET_MEASURE_SUBMISSION_DETAILS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REPORT_GET_MEASURE_SUBMISSION_DETAILS
 * --Purpose/Function		: Get measure details report data
 * --Author					: MRZ
 * --Start Date(MM/DD/YY)	: 01/06/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 01/06/2010		MRZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REPORT_GET_MEASURE_SUBMISSION_DETAILS](
			@MeasureIDs VARCHAR(MAX)
			,@Statuses VARCHAR(MAX)
			,@FromDate VARCHAR(MAX)
			,@ToDate VARCHAR(MAX)
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	

		DECLARE @SQL varchar(max)

		IF(@FromDate = '') SET @FromDate = '01/30/1900'
		IF(@ToDate = '') SET @ToDate = '12/30/2100'
		SET @FromDate = ISNULL(@FromDate ,'01/30/1900')
		SET @ToDate = ISNULL(@ToDate ,'12/30/2100')
		
		SET @FromDate = cast(convert(varchar(10),@FromDate ,101) as datetime)
		SET @ToDate = cast(convert(varchar(10),@ToDate ,101) as datetime)
		
		
		IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.TempMeasureStatus') AND type in (N'U'))
		BEGIN
		DROP TABLE TempMeasureStatus
		END

		SET @SQL = '
		SELECT DISTINCT
			MS.DTS AS LastEditedDate
			--,MS.ID
			--,MS.ProjectID
			,MS.ID AS MeasureID
			,(SELECT 		
						MemberID
						FROM dbo.MSF_FORWARD_MEASURE
						WHERE MsfStatusChangeID = (SELECT TOP 1 MsfStatusChangeID 
													FROM
														MSF_STATUS_CHANGE
													WHERE (ChangedStatus = 11 OR ChangedStatus = 12) 
														AND MeasureID = MS.ID
													ORDER BY DTS DESC)) AS COMIN
			
			,ISNULL(MSC.MsfStatusChangeID, 0) AS STATUSID
			,ISNULL((SELECT MU.FirstName + '' '' + MU.LastName FROM dbo.MSF_USERS MU WHERE MU.IMISUserID = MS.IMISUserID), '''') AS LastEditedBy
			,OPPD.ShortName AS ProjectShortName			
			,(DBO.GET_COMMA_SEPARATED_NPP_AND_CONDITIONS_BY_MEASUREID(MS.ID,1)) AS NPPAreas
			,(DBO.GET_COMMA_SEPARATED_NPP_AND_CONDITIONS_BY_MEASUREID(MS.ID,3)) AS Conditions
			,ISNULL(MS.SimilarMeasure, '''') AS SimilarMeasure
			,(SELECT SUBMISSION_STATUS_NAME FROM dbo.MSF_SUBMISSION_STATUS WHERE SUBMISSION_STATUS_ID = MS.StatusSubmitted) AS MeasureStatus
		INTO TempMeasureStatus 

		FROM MSF_SUBMISSIONS MS
			LEFT OUTER JOIN dbo.MSF_STATUS_CHANGE MSC ON MSC.MeasureID = MS.ID
			LEFT OUTER JOIN dbo.MSF_MEASURE_TAXONOMY MMT ON MMT.MeasureID = MS.ID
			LEFT OUTER JOIN dbo.MSF_FORWARD_MEASURE MFM ON MFM.MsfStatusChangeID = MSC.MsfStatusChangeID
			INNER JOIN dbo.MSF_SUB_TAXONOMY MST ON MST.TaxonomyID IN (1,3)
			INNER JOIN dbo.OPLM_PROJECT_PRIMARY_DATA OPPD ON OPPD.ProjectID = MS.ProjectID
			INNER JOIN dbo.MSF_USERS MU ON MU.IMISUserID = MS.IMISUserID

		WHERE
			MS.IsDeleted=0 
			AND (CAST(CONVERT(VARCHAR(20), MS.DTS, 101) AS DATETIME) >= ''' + @FromDate + ''')
			AND (CAST(CONVERT(VARCHAR(20),MS.DTS, 101) AS DATETIME) <= ''' + @ToDate + ''')					
			AND (CONVERT(VARCHAR(MAX),MS.ID) IN (' + @MeasureIDs + ') AND CONVERT(VARCHAR(MAX),MS.StatusSubmitted) IN (' + @Statuses + '))
			AND CONVERT(VARCHAR(MAX), MST.TaxonomyID) IN (1,3) 
			AND ((ISNULL(MSC.MsfStatusChangeID, 0) = 0) OR MSC.MsfStatusChangeID IN (
										SELECT MsfStatusChangeID
										FROM MSF_STATUS_CHANGE
										WHERE DTS in (
										SELECT MAX(MSF_STATUS_CHANGE.DTS)
										FROM MSF_STATUS_CHANGE
										INNER JOIN MSF_SUBMISSIONS ON MSF_SUBMISSIONS.ID = MSF_STATUS_CHANGE.MeasureID
										WHERE MSF_SUBMISSIONS.ID IN (' + @MeasureIDs + ')
										AND MSF_SUBMISSIONS.IsDeleted=0
										GROUP BY MeasureID)
										 ) )
		ORDER BY MS.DTS DESC
			'
		--PRINT @SQL
		Exec(@SQL)

	SELECT 
	TMS.LastEditedDate	
	,TMS.LastEditedBy
	,TMS.ProjectShortName
	,isnull(MS.xml_data.query('data(tabs/tab/NQFReviewTitle)'),'') AS MeasureTitle
	,isnull(MS.xml_data.query('data(tabs/tab/NQFReviewMeasureDescription)'),'') AS MeasureShortDescription
	,TMS.NPPAreas
	,TMS.Conditions
	,TMS.SimilarMeasure
	, ISNULL((SELECT CMD.FirstName + ' ' + CMD.LastName + ', ' + CMD.Organization FROM dbo.COMMITTEE_MEMBER_DETAILS CMD WHERE CMD.MemberID = TMS.COMIN), '') AS SteeringCommitteeMember
	,TMS.MeasureStatus
	FROM TempMeasureStatus TMS
	INNER JOIN MSF_SUBMISSIONS MS ON MS.ID = TMS.MeasureID
	WHERE
	MS.IsDeleted=0
	DROP TABLE TempMeasureStatus
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_MEASURE_SUBMISSION_DETAILS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REPORT_GET_MEASURE_SUBMISSION_DETAILS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REPORT_GET_MEASURE_SUBMISSION_DETAILS.';
END
GO
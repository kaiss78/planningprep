SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_BOARD_MEETING_DATES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REPORT_GET_BOARD_MEETING_DATES.';
	DROP PROCEDURE REPORT_GET_BOARD_MEETING_DATES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REPORT_GET_BOARD_MEETING_DATES
 * --Purpose/Function		: REPORT GET BOARD MEETING DATES
 * --Author					: MZ
 * --Start Date(MM/DD/YY)	: 02/04/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/04/2010		MZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REPORT_GET_BOARD_MEETING_DATES]
(
	@ProjectID BIGINT,
	@FromDate VARCHAR(20),
	@ToDate VARCHAR(20)
)

AS
BEGIN
-- Declare variables
DECLARE @Sqry VARCHAR(MAX)
DECLARE @StatusID VARCHAR(50)

-- Set Status ID
SET @StatusID='24,25,26,27,28,29,30,31,32,34'

-- Set filtering condition

IF @FromDate = ''
BEGIN
	SET @FromDate = '01/01/1900'
END

IF @ToDate = ''
BEGIN
	SET @ToDate = '01/01/2099'
END

-- Main query
SET @Sqry = 
'SELECT DISTINCT
	MS.ID AS MeasureID
	, MS.XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', 
		''varchar(2000)'') AS MeasureName
	, OPD.LongTitle AS LongTitle
	, OPD.ShortName AS ShortName
	, MT.MeetingTypeName AS TypeOfMeeting
	, MT.MeetingTypeID AS MeetingTypeID
	, GMD.MeetingStartDateTime AS StartDateTime
	, GMD.MeetingEndDateTime AS EndDateTime
	, GMD.MeetingVenue AS MeetingVenue
	, GMD.MeetingStreet AS MeetingStreet
	, GMD.MeetingCity AS MeetingCity
	, GMD.MeetingZip AS MeetingZip
	, GMD.MeetingState AS MeetingState
	, GMD.MeetingDialInNumber AS MeetingDialInNumber

FROM MSF_SUBMISSIONS MS INNER JOIN
	 OPLM_PROJECT_PRIMARY_DATA OPD ON MS.ProjectID=OPD.ProjectID INNER JOIN
	 VW_MEETING_DATES_WITH_MEASURES VW_MEASURE ON MS.ID=VW_MEASURE.MeasureID INNER JOIN
	 GROUP_MEETING_DATES GMD ON VW_MEASURE.MeetingDateID=GMD.MeetingDateID INNER JOIN
	 MEETING_TYPE MT ON GMD.MeetingTypeID=MT.MeetingTypeID INNER JOIN
	 GROUP_VOTING_RESULT GVR ON VW_MEASURE.MeetingDateID=GVR.MeetingDateID AND VW_MEASURE.MeasureID=GVR.MeasureID

WHERE MS.StatusSubmitted In (' + @StatusID +')
	AND MS.ProjectID= ' + Cast(@ProjectID as varchar(100)) + '
	AND (((CAST(CONVERT(VARCHAR(20), GMD.MeetingStartDateTime, 101) AS DATETIME) >=  ''' + @FromDate + ''') 
			AND (CAST(CONVERT(VARCHAR(20), GMD.MeetingStartDateTime, 101) AS DATETIME) <=  ''' + @ToDate + '''))
		OR
		((CAST(CONVERT(VARCHAR(20), GMD.MeetingEndDateTime, 101) AS DATETIME) >=  ''' + @FromDate + ''') 
			AND (CAST(CONVERT(VARCHAR(20), GMD.MeetingEndDateTime, 101) AS DATETIME) <=  ''' + @ToDate + '''))
		)
	AND GVR.GroupID=''2''
ORDER BY StartDateTime DESC'

print(@Sqry)
EXEC(@Sqry)

-- EXEC REPORT_GET_BOARD_MEETING_DATES 16, '',''
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_BOARD_MEETING_DATES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REPORT_GET_BOARD_MEETING_DATES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REPORT_GET_BOARD_MEETING_DATES.';
END
GO
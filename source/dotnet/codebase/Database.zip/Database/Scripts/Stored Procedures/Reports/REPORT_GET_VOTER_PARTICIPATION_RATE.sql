SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_VOTER_PARTICIPATION_RATE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REPORT_GET_VOTER_PARTICIPATION_RATE.';
	DROP PROCEDURE REPORT_GET_VOTER_PARTICIPATION_RATE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REPORT_GET_VOTER_PARTICIPATION_RATE
 * --Purpose/Function		: Get Sub Category ID and Submission Type as comma separated
 * --Author					: MZ
 * --Start Date(MM/DD/YY)	: 10/28/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/02/2010		MZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REPORT_GET_VOTER_PARTICIPATION_RATE]
(
	@ProjectID BIGINT,
	@CommentingPeriodList VARCHAR(1000),
	@OrderBy VARCHAR(200),
	@OrderType VARCHAR(20)
)

AS
BEGIN
-- Declare variables
DECLARE @Sqry VARCHAR(MAX)
DECLARE @CommentingPeriodString VARCHAR(1000)

-- Set sorting condition 
IF @OrderBy = 'COUNCIL'
BEGIN
	SET @OrderBy = 'COUNCIL_NAME'
END
ELSE
BEGIN
	SET @OrderBy = 'COUNCIL_NAME'
END

-- Set filtering condition

DECLARE @CommentingPeriod VARCHAR (1000)
SET @CommentingPeriod = 'select ActivityID from VOTING_RESULTS '
SET @CommentingPeriodString = ''
IF @CommentingPeriodList <> ''
BEGIN
	SET @CommentingPeriodString = 'and vr.ActivityID in (' + @CommentingPeriodList + ')'
END

-- Main query
SET @Sqry = 
'SELECT
	elgu.COUNCIL AS COUNCIL_NAME,
	(Select Count(vrui.UserInfoID) From VOTING_RESULTS vr,VOTING_RESULTS_USER_INFO vrui 
		Where vr.VoteUserInfoID=vrui.UserInfoID 
		AND elgu.COUNCIL=vrui.Council 
		AND vr.ProjectID = ' + Cast(@ProjectID as varchar(100)) + '
		' + @CommentingPeriodString + ') AS VOTING,
	Count(IMISUserID) AS ELIGIBLETOVOTE

FROM IMIS_ELIGIBLE_VOTERS elgu 
WHERE elgu.COUNCIL IS NOT NULL
GROUP BY COUNCIL

ORDER BY ' + @OrderBy + ' ' + @OrderType +'
'

print(@Sqry)
EXEC(@Sqry)
-- EXEC REPORT_GET_VOTER_PARTICIPATION_RATE 39, '141', 'COUNCIL', 'DESC'
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_VOTER_PARTICIPATION_RATE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REPORT_GET_VOTER_PARTICIPATION_RATE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REPORT_GET_VOTER_PARTICIPATION_RATE.';
END
GO
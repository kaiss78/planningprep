SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA.';
	DROP PROCEDURE OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA
 * --Purpose/Function		: Gets all the submissions
 * --Author					: MI
 * --Start Date(MM/DD/YY)	: 10/29/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MI		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA](
	@ProjectID BIGINT,
	@SubmissionDateStart DATETIME, 
	@SubmissionDateEnd DATETIME, 
	@Taxonomies VARCHAR(200),
	@Organization VARCHAR(100),
	@SubmissionType VARCHAR(100)
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	IF(@SubmissionDateStart = '')
		SET @SubmissionDateStart = CONVERT(DATETIME,'01/30/1900')
	IF(@SubmissionDateEnd = '')
		SET @SubmissionDateEnd = CONVERT(DATETIME,'12/30/2100')

SET @SubmissionDateStart = ISNULL(@SubmissionDateStart ,CONVERT(DATETIME,'01/30/1900'))
SET @SubmissionDateEnd = ISNULL(@SubmissionDateEnd ,CONVERT(DATETIME,'12/30/2100'))

	declare @sql varchar(max)
	declare @select varchar(max)
	declare @from varchar(max)
	declare @where varchar(max)

	IF @Organization <> ''
	BEGIN
		SET @Organization = REPLACE(@Organization,'''','''''');
		SET @Organization = '%' + @Organization + '%';
	END

set @select = '
	SELECT DISTINCT
		  OI.IntentID
		, OI.Title
		, OI.Description
		, OI.OnBehalfOrganization AS ''On Behalf Of Organization''
		, OI.SubmissionType AS ''Type''
		, OI.SubmissionDate
		, OI.imisUserOrganization AS ''Organization''
		, OI.imisUserName AS ''Name''
		, 
		(select CASE WHEN convert(varchar(max), OISC_TEMP.IntentSubCategoryName) = ''Other'' THEN ''Other: '' + (Select OtherText From dbo.OPLM_INTENT_OTHER Where OtherID=OICR_TEMP.IntentSubCategoryID) else convert(varchar(max), OISC_TEMP.IntentSubCategoryName) end + '', '' as [text()] 
			FROM OPLM_INTENT_CATEGORY_RELATION OICR_TEMP
			LEFT OUTER JOIN OPLM_INTENT_SUB_CATEGORY OISC_TEMP ON OICR_TEMP.IntentSubCategoryID = OISC_TEMP.IntentSubCategoryID
			WHERE  IntentID=OI.IntentID                
			FOR XML PATH('''')) AS ''Taxonomies''
	'

SET @from =	' FROM dbo.OPLM_INTENT OI		
		right outer JOIN dbo.SplitData(''' + @SubmissionType +''', '','') SValues ON CONVERT(VARCHAR(20),SValues.id) = OI.SubmissionType
		left outer JOIN dbo.OPLM_INTENT_CATEGORY_RELATION OICR ON OI.IntentID = OICR.IntentID
		right outer JOIN dbo.SplitData(''' + @Taxonomies +''', '','') SplittedValues ON SplittedValues.id = OICR.IntentSubCategoryID'

IF(@SubmissionType = '')
	BEGIN 
		SET @from =	' FROM dbo.OPLM_INTENT OI		
			left outer JOIN dbo.OPLM_INTENT_CATEGORY_RELATION OICR ON OI.IntentID = OICR.IntentID
			left outer JOIN dbo.SplitData(''' + @Taxonomies +''', '','') SplittedValues ON SplittedValues.id = OICR.IntentSubCategoryID'
	END

IF(@Taxonomies = '')
	BEGIN 
		SET @from =	' FROM dbo.OPLM_INTENT OI	
			right outer JOIN dbo.SplitData(''' + @SubmissionType +''', '','') SValues ON CONVERT(VARCHAR(20),SValues.id) = OI.SubmissionType	
			left outer JOIN dbo.OPLM_INTENT_CATEGORY_RELATION OICR ON OI.IntentID = OICR.IntentID'
	END

IF(@SubmissionType = '' AND @Taxonomies = '')
	BEGIN 
		SET @from =	' FROM dbo.OPLM_INTENT OI'
	END

SET @where = ' WHERE 
		OI.ProjectID = '+ CONVERT(VARCHAR(20),@ProjectID) + '
		AND (CONVERT(VARCHAR(20),OI.SubmissionDate, 101) >= ''' + CONVERT(VARCHAR(20),@SubmissionDateStart, 101) + ''')
		AND (CONVERT(VARCHAR(20),OI.SubmissionDate, 101) <= ''' + CONVERT(VARCHAR(20),@SubmissionDateEnd, 101) + ''')
		AND ISNULL( OI.imisUserOrganization, '''' ) LIKE CASE WHEN ''' + @Organization + '''= '''' THEN ''%%'' ELSE ''' + @Organization + ''' END'

SET @sql = @select + @from + @where
Print @sql
EXEC (@sql)
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_REPORT_GET_CALL_FOR_INTENT_SUBMISSION_DATA.';
END
GO
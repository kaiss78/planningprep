SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_MEMBER_VOTING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REPORT_GET_MEMBER_VOTING.';
	DROP PROCEDURE REPORT_GET_MEMBER_VOTING;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REPORT_GET_MEMBER_VOTING
 * --Purpose/Function		: Get Sub Category ID and Submission Type as comma separated
 * --Author					: MZ
 * --Start Date(MM/DD/YY)	: 10/28/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/02/2010		MZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REPORT_GET_MEMBER_VOTING]
(
	@ProjectID BIGINT,
	@FromDate VARCHAR(20),
	@ToDate VARCHAR(20),
	@MeasureIDList VARCHAR(1000),
	@OrganizationList VARCHAR(1000),
	@CouncilList VARCHAR(1000),
	@CommentingPeriodList VARCHAR(1000),
	@OrderBy VARCHAR(200),
	@OrderType VARCHAR(20)
)

AS
BEGIN
-- Declare variables
DECLARE @Sqry VARCHAR(MAX)
DECLARE @MeasureIDString VARCHAR(1000)
DECLARE @OrganizationString VARCHAR(1000)
DECLARE @CouncilString VARCHAR(1000)
DECLARE @CommentingPeriodString VARCHAR(1000)

-- Set sorting condition 
IF @OrderBy = 'DATE'
BEGIN
	SET @OrderBy = 'VOTING_DATE'
END
ELSE IF @OrderBy = 'USERNAME'
BEGIN
	SET @OrderBy = 'USER_NAME'
END
ELSE IF @OrderBy = 'FIRSTNAME'
BEGIN
	SET @OrderBy = 'FIRST_NAME'
END
ELSE IF @OrderBy = 'LASTNAME'
BEGIN
	SET @OrderBy = 'LAST_NAME'
END
ELSE IF @OrderBy = 'ORGANIZATIONNAME'
BEGIN
	SET @OrderBy = 'ORGANIZATION_NAME'
END
ELSE IF @OrderBy = 'COUNCILNAME'
BEGIN
	SET @OrderBy = 'COUNCIL_NAME'
END
ELSE IF @OrderBy = 'MEASURENAME'
BEGIN
	SET @OrderBy = 'MEASURE_NAME'
END
ELSE IF @OrderBy = 'RESULT'
BEGIN
	SET @OrderBy = 'RESULT'
END
ELSE
BEGIN
	SET @OrderBy = 'VOTING_DATE'
END

-- Set filtering condition
IF @FromDate = ''
BEGIN
	SET @FromDate = '01/01/1900'
END

IF @ToDate = ''
BEGIN
	SET @ToDate = '01/01/2099'
END

DECLARE @MeasureID VARCHAR (1000)
SET @MeasureID = 'select MeasureID from VOTING_RESULTS '
SET @MeasureIDString = ''
IF @MeasureIDList <> ''
BEGIN
	SET @MeasureIDString = 'and MeasureID in (' + @MeasureIDList + ')'
END

DECLARE @Organization VARCHAR (1000)
SET @Organization = 'select Distinct Organization from VOTING_RESULTS_USER_INFO '
SET @OrganizationString = ''
IF @OrganizationList <> ''
BEGIN
	DECLARE @SplitOrganization VARCHAR (1000)
	SET @SplitOrganization = 'select id from dbo.SplitId ('''+@OrganizationList+''','','')'
	SET @OrganizationString = 'and Organization in (' + @SplitOrganization + ')'
END

DECLARE @CommentingPeriod VARCHAR (1000)
SET @CommentingPeriod = 'select ActivityID from VOTING_RESULTS '
SET @CommentingPeriodString = ''
IF @CommentingPeriodList <> ''
BEGIN
	SET @CommentingPeriodString = 'and vr.ActivityID in (' + @CommentingPeriodList + ')'
END

DECLARE @Council VARCHAR (1000)
SET @Council = 'select Distinct Council from VOTING_RESULTS_USER_INFO '
SET @CouncilString = ''
IF @CouncilList <> ''
BEGIN
	DECLARE @SplitCouncil VARCHAR (1000)
	SET @SplitCouncil = 'select id from dbo.SplitId ('''+@CouncilList+''','','')'
	SET @CouncilString = 'and council in (' + @SplitCouncil + ')'
END
	

-- Main query
SET @Sqry = 
'SELECT
	vr.VoteResultID AS VOTE_RESULT_ID,
	vr.VotingDate AS VOTING_DATE,
	vrui.IMISUserID AS USER_NAME,
	vrui.FirstName AS FIRST_NAME,
	vrui.LastName AS LAST_NAME,
	vrui.Organization AS ORGANIZATION_NAME,
	vrui.Council AS COUNCIL_NAME,
	MS.XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', 
                      ''varchar(2000)'') AS MEASURE_NAME,
	vr.MeasureID AS MEASURE_ID,
	vr.Result AS RESULT
	
	From VOTING_RESULTS vr Inner Join VOTING_RESULTS_USER_INFO vrui
	On vr.VoteUserInfoID=vrui.UserInfoID
	LEFT OUTER JOIN dbo.MSF_SUBMISSIONS AS MS
	ON vr.MeasureID = MS.ID
WHERE
	(CAST(CONVERT(VARCHAR(20), vr.VotingDate, 101) AS DATETIME) >= ''' + @FromDate + ''') 
	and (CAST(CONVERT(VARCHAR(20), vr.VotingDate, 101) AS DATETIME) <= ''' + @ToDate + ''')
	' + @MeasureIDString + '
	' + @OrganizationString + '
	' + @CommentingPeriodString + '
	' + @CouncilString + '
	and vr.ProjectID = ' + Cast(@ProjectID as varchar(100)) + '
	AND MS.IsDeleted=0
	ORDER BY ' + @OrderBy + ' ' + @OrderType +'
	'

print(@Sqry)
EXEC(@Sqry)
-- EXEC REPORT_GET_MEMBER_VOTING 39, '', '', '', '', 'Health Plan', '', 'DATE', 'DESC'
END
GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_MEMBER_VOTING'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REPORT_GET_MEMBER_VOTING created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REPORT_GET_MEMBER_VOTING.';
END
GO
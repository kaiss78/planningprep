SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_REPORT_GET_HISTORY_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_REPORT_GET_HISTORY_DATA.';
	DROP PROCEDURE OPLM_REPORT_GET_HISTORY_DATA;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_REPORT_GET_HISTORY_DATA
 * --Purpose/Function		: Gets ProjectDocument objects by ID
 * --Author					: MI
 * --Start Date(MM/DD/YY)	: 10/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/13/2009		MI		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_REPORT_GET_HISTORY_DATA]
(
	@ProjectID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	

		SELECT 
		  HistoryID
		, ProjectID
		, DataTypeName
		, DataTypeCode
		, FieldName
		, SQLFieldTypeCode
		, BeforeValue
		, AfterValue
		, UserID
		, UserName
		, UserFirstName
		, UserLastName
		, DataID
		, DataName
		, DTS
		, PreviousDTS
		FROM dbo.OPLM_HISTORY_DATA
		WHERE ProjectID = CAST(@ProjectID AS VARCHAR)
		ORDER BY DTS DESC;
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_REPORT_GET_HISTORY_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_REPORT_GET_HISTORY_DATA created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_REPORT_GET_HISTORY_DATA.';
END
GO
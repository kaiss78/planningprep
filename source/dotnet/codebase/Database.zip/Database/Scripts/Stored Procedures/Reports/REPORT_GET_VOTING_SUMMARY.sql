SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_VOTING_SUMMARY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REPORT_GET_VOTING_SUMMARY.';
	DROP PROCEDURE REPORT_GET_VOTING_SUMMARY;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REPORT_GET_VOTING_SUMMARY
 * --Purpose/Function		: Get Voting Summary
 * --Author					: MI
 * --Start Date(MM/DD/YY)	: 02/04/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/04/2010		MI		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REPORT_GET_VOTING_SUMMARY]
(
	@ProjectID BIGINT,
	@FromDate VARCHAR(20),
	@ToDate VARCHAR(20),
	@MeasureIDList VARCHAR(1000),
	@OrganizationList VARCHAR(1000),
	@CouncilList VARCHAR(1000),
	@CommentingPeriodList VARCHAR(1000),
	@OrderBy VARCHAR(200),
	@OrderType VARCHAR(20)
)

AS
BEGIN
-- Declare variables
DECLARE @Sqry VARCHAR(MAX)
DECLARE @MeasureIDString VARCHAR(1000)
DECLARE @OrganizationString VARCHAR(1000)
DECLARE @CouncilString VARCHAR(1000)
DECLARE @CommentingPeriodString VARCHAR(1000)

-- Set sorting condition 
IF @OrderBy = 'DATE'
BEGIN
	SET @OrderBy = 'VOTING_DATE'
END
ELSE IF @OrderBy = 'USERNAME'
BEGIN
	SET @OrderBy = 'USER_NAME'
END
ELSE IF @OrderBy = 'FIRSTNAME'
BEGIN
	SET @OrderBy = 'FIRST_NAME'
END
ELSE IF @OrderBy = 'LASTNAME'
BEGIN
	SET @OrderBy = 'LAST_NAME'
END
ELSE IF @OrderBy = 'ORGANIZATIONNAME'
BEGIN
	SET @OrderBy = 'ORGANIZATION_NAME'
END
ELSE IF @OrderBy = 'COUNCILNAME'
BEGIN
	SET @OrderBy = 'COUNCIL_NAME'
END
ELSE IF @OrderBy = 'MEASURENAME'
BEGIN
	SET @OrderBy = 'MEASURE_NAME'
END
ELSE IF @OrderBy = 'RESULT'
BEGIN
	SET @OrderBy = 'RESULT'
END
ELSE
BEGIN
	SET @OrderBy = 'VOTING_DATE'
END

-- Set filtering condition
IF @FromDate = ''
BEGIN
	SET @FromDate = '01/01/1900'
END

IF @ToDate = ''
BEGIN
	SET @ToDate = '01/01/2099'
END

DECLARE @MeasureID VARCHAR (1000)
SET @MeasureID = 'select MeasureID from VOTING_RESULTS '
SET @MeasureIDString = ''
IF @MeasureIDList <> ''
BEGIN
	SET @MeasureIDString = 'and MeasureID in (' + @MeasureIDList + ')'
END

DECLARE @Organization VARCHAR (1000)
SET @Organization = 'select Distinct Organization from VOTING_RESULTS_USER_INFO '
SET @OrganizationString = ''
IF @OrganizationList <> ''
BEGIN
	DECLARE @SplitOrganization VARCHAR (1000)
	SET @SplitOrganization = 'select id from dbo.SplitId ('''+@OrganizationList+''','','')'
	SET @OrganizationString = 'and Organization in (' + @SplitOrganization + ')'
END

DECLARE @CommentingPeriod VARCHAR (1000)
SET @CommentingPeriod = 'select ActivityID from VOTING_RESULTS '
SET @CommentingPeriodString = ''
IF @CommentingPeriodList <> ''
BEGIN
	SET @CommentingPeriodString = 'and vr.ActivityID in (' + @CommentingPeriodList + ')'
END

DECLARE @Council VARCHAR (1000)
SET @Council = 'select Distinct Council from VOTING_RESULTS_USER_INFO '
SET @CouncilString = ''
IF @CouncilList <> ''
BEGIN
	DECLARE @SplitCouncil VARCHAR (1000)
	SET @SplitCouncil = 'select id from dbo.SplitId ('''+@CouncilList+''','','')'
	SET @CouncilString = 'and council in (' + @SplitCouncil + ')'
END
	

-- Main query
SET @Sqry = 
'
CREATE TABLE #allCouncils
(
	ID INT IDENTITY,
	COUNCIL VARCHAR(1000)
)

INSERT INTO #allCouncils SELECT DISTINCT COUNCIL  from dbo.IMIS_ELIGIBLE_VOTERS where council is not null;

WITH VOTINGRESULT AS
(
	SELECT
	vr.VoteResultID as ID,
	vr.VotingDate AS VOTING_DATE,
	vr.MeasureID AS MEASURE_ID,
    --case vr.MeasureID when 2 then 3 else vr.MeasureID end MEASURE_ID,
	MS.XML_DATA.value(''(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]'', 
                      ''varchar(2000)'') AS MEASURE_NAME,
	vrui.Council COUNCIL_NAME,	
	case vr.Result when ''Approve'' then vr.result else null end ApproveResult,
	case vr.Result when ''Disapprove'' then vr.result else null end DenyResult,
	case vr.Result when ''Abstain'' then vr.result else null end AbstainResult 

FROM VOTING_RESULTS vr Inner Join VOTING_RESULTS_USER_INFO vrui
	On vr.VoteUserInfoID=vrui.UserInfoID
	LEFT OUTER JOIN dbo.MSF_SUBMISSIONS AS MS
	ON vr.MeasureID = MS.ID
WHERE
	(CAST(CONVERT(VARCHAR(20), vr.VotingDate, 101) AS DATETIME) >= ''' + @FromDate + ''') 
	and (CAST(CONVERT(VARCHAR(20), vr.VotingDate, 101) AS DATETIME) <= ''' + @ToDate + ''')
	' + @MeasureIDString + '
	' + @OrganizationString + '
	' + @CommentingPeriodString + '
	' + @CouncilString + '
	and MS.IsDeleted=0 AND vr.ProjectID = ' + Cast(@ProjectID as varchar(100)) + ')

SELECT 
	COUNCIL_NAME, 
	MEASURE_ID,
	MEASURE_NAME,
	YES,
	No,
	Abstain,
	TotalVotes, 
	case when TotalVotes - Abstain = 0 then null else ROUND(Yes * CAST(100 as FLOAT)/CAST((TotalVotes - Abstain)as FLOAT),0) end 
	PercentResult into #tempTable FROM
	(
		select t1.COUNCIL_NAME,t1.measure_id, t1.MEASURE_NAME, count(t1.ApproveResult) Yes,count(t1.DenyResult) No, count(t1.AbstainResult) Abstain, count(t1.ApproveResult) + (count(t1.DenyResult) + count(t1.AbstainResult)) TotalVotes from VOTINGRESULT t1 INNER join VOTINGRESULT t2
		on t1.ID=t2.ID
		where  t1.MEASURE_ID=t2.MEASURE_ID and
		t1.COUNCIL_NAME=t2.COUNCIL_NAME GROUP BY
		t1.measure_id,t1.COUNCIL_NAME,t1.MEASURE_NAME

	) RESULTQUERY
ORDER by MEASURE_ID,COUNCIL_NAME;

CREATE TABLE #allMeasureIDs
(
	ID INT IDENTITY,
	MEASURE_ID BIGINT,
	MEASURE_NAME VARCHAR(1000)
)
INSERT INTO #allMeasureIDs SELECT DISTINCT MEASURE_ID, MEASURE_NAME FROM #tempTable; 

--SELECT * FROM #tempTable

DECLARE @MeasureIDCount INT, @CouncilCount INT, @MeasureCouter INT, @CouncilCounter INT;
SET @MeasureCouter = 1;

SELECT @MeasureIDCount= MAX(ID) FROM #allMeasureIDs
SELECT @CouncilCount= MAX(ID) FROM #allCouncils

WHILE @MeasureCouter <= @MeasureIDCount
BEGIN
	SET @CouncilCounter = 1;
	WHILE @CouncilCounter <= @CouncilCount
	BEGIN
		DECLARE @CurrentMeasureID BIGINT, @CurrentCouncil VARCHAR(100),@CurrentMeasureName VARCHAR(100)

		SELECT @CurrentMeasureID = MEASURE_ID FROM #allMeasureIDs WHERE ID = @MeasureCouter;
		SELECT @CurrentMeasureName = MEASURE_NAME FROM #allMeasureIDs WHERE ID = @MeasureCouter;
		SELECT @CurrentCouncil = COUNCIL FROM #allCouncils WHERE ID = @CouncilCounter;

		IF NOT EXISTS (SELECT * FROM #tempTable WHERE COUNCIL_NAME = @CurrentCouncil AND MEASURE_ID = @CurrentMeasureID)
		BEGIN
			INSERT INTO #tempTable VALUES(@CurrentCouncil,@CurrentMeasureID,@CurrentMeasureName,0,0,0,0,null)
		END
		SET @CouncilCounter = @CouncilCounter + 1
	END
	SET @MeasureCouter = @MeasureCouter + 1
END;



WITH AVGQuery AS
(
	SELECT MEASURE_ID,TotalYesForMeasure,TotalNoForMeasure,TotalAbstainForMeasure,TotalVotesForMeasure,AvgPercentResultForMeasure,CountOver50,TotalCount,
	case when TotalCount = 0 then null else 100 * CAST(CountOver50 as Float)/CAST(TotalCount as Float) end MeasurePercentageRatio
	FROM
	(
		SELECT  MEASURE_ID,Sum(Yes) TotalYesForMeasure,Sum(No) TotalNoForMeasure,Sum(Abstain) TotalAbstainForMeasure,Sum(TotalVotes) TotalVotesForMeasure, Avg(CAST(PercentResult as Float)) AvgPercentResultForMeasure, Count(case when PercentResult > 50 then PercentResult end) CountOver50, Count(PercentResult) TotalCount FROM
		#tempTable
		GROUP BY MEASURE_ID
	)
	InnerQry
)



SELECT COUNCIL_NAME,MEASURE_ID,MEASURE_NAME, YES,No,Abstain,TotalVotes,PercentResult,
(Select ROUND(AvgPercentResultForMeasure,0) from AVGQuery where AVGQuery.MEASURE_ID = #tempTable.MEASURE_ID) AvgPercentResultForMeasure, 
(Select ROUND(MeasurePercentageRatio,0) from AVGQuery where AVGQuery.MEASURE_ID = #tempTable.MEASURE_ID) MeasurePercentageRatio 
FROM #tempTable
ORDER BY MEASURE_ID,COUNCIL_NAME

drop table #tempTable
drop table #allCouncils
drop table #allMeasureIDs

'

print(@Sqry)
EXEC(@Sqry)
	
-- EXEC REPORT_GET_VOTING_SUMMARY 39, '', '', '', '', '', '', 'DATE', 'DESC'
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_VOTING_SUMMARY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REPORT_GET_VOTING_SUMMARY created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REPORT_GET_VOTING_SUMMARY.';
END
GO
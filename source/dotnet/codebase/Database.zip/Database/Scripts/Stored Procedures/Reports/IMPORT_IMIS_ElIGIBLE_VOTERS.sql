SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IMPORT_IMIS_ElIGIBLE_VOTERS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IMPORT_IMIS_ElIGIBLE_VOTERS.';
	DROP PROCEDURE IMPORT_IMIS_ElIGIBLE_VOTERS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: IMPORT_IMIS_ElIGIBLE_VOTERS
 * --Purpose/Function		: Get Sub Category ID and Submission Type as comma separated
 * --Author					: MRI
 * --Start Date(MM/DD/YY)	: 10/28/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/02/2010		MZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[IMPORT_IMIS_ELIGIBLE_VOTERS]

AS
	BEGIN 

TRUNCATE TABLE IMIS_ELIGIBLE_VOTERS;

INSERT INTO [IMIS_ELIGIBLE_VOTERS]
           ([IMISUserID]
           ,[OrganizationID]
           ,[CouncilID]
           ,[Organization]
           ,[Council])

SELECT 
	a.id as IMIS_User_ID,        	
	e.id as Organization_ID,	
	c.PrimaryCouncil as Council,
	e.Company as Organization,
	
CASE WHEN c.PrimaryCouncil = 'CON' THEN 'Consumer' 
	 WHEN c.PrimaryCouncil = 'HPL' THEN 'Health Plan' 
	 WHEN c.PrimaryCouncil = 'PRO' THEN 'Provider Organizations' 
	 WHEN c.PrimaryCouncil = 'PCH' THEN 'Public - Community Health Agency' 
	 WHEN c.PrimaryCouncil = 'PUR' THEN 'Purchaser'
	 WHEN c.PrimaryCouncil = 'QMRI' THEN 'QMRI'
	 WHEN c.PrimaryCouncil = 'SPI' THEN 'Supplier - Industry'
	 WHEN c.PrimaryCouncil = 'HPR' THEN 'Health Professionals'
 END AS Council

FROM 

LinkToIMISDB.iMIS_NQF_Dev.dbo.NAME a, 
LinkToIMISDB.iMIS_NQF_Dev.dbo.RELATIONSHIP b , 
LinkToIMISDB.iMIS_NQF_Dev.dbo.NQF_DEMO c,  
LinkToIMISDB.iMIS_NQF_Dev.dbo.NAME_SECURITY d,  
LinkToIMISDB.iMIS_NQF_Dev.dbo.NAME e 

WHERE 
      a.id = b.id 
and a.id = d.id
and a.member_type='IMO'

and b.target_id = e.id
and b.relation_type = 'MPC' 
and b.status='A' --RELATION STATUS


and c.id = e.id
and (e.Status = 'A' or c.StatusOverride=1  ) --MEMBER STATUS

and d.web_login !=''

order by a.company

	END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IMPORT_IMIS_ElIGIBLE_VOTERS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IMPORT_IMIS_ElIGIBLE_VOTERS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IMPORT_IMIS_ElIGIBLE_VOTERS.';
END
GO
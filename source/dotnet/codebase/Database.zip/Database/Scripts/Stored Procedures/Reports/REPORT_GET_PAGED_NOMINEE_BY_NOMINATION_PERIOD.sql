SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD.';
	DROP PROCEDURE REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD
 * --Purpose/Function		: Get Sub Category ID and Submission Type as comma separated
 * --Author					: MI
 * --Start Date(MM/DD/YY)	: 11/1/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/1/2009		MI		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD](
	@NominationPeriodID VARCHAR(max)	
	, @PageNo INT
	, @PageSize INT	
	, @SortField VARCHAR(55)
	, @SortOrder VARCHAR(4)
	, @CommitteeID VARCHAR(max)
	, @StatusID VARCHAR(max)	
	, @NominationDateStart DATETIME
	, @NominationDateEnd DATETIME
	--, @CommitteeSortDirection VARCHAR(4)
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
	DECLARE @SQL VARCHAR(6000);
	DECLARE @StartRecord BIGINT;
	DECLARE @EndRecord BIGINT;
	DECLARE @TablePrefix VARCHAR(6);
	DECLARE @CommitteeIDs VARCHAR(max);
	DECLARE @StatusIDs VARCHAR(max);
	
	SET @StartRecord = (@PageNo - 1) * @PageSize;
	SET @EndRecord = @PageNo * @PageSize;
	SET @TablePrefix = 'NC.';
	
	IF(@NominationDateStart = '')
		SET @NominationDateStart = CONVERT(DATETIME,'01/30/1900')
	IF(@NominationDateEnd = '')
		SET @NominationDateEnd = CONVERT(DATETIME,'12/30/2100')

	SET @NominationDateStart = ISNULL(@NominationDateStart ,CONVERT(DATETIME,'01/30/1900'))
	SET @NominationDateEnd = ISNULL(@NominationDateEnd ,CONVERT(DATETIME,'12/30/2100'))

	SET @CommitteeIDs = ''
	IF @CommitteeID <> ''
	BEGIN
		SET @CommitteeIDs = ' AND dbo.Committee.CommitteeID IN (' + @CommitteeID + ') '
	END

	SET @StatusIDs = ''
	IF @StatusID <> ''
	BEGIN
		SET @StatusIDs = ' AND dbo.NOMINEE_COMMITTEE.StatusID IN (' + @StatusID + ') '
	END

	IF (@SortField = 'NomineeFirstName') 
	BEGIN 
		SET @SortField = 'FirstName';
	END
	ELSE IF (@SortField = 'NomineeLastName') 
	BEGIN 
		SET @SortField = 'LastName';
	END

	

	IF(@SortField = 'FormsComplete')
	BEGIN
		DECLARE @TotalRecordCount BIGINT;
		CREATE TABLE #Nominees (NomineeID BIGINT 
			, Prefix [VARCHAR](50)	
			, Suffix [VARCHAR](50)
			, UserName [VARCHAR](50)
			, Organization [VARCHAR](200)
			, NomineeFirstName [VARCHAR](500)
			, NomineeLastName [VARCHAR](500)
			, MemberCouncil [VARCHAR](500)
			, City [VARCHAR](100)
			, State [VARCHAR](50)
			, Email	[VARCHAR](100)				
			, ShortBiography [VARCHAR](750)
			, NominatedOn DATETIME
			, AddedOnAdhoc BIT										
			, UpdatedBy	[VARCHAR](50)
			, FormsComplete BIT
		);		
		INSERT INTO #Nominees(NomineeID					
				, Prefix
				, Suffix
				, UserName	
				, Organization
				, NomineeFirstName
				, NomineeLastName
				, MemberCouncil
				, City
				, State
				, Email					
				, NominatedOn
				, AddedOnAdhoc					
				, UpdatedBy								
				, FormsComplete) 
			SELECT NC.NomineeID					
				, NC.Prefix
				, NC.Suffix
				, NC.UserName
				, NC.Organization
				, NC.FirstName AS NomineeFirstName
				, NC.LastName AS NomineeLastName					
				, NC.MemberCouncil
				, NC.City
				, NC.State
				, NC.Email										
				, NC.NominatedOn
				, NC.AddedOnAdhoc																		
				, NC.UpdatedBy
				,(SELECT dbo.HAS_NOMINEE_FORM_COMPLETED(NC.NomineeID) ) AS FormsComplete					
			FROM dbo.NOMINEE_OF_COMMITTEE NC
			WHERE NC.NomineeID IN
			(
				SELECT DISTINCT NomineeID 
				FROM dbo.NOMINEE_COMMITTEE
				INNER JOIN dbo.Committee ON NOMINEE_COMMITTEE.CommitteeID = Committee.CommitteeID
				WHERE  Committee.ProjectStepIDForNominationPeriod IN (@NominationPeriodID)
			);

		IF (@SortOrder = 'ASC')
		BEGIN
			WITH AllNominees AS(
			SELECT NomineeID					
				, Prefix
				, Suffix
				, UserName	
				, Organization
				, NomineeFirstName
				, NomineeLastName
				, MemberCouncil
				, City
				, State
				, Email					
				, NominatedOn
				, AddedOnAdhoc					
				, UpdatedBy								
				, FormsComplete	
				, ROW_NUMBER() OVER(ORDER BY FormsComplete ASC) AS RowNumber			
			FROM #Nominees )
			SELECT NomineeID					
				, Prefix
				, Suffix
				, UserName	
				, Organization
				, NomineeFirstName
				, NomineeLastName
				, MemberCouncil
				, City
				, State
				, Email					
				, NominatedOn
				, AddedOnAdhoc					
				, UpdatedBy								
				, FormsComplete
				, ISNULL(@TotalRecordCount, (SELECT COUNT(NomineeID) FROM AllNominees)) AS TotalRecord	
			FROM AllNominees
			WHERE RowNumber > @StartRecord
			AND RowNumber <= @EndRecord	
		END
		ELSE				
		BEGIN
			WITH AllNominees AS(
			SELECT NomineeID					
				, Prefix
				, Suffix
				, UserName	
				, Organization
				, NomineeFirstName
				, NomineeLastName
				, MemberCouncil
				, City
				, State
				, Email					
				, NominatedOn
				, AddedOnAdhoc					
				, UpdatedBy								
				, FormsComplete	
				, ROW_NUMBER() OVER(ORDER BY FormsComplete DESC) AS RowNumber			
			FROM #Nominees )
			SELECT NomineeID					
				, Prefix
				, Suffix
				, UserName	
				, Organization
				, NomineeFirstName
				, NomineeLastName
				, MemberCouncil
				, City
				, State
				, Email					
				, NominatedOn
				, AddedOnAdhoc					
				, UpdatedBy								
				, FormsComplete
				, ISNULL(@TotalRecordCount, (SELECT COUNT(NomineeID) FROM AllNominees)) AS TotalRecord	
			FROM AllNominees
			WHERE RowNumber > @StartRecord
			AND RowNumber <= @EndRecord			
		END
		DROP TABLE #Nominees
	END
	ELSE
	BEGIN
		SET @SQL = 'DECLARE @TotalRecordCount BIGINT;
				WITH AllNominees AS(	
				SELECT NC.NomineeID					
					, NC.Prefix
					, NC.Suffix
					, NC.Title_Credential
					, NC.Affiliation
					, NC.UserName
					, NC.Organization
					, NC.FirstName AS NomineeFirstName
					, NC.LastName AS NomineeLastName					
					, NC.MemberCouncil
					, NC.City
					, NC.State
					, NC.Email					
					, NC.ShortBiography
					, NC.NominatedOn
					, NC.AddedOnAdhoc					
					, NC.IsSyncedWithIMIS
					, NC.ReasonForAddition					
					, NC.UpdatedBy
					,(SELECT dbo.HAS_NOMINEE_FORM_COMPLETED(NC.NomineeID) ) AS FormsComplete
					, ROW_NUMBER() OVER(ORDER BY ' + @TablePrefix + @SortField + ' ' + @SortOrder + ') AS RowNumber	
					, C.CommitteeName
					, NSFC.StatusName
					, OPS.WebTitle

				FROM dbo.NOMINEE_COMMITTEE NOMCOM 
					INNER JOIN dbo.NOMINEE_OF_COMMITTEE NC ON NOMCOM.NomineeID = NC.NomineeID
					INNER JOIN NOMINATION_STATUS_FOR_COMMITEE NSFC ON NOMCOM.StatusID = NSFC.StatusID
					INNER JOIN COMMITTEE C ON NOMCOM.CommitteeID = C.CommitteeID
					INNER JOIN dbo.OPUS_PROJECT_STEPS OPS ON C.ProjectStepIDForNominationPeriod = OPS.ProjectStepID

				--INNER JOIN NOMINATOR_OF_COMMITEE_NOMINATION NCN ON NC.NomineeID = NCN.NomineeID
				--INNER JOIN COMMITTEE C ON NC.CommiteeID = C.CommitteeID
				--INNER JOIN COMMITTEE_TYPE CT ON C.CommitteeTypeID = CT.CommitteeTypeID
				--INNER JOIN NOMINATION_STATUS_FOR_COMMITEE NSFC ON NSFC.StatusID = NC.StatusID
				
				WHERE NC.NomineeID IN
				(
					SELECT NomineeID 
					FROM dbo.NOMINEE_COMMITTEE
					INNER JOIN dbo.Committee ON NOMINEE_COMMITTEE.CommitteeID = Committee.CommitteeID AND NOMINEE_COMMITTEE.SELECTED = 1
					WHERE  
					(CONVERT(VARCHAR(20),NC.NominatedOn, 101) >= ''' + CONVERT(VARCHAR(20),@NominationDateStart, 101) + ''')
					AND (CONVERT(VARCHAR(20),NC.NominatedOn, 101) <= ''' + CONVERT(VARCHAR(20),@NominationDateEnd, 101) + ''')					
					AND Committee.ProjectStepIDForNominationPeriod IN (' + @NominationPeriodID + ')' + @CommitteeIDs + @StatusIDs + '
				) '			
				
		SET @SQL = 	@SQL + ')
				SELECT NomineeID					
					, Prefix
					, Suffix
					, Title_Credential
					, Affiliation
					, UserName	
					, Organization
					, NomineeFirstName
					, NomineeLastName
					, MemberCouncil
					, City
					, State
					, Email					
					, NominatedOn
					, AddedOnAdhoc					
					, UpdatedBy								
					, FormsComplete										
					, ISNULL(@TotalRecordCount, (SELECT COUNT(NomineeID) FROM AllNominees)) AS TotalRecord
					, ( 
						SELECT 
							CONVERT(VARCHAR(max), CommitteeName) + ''('' + CONVERT(VARCHAR(max), StatusName) + '')'' + '', '' AS [text()]
						FROM 
							AllNominees A
						WHERE A.NomineeID =  AllNominees.NomineeID
						ORDER BY A.CommitteeName
						FOR XML PATH ('''') 
						) AS CommitteeName
					, StatusName
					, WebTitle
				FROM AllNominees
					WHERE RowNumber > ' + CAST(@StartRecord AS VARCHAR) + '
					AND RowNumber <= ' + CAST(@EndRecord AS VARCHAR);		
		EXEC (@SQL);
	END	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REPORT_GET_PAGED_NOMINEE_BY_NOMINATION_PERIOD.';
END
GO
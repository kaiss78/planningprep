SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID.';
	DROP PROCEDURE OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPLM
 * --Procedure name			: OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID
 * --Purpose/Function		: Gets Document History objects by related with provided project id
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 10/18/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/18/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID(
	@DocumentID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT DocumentHistoryID
		, DocumentID
		, UpdateReason
		, history.UserID
		, DTS
		, FirstName + ' ' + LastName AS UserName
	FROM dbo.OPLM_PROJECT_DOCUMENT_HISTORY AS history
		INNER JOIN dbo.OPLM_USER AS usr ON history.UserID = usr.UserID	
	WHERE DocumentID = @DocumentID
	ORDER BY DTS DESC
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_DOCUMENT_HISTORY_BY_DOCUMENT_ID.';
END
GO
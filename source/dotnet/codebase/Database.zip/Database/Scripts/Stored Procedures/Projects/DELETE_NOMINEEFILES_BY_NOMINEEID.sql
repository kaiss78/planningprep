SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'DELETE_NOMINEEFILES_BY_NOMINEEID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure DELETE_NOMINEEFILES_BY_NOMINEEID.';
	DROP PROCEDURE DELETE_NOMINEEFILES_BY_NOMINEEID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: DELETE_NOMINEEFILES_BY_NOMINEEID
 * --Purpose/Function		: DELETE NOMINATION PERIOD
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 11/30/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[DELETE_NOMINEEFILES_BY_NOMINEEID](
	@NomineeID BIGINT
)
AS
BEGIN
	DELETE FROM dbo.NOMINEES_FILES
	WHERE NomineeID = @NomineeID	

END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'DELETE_NOMINEEFILES_BY_NOMINEEID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure DELETE_NOMINEEFILES_BY_NOMINEEID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure DELETE_NOMINEEFILES_BY_NOMINEEID.';
END
GO
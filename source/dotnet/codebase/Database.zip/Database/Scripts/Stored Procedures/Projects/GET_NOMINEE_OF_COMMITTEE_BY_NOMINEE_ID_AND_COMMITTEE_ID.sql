SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID.';
	DROP PROCEDURE GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID
 * --Purpose/Function		: GET NOMINEE OF COMMITTEE BY NOMINEE ID AND COMMITTEE ID
 * --Author					: MI
 * --Start Date(MM/DD/YY)	: 12/03/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/03/2009		MI		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID](
	@NomineeID BIGINT	
	, @CommitteeID BIGINT	
	, @PageNo INT
	, @PageSize INT	
	, @SortField VARCHAR(55)
	, @SortOrder VARCHAR(4)	
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
	DECLARE @SQL VARCHAR(3000);
	DECLARE @StartRecord BIGINT;
	DECLARE @EndRecord BIGINT;
	DECLARE @TablePrefix VARCHAR(4);	
	
	SET @StartRecord = (@PageNo - 1) * @PageSize;
	SET @EndRecord = @PageNo * @PageSize;
	SET @TablePrefix = 'NC.';
																
	IF (@SortField = 'NominatorFirstName' OR @SortField = 'NominatorLastName') 
	BEGIN 
		SET @TablePrefix = 'NCN.';	
	END
	
	IF (@SortField = 'NominatorFirstName' OR @SortField = 'NomineeFirstName') 
	BEGIN 
		SET @SortField = 'FirstName';
	END
	ELSE IF (@SortField = 'NomineeLastName' OR @SortField = 'NominatorLastName') 
	BEGIN 
		SET @SortField = 'LastName';
	END
	

	SET @SQL = 'WITH AllNominees AS(	
				SELECT NC.NomineeID
					, NC.Prefix
					, NC.FirstName AS NomineeFirstName
					, NC.LastName AS NomineeLastName
					, NC.Title_Credential
					, NC.Affiliation
					, NC.MemberCouncil
					, NC.City
					, NC.State
					, NC.Email
					, NC.ShortBiography
					, NC.NominatedOn
					, NC.AddedOnAdhoc
					, NC.WorkflowInstanceID
					, NC.CurrentState
					, NC.IMISIntegrationID
					, NC.IMISContactID
					, NC.IsSyncedWithIMIS
					, NC.ReasonForAddition
					, NOMCOM.StatusID
					, NOMCOM.AcceptanceEmailSent
					, NOMCOM.RejectionEmailSent
					, NC.Suffix
					, (SELECT ProjectID FROM COMMITTEE WHERE COMMITTEE.CommitteeID = ' + CAST(@CommitteeID AS VARCHAR(20)) + ') ProjectID
					, (SELECT StatusName FROM NOMINATION_STATUS_FOR_COMMITEE WHERE NOMINATION_STATUS_FOR_COMMITEE.StatusID = NOMCOM.StatusID) StatusName
					, (SELECT ShortName FROM OPLM_PROJECT_PRIMARY_DATA WHERE OPLM_PROJECT_PRIMARY_DATA.ProjectID = (SELECT ProjectID FROM COMMITTEE WHERE COMMITTEE.CommitteeID = ' + CAST(@CommitteeID AS VARCHAR(20)) + ')) ProjectName
					, (SELECT ShortDescription FROM OPLM_PROJECT_SECONDARY_DATA WHERE OPLM_PROJECT_SECONDARY_DATA.ProjectID = (SELECT ProjectID FROM COMMITTEE WHERE COMMITTEE.CommitteeID = ' + CAST(@CommitteeID AS VARCHAR(20)) + ')) ShortDescription
					, NC.UpdatedBy
					, NCN.Orgnanization	 AS NominatorOrganization		
					, NCN.FirstName AS NominatorFirstName	
					, NCN.LastName AS NominatorLastName
					, NCN.Email AS NominatorEmail
					, NCN.PhoneNo AS NominatorPhone	
					, NCN.AdditionalEndorsements AS NominatorEndorsements
					, ROW_NUMBER() OVER(ORDER BY ' + @TablePrefix + @SortField + ' ' + @SortOrder + ') AS RowNumber	
				FROM dbo.NOMINEE_OF_COMMITTEE NC
				INNER JOIN NOMINATOR_OF_COMMITEE_NOMINATION NCN ON NC.NomineeID = NCN.NomineeID
				INNER JOIN NOMINEE_COMMITTEE NOMCOM ON NOMCOM.NomineeID = NC.NomineeID
				WHERE NOMCOM.CommitteeID = ' + CAST(@CommitteeID AS VARCHAR) + ' AND NOMCOM.NomineeID = ' + CAST(@NomineeID AS VARCHAR);	
	SET @SQL = 	@SQL + ')
				SELECT NomineeID
					, Prefix
					, NomineeFirstName
					, NomineeLastName
					, Title_Credential
					, Affiliation
					, MemberCouncil
					, City
					, State
					, Email
					, ShortBiography
					, NominatedOn
					, AddedOnAdhoc
					, WorkflowInstanceID
					, CurrentState
					, IMISIntegrationID
					, IMISContactID
					, IsSyncedWithIMIS
					, NominatorOrganization		
					, NominatorFirstName	
					, NominatorLastName
					, NominatorEmail
					, NominatorPhone	
					, NominatorEndorsements
					, ReasonForAddition
					, StatusID
					, AcceptanceEmailSent
					, RejectionEmailSent
					, UpdatedBy
					, Suffix
					, ProjectID
					, StatusName
					, ProjectName
					, ShortDescription
					, (SELECT COUNT(NomineeID) FROM AllNominees) AS TotalRecord
				FROM AllNominees
					WHERE RowNumber > ' + CAST(@StartRecord AS VARCHAR) + '
					AND RowNumber <= ' + CAST(@EndRecord AS VARCHAR);
	PRINT @SQL;
	EXEC (@SQL);		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_NOMINEE_OF_COMMITTEE_BY_NOMINEE_ID_AND_COMMITTEE_ID.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_COMMITTEE.';
	DROP PROCEDURE SAVE_COMMITTEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_COMMITTEE
 * --Purpose/Function		: Saves a committee object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_COMMITTEE(
	@CommitteeID BIGINT
	, @CommitteeTypeID BIGINT
	, @ProjectID BIGINT
	, @CommitteeName VARCHAR(255)
	, @ProjectStepIDForCommenting BIGINT
	, @ProjectStepIDForNominationPeriod BIGINT
	, @CreateWebLink BIT
	, @MeetingStartDate DATETIME
	, @MeetingEndDate DATETIME
	, @Background VARCHAR(MAX)
	, @iMISCode VARCHAR(50)
	, @IsActive BIT
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.COMMITTEE WHERE CommitteeID = @CommitteeID)
	BEGIN
		
		DELETE FROM COMMITTEE_MEETING_DATES WHERE CommitteeID = @CommitteeID	
		-- Update Existing committee Information
		UPDATE dbo.COMMITTEE SET
			CommitteeTypeID = @CommitteeTypeID
			, ProjectID = @ProjectID
			, CommitteeName = @CommitteeName
			, ProjectStepIDForCommenting = @ProjectStepIDForCommenting
			, ProjectStepIDForNominationPeriod = @ProjectStepIDForNominationPeriod
			, CreateWebLink = @CreateWebLink
			, MeetingStartDate = @MeetingStartDate
			, MeetingEndDate = @MeetingEndDate
			, Background = @Background
			, iMISCode = @iMISCode
			, IsActive=@IsActive
		WHERE CommitteeID = @CommitteeID;
			
	IF @IsActive=0
	BEGIN	
		UPDATE COMMITTEE_MEMBER SET 
				IsActive=0
		WHERE  CommitteeID=@CommitteeID
	END

		SET @GeneratedID = @CommitteeID;
			
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.COMMITTEE
		INSERT INTO dbo.COMMITTEE (CommitteeTypeID
			, ProjectID
			, CommitteeName
			, ProjectStepIDForCommenting
			, ProjectStepIDForNominationPeriod
			, CreateWebLink
			, MeetingStartDate
			, MeetingEndDate
			, Background
			, iMISCode
			, IsActive)
		VALUES(@CommitteeTypeID
			, @ProjectID
			, @CommitteeName
			, @ProjectStepIDForCommenting
			, @ProjectStepIDForNominationPeriod
			, @CreateWebLink
			, @MeetingStartDate
			, @MeetingEndDate
			, @Background
			, @iMISCode
			, 1);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_COMMITTEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_COMMITTEE.';
END
GO
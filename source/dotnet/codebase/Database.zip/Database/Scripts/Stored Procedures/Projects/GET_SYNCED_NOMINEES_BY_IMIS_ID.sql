SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_SYNCED_NOMINEES_BY_IMIS_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_SYNCED_NOMINEES_BY_IMIS_ID.';
	DROP PROCEDURE GET_SYNCED_NOMINEES_BY_IMIS_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_SYNCED_NOMINEES_BY_IMIS_ID
 * --Purpose/Function		: Gets GET SYNCED NOMINEES BY IMIS ID
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 10/24/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/19/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_SYNCED_NOMINEES_BY_IMIS_ID
(
	@imiscontactid BIGINT
	,@projectStepIDForNominationPeriod BIGINT
)
AS
BEGIN
  

	SET NOCOUNT ON;
 
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @REOPENED BIT;
 

    IF  exists(select nom.reopened 
FROM   nominee_of_committee nom
		   INNER JOIN committee com
			 ON nom.commiteeid = com.committeeid
	WHERE  nom.statusid <> 4
		   AND nom.imiscontactid = @imiscontactid
		   and com.projectStepIDForNominationPeriod = 117
           AND nom.reopened = @projectStepIDForNominationPeriod )
BEGIN
  SET @REOPENED=1
END
ELSE
BEGIN
SET @REOPENED=0
END


	SELECT nom.nomineeid,
		   REOPENED 'reopened',
		   nom.statusid,
		   nom.commiteeid,
		   nom.imiscontactid,
		   com.committeename
		   
	FROM   nominee_of_committee nom
		   INNER JOIN committee com
			 ON nom.commiteeid = com.committeeid
	WHERE  nom.statusid <> 4
		   AND nom.imiscontactid = @imiscontactid
		   and com.projectStepIDForNominationPeriod =  @projectStepIDForNominationPeriod 

END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_SYNCED_NOMINEES_BY_IMIS_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_SYNCED_NOMINEES_BY_IMIS_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_SYNCED_NOMINEES_BY_IMIS_ID.';
END
GO

-- exec GET_SYNCED_NOMINEES_BY_IMIS_ID 111193,117
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_PRIMARY_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_PROJECT_PRIMARY_DATA.';
	DROP PROCEDURE OPLM_SAVE_PROJECT_PRIMARY_DATA;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: OPLM
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_PROJECT_PRIMARY_DATA
 * --Purpose/Function		: Retrieves users by username
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 06/06/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 01/10/09		AFS	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_SAVE_PROJECT_PRIMARY_DATA](
	@ProjectID BIGINT
	, @LongTitle NVARCHAR(2000)
	, @ShortName NVARCHAR(255)
	, @StartDate DATETIME
	, @EndDate DATETIME
	, @ProjectTypeID BIGINT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.OPLM_PROJECT_PRIMARY_DATA WHERE ProjectID = @ProjectID)
	BEGIN
		-- Update Existing OPLMPROJECTPRIMARYDATA Information
		UPDATE dbo.OPLM_PROJECT_PRIMARY_DATA SET
			LongTitle = @LongTitle
			, ShortName = @ShortName
			, StartDate = @StartDate
			, EndDate = @EndDate
			, ProjectTypeID = @ProjectTypeID
			, UpdatedDate = getdate()
		WHERE ProjectID = @ProjectID;
		SET @GeneratedID = @ProjectID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_PRIMARY_DATA
		INSERT INTO dbo.OPLM_PROJECT_PRIMARY_DATA (
             ProjectID
            ,LongTitle
			, ShortName
			, StartDate
			, EndDate
			, ProjectTypeID
			, UpdatedDate)
		VALUES(
            @ProjectID
            , @LongTitle
			, @ShortName
			, @StartDate
			, @EndDate
			, @ProjectTypeID
			, getdate());
		SET @GeneratedID =@ProjectID;	
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_PRIMARY_DATA'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_PROJECT_PRIMARY_DATA created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_PROJECT_PRIMARY_DATA.';
END
GO




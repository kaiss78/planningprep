SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_CHILD_STEPS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_ALL_CHILD_STEPS.';
	DROP PROCEDURE GET_ALL_CHILD_STEPS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_ALL_CHILD_STEPS
 * --Purpose/Function		: GET ALL CHILD STEPS 
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 11/18/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_ALL_CHILD_STEPS](
	@ParentProjectStepID BIGINT
	,@ChildStepCode int
)
AS
BEGIN
	SELECT 
		  ps.[ProjectStepID]
		  ,ps.[ProjectStepName]
		  ,ps.[ParentProjectStepID]
		  ,ps.[stepID]
		  ,ps.[ProjectID]--
		  ,pss.[ProjectSetupID]      
		  ,pss.[WebTitle]
		  ,pss.[StartDate]
		  ,pss.[EndDate]
		  ,pss.[BeforePeriodDescription]
		  ,pss.[DuringPeriodDescription]
		  ,pss.[AfterPeriodDescription]
		  ,pss.[Background]
		  ,pss.[ScopeOfActivities]
		  ,pss.[NQFProcess]
		  ,pss.[Instructions]
		  ,pss.[Remarks]
		  ,pss.[UpdatedBy]
		  ,pss.[DTS]
		  ,pss.[Status]
		  ,pss.[DetailPageURL]
		  ,ps.[ChildStepCode]
	  FROM 
		  [PROJECT_STEPS] ps
	  INNER JOIN
		  [PROJECT_STEP_SETUP] pss
	  ON
			ps.ProjectStepID = pss.ProjectStepID
	  WHERE
			ps.ParentProjectStepID = @ParentProjectStepID
			AND ps.ChildStepCode = @ChildStepCode


-- EXEC GET_ALL_CHILD_STEPS 11
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_ALL_CHILD_STEPS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_ALL_CHILD_STEPS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_ALL_CHILD_STEPS.';
END
GO
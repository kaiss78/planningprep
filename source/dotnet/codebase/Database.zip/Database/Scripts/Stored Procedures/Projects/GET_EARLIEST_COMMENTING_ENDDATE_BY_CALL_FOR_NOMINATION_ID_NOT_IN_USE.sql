SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID.';
	DROP PROCEDURE GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID
 * --Purpose/Function		: GET EARLIEST COMMENTING ENDDATE BY CALL FOR NOMINATION ID
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 11/22/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID](
	@CallForNominationID BIGINT
)
AS
BEGIN
	--	SELECT TOP(1) StartDate FROM project_step_setup
--	WHERE ProjectStepID in
--	(SELECT ProjectStepID FROM project_steps ps
--	WHERE ParentProjectStepID in 
--	(SELECT ProjectStepID FROM project_steps
--	WHERE ParentProjectStepID = @CallForNominationID))
--	ORDER BY StartDate

SELECT 
	MIN(pss.StartDate)
FROM
	project_step_setup pss
INNER JOIN
	project_steps ps
ON
	pss.ProjectStepID = ps.ProjectStepID
WHERE
	ps.ParentProjectStepID = @CallForNominationID
	AND ps.ChildStepCode = 2

	

-- EXEC GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID 166
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_EARLIEST_COMMENTING_ENDDATE_BY_CALL_FOR_NOMINATION_ID.';
END
GO
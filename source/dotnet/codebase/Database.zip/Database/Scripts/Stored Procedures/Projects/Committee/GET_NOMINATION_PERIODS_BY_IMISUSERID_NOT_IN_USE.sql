
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINATION_PERIODS_BY_IMISUSERID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_NOMINATION_PERIODS_BY_IMISUSERID.';
	DROP PROCEDURE GET_NOMINATION_PERIODS_BY_IMISUSERID;
END

GO

/* 
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_NOMINATION_PERIODS_BY_IMISUSERID
 * --Purpose/Function		: Saves a ProjectType object
 * --Author					: MRZ
 * --Start Date(MM/DD/YY)	: 10/13/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/13/2009		MRZ		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_NOMINATION_PERIODS_BY_IMISUSERID]
@IMISContactID bigint
AS
BEGIN
	BEGIN TRY
		BEGIN
			SELECT 
			  ps.[ProjectStepID]
			  ,ps.[ProjectStepName]
			  ,ps.[ParentProjectStepID]
			  ,ps.[stepID]
			  ,ps.[ProjectID]--
			  ,pss.[ProjectSetupID]      
			  ,pss.[WebTitle]
			  ,pss.[StartDate]
			  ,pss.[EndDate]
			  ,pss.[BeforePeriodDescription]
			  ,pss.[DuringPeriodDescription]
			  ,pss.[AfterPeriodDescription]
			  ,pss.[Background]
			  ,pss.[ScopeOfActivities]
			  ,pss.[NQFProcess]
			  ,pss.[Instructions]
			  ,pss.[Remarks]
			  ,pss.[UpdatedBy]
			  ,pss.[DTS]
			  ,pss.[Status]
			  ,pss.[DetailPageURL]
			  ,ps.[ChildStepCode]
		  FROM 
			  [PROJECT_STEPS] ps
		  INNER JOIN
			  [PROJECT_STEP_SETUP] pss
		  ON
				ps.ProjectStepID = pss.ProjectStepID
		  WHERE
				pss.ProjectStepID IN(
				SELECT C.ProjectStepIDForNominationPeriod 
				FROM NOMINEE_OF_COMMITTEE NC, 
				NOMINATOR_OF_COMMITEE_NOMINATION NCN, 
				COMMITTEE C,
				NOMINEE_COMMITTEE NCR
				WHERE NC.NOMINEEID = NCN.NOMINEEID 
				AND C.COMMITTEEID = NCR.COMMITTEEID 
				AND C.ISACTIVE = 1 
				AND C.ProjectStepIDForNominationPeriod IS NOT NULL
				AND  NC.IMISCONTACTID = @IMISContactID)
		END	
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();   

		RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
	END CATCH
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINATION_PERIODS_BY_IMISUSERID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_NOMINATION_PERIODS_BY_IMISUSERID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_NOMINATION_PERIODS_BY_IMISUSERID.';
END
GO

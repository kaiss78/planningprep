SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID.';
	DROP PROCEDURE OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID
 * --Purpose/Function		: Gets FundingContactRoleID objects by ContactID
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/19/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/19/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID(
	@ContactRoleID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT ContactRoleID
		, ContactID
		, ProjectID
		, RoleID
		, (SELECT OPLM_CONTACT_ROLE.RoleName FROM OPLM_CONTACT_ROLE WHERE OPLM_CONTACT_ROLE.RoleID = OPLM_FUNDING_CONTACT_ROLE.RoleID)RoleName
	FROM dbo.OPLM_FUNDING_CONTACT_ROLE
	WHERE ContactRoleID = @ContactRoleID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_FUNDING_CONTACT_ROLE_BY_ID.';
END
GO

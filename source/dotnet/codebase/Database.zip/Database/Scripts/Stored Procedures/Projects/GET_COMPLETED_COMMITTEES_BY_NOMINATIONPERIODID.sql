SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID.';
	DROP PROCEDURE GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID
 * --Purpose/Function		: Gets Member objects by ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/21/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/21/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID(
	@NominationPeriodID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT * FROM 
	(
		SELECT COMMITTEE.CommitteeID
			, COMMITTEE.CommitteeTypeID
			, COMMITTEE.ProjectID
			, COMMITTEE.CommitteeName
			, COMMITTEE.ProjectStepIDForCommenting
			, COMMITTEE.ProjectStepIDForNominationPeriod
			, COMMITTEE.CreateWebLink
			, COMMITTEE.MeetingStartDate
			, COMMITTEE.MeetingEndDate
			, COMMITTEE.Background
			, COMMITTEE.iMISCode
			, COMMITTEE.IsActive  
			, COMMITTEE_TYPE.CommitteeType 
			, (SELECT COUNT(*) FROM dbo.COMMITTEE_MEETING_DATES WHERE CommitteeID = COMMITTEE.CommitteeID) AS MeetingDateCount
		FROM dbo.COMMITTEE
		--INNER JOIN COMMITTEES_WITH_MEETING_DATES ON COMMITTEE.CommitteeID = COMMITTEES_WITH_MEETING_DATES.CommitteeID
		INNER JOIN  dbo.COMMITTEE_TYPE ON dbo.COMMITTEE.CommitteeTypeID = dbo.COMMITTEE_TYPE.CommitteeTypeID
		WHERE dbo.COMMITTEE.ProjectStepIDForNominationPeriod = @NominationPeriodID	
		AND ISNULL(dbo.COMMITTEE.Background,'') <> ''
		AND ISNULL(dbo.COMMITTEE.CommitteeTypeID,'') <> ''
		AND ISNULL(dbo.COMMITTEE.CommitteeName,'') <> ''
		AND ISNULL(dbo.COMMITTEE.iMISCODE,'') <> ''
		AND COMMITTEE.IsActive = 1	
	) AS CompletedCommittees
	WHERE MeetingDateCount > 0;	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMPLETED_COMMITTEES_BY_NOMINATIONPERIODID.';
END
GO

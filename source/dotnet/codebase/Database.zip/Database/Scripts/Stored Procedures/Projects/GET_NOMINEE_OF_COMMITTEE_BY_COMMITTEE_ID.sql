SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID.';
	DROP PROCEDURE GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID
 * --Purpose/Function		: GET NOMINEE OF COMMITTEE BY COMMITTEE ID
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 11/19/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID](
	@CommitteeID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT Nominee.NomineeID
		, Rel.CommitteeID
		, Nominee.Prefix
		, Nominee.FirstName
		, Nominee.LastName
		, Nominee.Title_Credential
		, Nominee.Affiliation
		, Nominee.MemberCouncil
		, Nominee.City
		, Nominee.State
		, Nominee.Email
		, Nominee.ShortBiography
		, Nominee.NominatedOn
		, Nominee.AddedOnAdhoc
		, Rel.StatusID
		, Nominee.WorkflowInstanceID
		, Nominee.CurrentState
		, Nominee.IMISIntegrationID
		, Nominee.IMISContactID
		, Nominee.IsSyncedWithIMIS
		, Nominee.ReasonForAddition
		, Rel.AcceptanceEmailSent
		, Rel.RejectionEmailSent
		, Nominee.Reopened
		, Nominee.UpdatedBy
		, Status.StatusName
		, Status.StatusID
		, UserName
		, Organization
		, Suffix

	FROM dbo.NOMINEE_OF_COMMITTEE Nominee
         INNER JOIN
         dbo.NOMINEE_COMMITTEE Rel
         ON
         Nominee.NomineeID = Rel.NomineeID
         INNER JOIN
        dbo.NOMINATION_STATUS_FOR_COMMITEE Status 
         ON
         Rel.StatusID = Status.StatusID
	WHERE rel.CommitteeID = @CommitteeID 
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_NOMINEE_OF_COMMITTEE_BY_COMMITTEE_ID.';
END
GO
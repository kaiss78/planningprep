

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS.';
	DROP PROCEDURE OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS
 * --Purpose/Function		: Saves a ProjectMaster object
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 10/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/12/2009		MHA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS(
	@OrganizationID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT ProjectID
		, OrganizationID
		, OrganizationName
	FROM dbo.OPLM_PROJECT_FUNDING_ORGANIZATIONS
	WHERE OrganizationID = @OrganizationID;	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_PROJECT_FUNDING_ORGANIZATIONS.';
END
GO



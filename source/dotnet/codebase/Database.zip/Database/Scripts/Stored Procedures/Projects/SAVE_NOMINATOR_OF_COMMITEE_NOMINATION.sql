SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINATOR_OF_COMMITEE_NOMINATION'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_NOMINATOR_OF_COMMITEE_NOMINATION.';
	DROP PROCEDURE SAVE_NOMINATOR_OF_COMMITEE_NOMINATION;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_NOMINATOR_OF_COMMITEE_NOMINATION
 * --Purpose/Function		: Saves a OfCommiteeNomination object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_NOMINATOR_OF_COMMITEE_NOMINATION(
	@NominatorID BIGINT
	, @iMISID BIGINT
	, @NomineeID BIGINT
	, @FirstName VARCHAR(500)
	, @LastName VARCHAR(500)
	, @PhoneNo VARCHAR(20)
	, @Email VARCHAR(100)
	, @Orgnanization VARCHAR(500)
	, @AdditionalEndorsements VARCHAR(5000)
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.NOMINATOR_OF_COMMITEE_NOMINATION WHERE NominatorID = @NominatorID)
	BEGIN
		-- Update Existing OfCommiteeNomination Information
		UPDATE dbo.NOMINATOR_OF_COMMITEE_NOMINATION SET
			iMISID = @iMISID
			, NomineeID = @NomineeID
			, FirstName = @FirstName
			, LastName = @LastName
			, PhoneNo = @PhoneNo
			, Email = @Email
			, Orgnanization = @Orgnanization
			, AdditionalEndorsements = @AdditionalEndorsements
		WHERE NominatorID = @NominatorID;
		SET @GeneratedID = @NominatorID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.NOMINATOR_OF_COMMITEE_NOMINATION
		INSERT INTO dbo.NOMINATOR_OF_COMMITEE_NOMINATION (iMISID
			, NomineeID
			, FirstName
			, LastName
			, PhoneNo
			, Email
			, Orgnanization
			, AdditionalEndorsements)
		VALUES(@iMISID
			, @NomineeID
			, @FirstName
			, @LastName
			, @PhoneNo
			, @Email
			, @Orgnanization
			, @AdditionalEndorsements);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINATOR_OF_COMMITEE_NOMINATION'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_NOMINATOR_OF_COMMITEE_NOMINATION created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_NOMINATOR_OF_COMMITEE_NOMINATION.';
END
GO

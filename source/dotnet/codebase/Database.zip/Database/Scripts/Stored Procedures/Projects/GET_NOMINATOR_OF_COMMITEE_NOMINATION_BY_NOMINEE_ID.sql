SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID.';
	DROP PROCEDURE GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID
 * --Purpose/Function		: Gets OfCommiteeNomination objects by ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID(
	@NomineeID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT NominatorID
		, iMISID
		, NomineeID
		, FirstName
		, LastName
		, PhoneNo
		, Email
		, Orgnanization
		, AdditionalEndorsements
	FROM dbo.NOMINATOR_OF_COMMITEE_NOMINATION
	WHERE NomineeID = @NomineeID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_NOMINATOR_OF_COMMITEE_NOMINATION_BY_NOMINEE_ID.';
END
GO


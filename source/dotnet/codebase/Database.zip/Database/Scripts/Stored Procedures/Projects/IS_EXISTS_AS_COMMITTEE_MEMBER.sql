SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_EXISTS_AS_COMMITTEE_MEMBER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure IS_EXISTS_AS_COMMITTEE_MEMBER.';
	DROP PROCEDURE IS_EXISTS_AS_COMMITTEE_MEMBER;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: IS_EXISTS_AS_COMMITTEE_MEMBER
 * --Purpose/Function		: Gets ProjectDocument objects by ID
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 12/3/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/1/2009		MI		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[IS_EXISTS_AS_COMMITTEE_MEMBER]
(
 @CommitteeID BIGINT
 ,@IMISUSERID VARCHAR(60)
 , @EXIST BIT OUTPUT

)
AS
BEGIN
	SET NOCOUNT ON;

IF EXISTS(SELECT cm.committeeid,
                 cmd.imisuserid
          FROM   committee_member_details cmd
                 INNER JOIN committee_member cm
                   ON cmd.memberid = cm.memberid
          WHERE  cm.committeeid = @CommitteeID
                 AND cmd.imisuserid = @IMISUSERID)
  BEGIN
      SET @EXIST = 1
  END
ELSE
  BEGIN
      SET @EXIST = 0
  END 



END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'IS_EXISTS_AS_COMMITTEE_MEMBER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure IS_EXISTS_AS_COMMITTEE_MEMBER created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure IS_EXISTS_AS_COMMITTEE_MEMBER.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOTE_FOR_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_NOTE_FOR_NOMINATION_PERIOD.';
	DROP PROCEDURE SAVE_NOTE_FOR_NOMINATION_PERIOD;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_NOTE_FOR_NOMINATION_PERIOD
 * --Purpose/Function		: SAVE NOTE FOR NOMINATION PERIOD
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 11/17/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[SAVE_NOTE_FOR_NOMINATION_PERIOD](
	@ProjectStepID BIGINT,
	@Note VARCHAR(500),
	@UpdatedBy VARCHAR(500),
	@Date DATETIME,
	@NoteType VARCHAR(50)
)
AS
BEGIN
	
	INSERT INTO dbo.NOTES (ProjectStepID, Note, UpdatedBy, Date, NoteType )
	VALUES (@ProjectStepID, @Note, @UpdatedBy, @Date, @NoteType )

-- EXEC SAVE_NOTE_FOR_NOMINATION_PERIOD 48, 'adsad kajhdas d', 'Syedur', '11/2/2009 7:00:00 PM'
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOTE_FOR_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_NOTE_FOR_NOMINATION_PERIOD created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_NOTE_FOR_NOMINATION_PERIOD.';
END
GO
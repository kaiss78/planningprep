
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_NOTES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_COMMITTEE_NOTES.';
	DROP PROCEDURE SAVE_COMMITTEE_NOTES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_COMMITTEE_NOTES
 * --Purpose/Function		: Saves a Committee Note object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[SAVE_COMMITTEE_NOTES](
	@NoteID BIGINT
	, @Notes VARCHAR(4000)
	, @MemberID BIGINT
	, @NotedBy BIGINT
	, @ProjectID BIGINT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.COMMITTEE_NOTES WHERE NoteID = @NoteID)
	BEGIN
		-- Update Existing ProjectDocument Information
		UPDATE dbo.COMMITTEE_NOTES SET
			Notes = @Notes
			, MemberID = @MemberID
			, NotedBy = @NotedBy
			, ProjectID = @ProjectID
			, DTS = GETDATE()
		WHERE NoteID = @NoteID;
		SET @GeneratedID = @NoteID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_DOCUMENT
		INSERT INTO dbo.COMMITTEE_NOTES (Notes
			, MemberID
			, NotedBy
			, ProjectID
			, DTS)
		VALUES(@Notes
			, @MemberID
			, @NotedBy
			, @ProjectID
			, GETDATE());
		SET @GeneratedID = SCOPE_IDENTITY();		
	END	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_NOTES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_COMMITTEE_NOTES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_COMMITTEE_NOTES.';
END
GO

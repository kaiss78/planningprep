SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEES_FOR_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMITTEES_FOR_NOMINATION_PERIOD.';
	DROP PROCEDURE GET_COMMITTEES_FOR_NOMINATION_PERIOD;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: GET_COMMITTEES_FOR_NOMINATION_PERIOD
 * --Purpose/Function		: Get Committee list for nomination period
 * --Author					: MH
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/25/2009		MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_COMMITTEES_FOR_NOMINATION_PERIOD](
	@ProjectID BIGINT = 31
)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		com.CommitteeID
		,com.CommitteeName
		,ISNULL(com.Background,'') AS Background
		,ISNULL(com.iMISCODE,'') AS iMISCODE
		,ISNULL(com.IsActive,0) AS IsActive
		,ISNULL(ProjectStepIDForCommenting,0) AS ProjectStepIDForCommenting
		,ISNULL(ProjectStepIDForNominationPeriod,0) AS ProjectStepIDForNominationPeriod
		,ct.CommitteeType
		,ISNULL(ps.ProjectStepName,'') AS NominationPeriodName
		,ISNULL(ps1.ProjectStepName,'') AS CommentingPeriodName
		,ISNULL(mm.CommitteeID,0) AS MeetingDateExist
	FROM 
		COMMITTEE com
	LEFT OUTER JOIN
		COMMITTEES_WITH_MEETING_DATES mm
	ON
		com.CommitteeID = mm.CommitteeID
	INNER JOIN 
		COMMITTEE_TYPE ct
	ON
		com.CommitteeTypeID = ct.CommitteeTypeID
	LEFT OUTER JOIN	
		OPUS_PROJECT_STEPS ps
	ON
		com.ProjectStepIDForNominationPeriod = ps.ProjectStepID
	LEFT OUTER JOIN	
		OPUS_PROJECT_STEPS ps1
	ON
		com.ProjectStepIDForCommenting = ps1.ProjectStepID
	WHERE
		com.ProjectID = @ProjectID
--select * from COMMITTEE

--	SELECT dbo.COMMITTEE.CommitteeID, dbo.COMMITTEE.CommitteeName, dbo.COMMITTEE_TYPE.CommitteeType
--	FROM dbo.COMMITTEE
--	INNER JOIN COMMITTEES_WITH_MEETING_DATES 
--	ON
--	COMMITTEE.CommitteeID = COMMITTEES_WITH_MEETING_DATES.CommitteeID
--	INNER JOIN  dbo.COMMITTEE_TYPE
--	ON
--	dbo.COMMITTEE.CommitteeTypeID = dbo.COMMITTEE_TYPE.CommitteeTypeID
--	WHERE dbo.COMMITTEE.ProjectID = @ProjectID AND dbo.COMMITTEE.ProjectStepIDForNominationPeriod IS NULL 	
--	AND ISNULL(dbo.COMMITTEE.Background,'') <> ''
--	AND ISNULL(dbo.COMMITTEE.CommitteeTypeID,'') <> ''
--	AND ISNULL(dbo.COMMITTEE.CommitteeName,'') <> ''
--	AND ISNULL(dbo.COMMITTEE.iMISCODE,'') <> ''
--	AND dbo.COMMITTEE.IsActive = 'True'
	
-- SELECT CommitteeType FROM dbo.COMMITTEE_TYPE WHERE 

-- EXEC GET_COMMITTEES_FOR_NOMINATION_PERIOD 2	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEES_FOR_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMITTEES_FOR_NOMINATION_PERIOD created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMITTEES_FOR_NOMINATION_PERIOD.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_NOMINEE_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_NOMINEE_COMMITTEE.';
	DROP PROCEDURE OPLM_SAVE_NOMINEE_COMMITTEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_NOMINEE_COMMITTEE
 * --Purpose/Function		: Saves a NomineeCommittee object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 12/03/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/03/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_SAVE_NOMINEE_COMMITTEE(
	@NomineeCommitteeID BIGINT
	, @NomineeID BIGINT
	, @CommitteeID BIGINT
	, @StatusID BIGINT
	, @AcceptanceEmailSent BIT
	, @RejectionEmailSent BIT
	, @CurrentState VARCHAR(50)
	, @WorkflowInstanceID UNIQUEIDENTIFIER
	, @UpdatedBy VARCHAR(50)
	, @Selected BIT
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.NOMINEE_COMMITTEE WHERE NomineeCommitteeID = @NomineeCommitteeID)
	BEGIN
		-- Update Existing NomineeCommittee Information
		UPDATE dbo.NOMINEE_COMMITTEE SET
			NomineeID = @NomineeID
			, CommitteeID = @CommitteeID
			, StatusID = @StatusID
			, AcceptanceEmailSent = @AcceptanceEmailSent
			, RejectionEmailSent = @RejectionEmailSent
			, CurrentState = @CurrentState
			, WorkflowInstanceID = @WorkflowInstanceID
			, UpdatedBy = @UpdatedBy
			, Selected = @Selected
		WHERE NomineeCommitteeID = @NomineeCommitteeID;
		SET @GeneratedID = @NomineeCommitteeID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.NOMINEE_COMMITTEE
		INSERT INTO dbo.NOMINEE_COMMITTEE (NomineeID
			, CommitteeID
			, StatusID
			, AcceptanceEmailSent
			, RejectionEmailSent
			, CurrentState
			, WorkflowInstanceID
			, Selected
			, UpdatedBy)
		VALUES(@NomineeID
			, @CommitteeID
			, @StatusID
			, @AcceptanceEmailSent
			, @RejectionEmailSent
			, @CurrentState
			, @WorkflowInstanceID
			, @Selected
			, @UpdatedBy);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_NOMINEE_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_NOMINEE_COMMITTEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_NOMINEE_COMMITTEE.';
END
GO
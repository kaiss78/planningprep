SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_MEMBER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_COMMITTEE_MEMBER.';
	DROP PROCEDURE SAVE_COMMITTEE_MEMBER;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_COMMITTEE_MEMBER
 * --Purpose/Function		: Saves a CommitteeMember object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 11/11/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/11/2009		MHR		Initial Development		
 * 11/21/2009		MHR		Added New Field IsAddHoc			
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_COMMITTEE_MEMBER(
	@CommitteeMemberID BIGINT
	, @MemberID BIGINT
	, @CommitteeID BIGINT
	, @StartDate DATETIME
	, @EndDate DATETIME
	--, @DTS DATETIME
	, @IsActive BIT
	, @UpdatedBy VARCHAR(50)
	, @IsChairPerson BIT
	, @ShortBIO VARCHAR(1000)
	, @ReasonToAdd VARCHAR(1000)
	, @IsAddHoc BIT
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE @ProjectID BIGINT;
	DECLARE @UserID BIGINT;

	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.COMMITTEE_MEMBER WHERE CommitteeMemberID = @CommitteeMemberID)
	BEGIN
		-- Update Existing CommitteeMember Information
		UPDATE dbo.COMMITTEE_MEMBER SET
			MemberID = @MemberID
			, CommitteeID = @CommitteeID
			, StartDate = @StartDate
			, EndDate = @EndDate
			, DTS = GetDate()
			, IsActive = @IsActive
			, UpdatedBy = @UpdatedBy
			, IsChairPerson = @IsChairPerson
			, ShortBIO = @ShortBIO
			, ReasonToAdd = @ReasonToAdd
			, IsAddHoc = @IsAddHoc
		WHERE CommitteeMemberID = @CommitteeMemberID;
		SET @GeneratedID = @CommitteeMemberID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_COMMITTEE_MEMBER		
		INSERT INTO dbo.COMMITTEE_MEMBER (MemberID
			, CommitteeID
			, StartDate
			, EndDate
			, DTS
			, IsActive
			, UpdatedBy
			, IsChairPerson
			, ShortBIO
			, ReasonToAdd
			, IsAddHoc)
		VALUES(@MemberID
			, @CommitteeID
			, @StartDate
			, @EndDate
			, GetDate()
			, @IsActive
			, @UpdatedBy
			, @IsChairPerson
			, @ShortBIO
			, @ReasonToAdd
			, @IsAddHoc);
		SET @GeneratedID = SCOPE_IDENTITY();	

		---Insert a Note In case of New Member Added to a Committee
		SELECT @ProjectID = ProjectID FROM dbo.COMMITTEE WHERE CommitteeID = @CommitteeID;
		SELECT @UserID = UserID FROM dbo.OPLM_USER WHERE UserName = @UpdatedBy;
		
		---Add Notes
		IF ISNULL(@ReasonToAdd, '') <> '' 
		BEGIN
			INSERT INTO dbo.COMMITTEE_NOTES( Notes
				, MemberID
				, NotedBy
				, ProjectID
				, DTS)
			VALUES 
				( @ReasonToAdd
				, @MemberID
				, @UserID
				, @ProjectID
				, GetDate())
		END
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_MEMBER'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_COMMITTEE_MEMBER created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_COMMITTEE_MEMBER.';
END
GO
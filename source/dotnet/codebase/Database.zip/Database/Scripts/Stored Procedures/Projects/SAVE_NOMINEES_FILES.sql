SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINEES_FILES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_NOMINEES_FILES.';
	DROP PROCEDURE SAVE_NOMINEES_FILES;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_NOMINEES_FILES
 * --Purpose/Function		: Saves a Files object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_NOMINEES_FILES(
	@NomineeID BIGINT
	, @LetterOfInterest VARBINARY
	, @LetterOfInterestFileName VARCHAR(255)
	, @LetterOfInterestMIME VARCHAR(255)
	, @CVorExperience VARBINARY
	, @CVorExperienceFileName VARCHAR(255)
	, @CVorExperienceMIME VARCHAR(255)
	, @NonDisclosureAgreement VARBINARY
	, @NonDisclosureAgreementFileName VARCHAR(255)
	, @NonDisclosureAgreementMIME VARCHAR(255)
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.NOMINEES_FILES WHERE NomineeID = @NomineeID)
	BEGIN
		-- Update Existing Files Information
		UPDATE dbo.NOMINEES_FILES SET
			LetterOfInterest = @LetterOfInterest
			, LetterOfInterestFileName = @LetterOfInterestFileName
			, LetterOfInterestMIME = @LetterOfInterestMIME
			, CVorExperience = @CVorExperience
			, CVorExperienceFileName = @CVorExperienceFileName
			, CVorExperienceMIME = @CVorExperienceMIME
			, NonDisclosureAgreement = @NonDisclosureAgreement
			, NonDisclosureAgreementFileName = @NonDisclosureAgreementFileName
			, NonDisclosureAgreementMIME = @NonDisclosureAgreementMIME
		WHERE NomineeID = @NomineeID;
		SET @GeneratedID = @NomineeID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.NOMINEES_FILES
		INSERT INTO dbo.NOMINEES_FILES (NomineeID
		    , LetterOfInterest
			, LetterOfInterestFileName
			, LetterOfInterestMIME
			, CVorExperience
			, CVorExperienceFileName
			, CVorExperienceMIME
			, NonDisclosureAgreement
			, NonDisclosureAgreementFileName
			, NonDisclosureAgreementMIME)
		VALUES(@NomineeID
		    , @LetterOfInterest
			, @LetterOfInterestFileName
			, @LetterOfInterestMIME
			, @CVorExperience
			, @CVorExperienceFileName
			, @CVorExperienceMIME
			, @NonDisclosureAgreement
			, @NonDisclosureAgreementFileName
			, @NonDisclosureAgreementMIME);
		SET @GeneratedID = @NomineeID;		
	END
END

GO
-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINEES_FILES'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_NOMINEES_FILES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_NOMINEES_FILES.';
END
GO

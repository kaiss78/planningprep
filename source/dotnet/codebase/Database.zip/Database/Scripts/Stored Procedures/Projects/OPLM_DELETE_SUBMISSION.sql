SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_DELETE_SUBMISSION'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_DELETE_SUBMISSION.';
	DROP PROCEDURE OPLM_DELETE_SUBMISSION;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: OPLM
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_DELETE_SUBMISSION
 * --Purpose/Function		: Save Intent Category
 * --Author					: MRZ
 * --Start Date(MM/DD/YY)	: 10/26/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 01/10/09		MRZ	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_DELETE_SUBMISSION](
	@IntentID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRAN TDel 
	DELETE FROM OPLM_INTENT_OTHER WHERE IntentID=@IntentID
	DELETE FROM OPLM_INTENT_CATEGORY_RELATION WHERE IntentID=@IntentID
	DELETE FROM OPLM_INTENT WHERE IntentID=@IntentID
	
	IF @@ERROR=0
	COMMIT TRAN TDel
	ELSE
	ROLLBACK TRAN TDel
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_DELETE_SUBMISSION'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_DELETE_SUBMISSION created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_DELETE_SUBMISSION.';
END
GO




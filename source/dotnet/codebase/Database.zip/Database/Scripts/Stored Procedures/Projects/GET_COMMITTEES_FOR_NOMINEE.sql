SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEES_FOR_NOMINEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMITTEES_FOR_NOMINEE.';
	DROP PROCEDURE GET_COMMITTEES_FOR_NOMINEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: GET_COMMITTEES_FOR_NOMINEE
 * --Purpose/Function		: Get Committee list for nomination period
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 11/30/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/25/2009		MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_COMMITTEES_FOR_NOMINEE](
	@NomineeID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT com.ProjectID
		,com.CommitteeID
		,com.CommitteeName
		,ISNULL(com.Background,'') AS Background
		,ISNULL(com.iMISCODE,'') AS iMISCODE
		,ISNULL(com.IsActive,0) AS IsActive
		,ISNULL(com.ProjectStepIDForCommenting,0) AS ProjectStepIDForCommenting
		,ISNULL(com.ProjectStepIDForNominationPeriod,0) AS ProjectStepIDForNominationPeriod
		,ct.CommitteeType	
		,ct.CommitteeTypeID
		,ISNULL(mm.CommitteeID,0) AS MeetingDateExist
		, com.CommitteeTypeID
        , REL.StatusID
		, REL.NomineeCommitteeID
		, (SELECT StatusName FROM NOMINATION_STATUS_FOR_COMMITEE WHERE NOMINATION_STATUS_FOR_COMMITEE.StatusID = REL.StatusID) StatusName		
	FROM 
		COMMITTEE com
	LEFT OUTER JOIN
		COMMITTEES_WITH_MEETING_DATES mm
	ON
		com.CommitteeID = mm.CommitteeID
	INNER JOIN 
		COMMITTEE_TYPE ct
	ON
		com.CommitteeTypeID = ct.CommitteeTypeID
    INNER JOIN 
        NOMINEE_COMMITTEE REL
    ON 
        REL.CommitteeID = com.committeeID AND REL.SELECTED = 1
    WHERE
        REL.NomineeID =@NomineeID
	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEES_FOR_NOMINEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMITTEES_FOR_NOMINEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMITTEES_FOR_NOMINEE.';
END
GO
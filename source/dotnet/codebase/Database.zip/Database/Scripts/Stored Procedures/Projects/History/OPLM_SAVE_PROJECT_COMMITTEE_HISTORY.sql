SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_COMMITTEE_HISTORY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_PROJECT_COMMITTEE_HISTORY.';
	DROP PROCEDURE OPLM_SAVE_PROJECT_COMMITTEE_HISTORY;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_PROJECT_COMMITTEE_HISTORY
 * --Purpose/Function		: Saves a ProjectCommitteeHistory object
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/12/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_SAVE_PROJECT_COMMITTEE_HISTORY(
	@CommitteeHistoryID BIGINT
	, @CurrentVersionNumber INT
	, @CommitteeID BIGINT
	, @CommitteeName VARCHAR(50)
	, @ProjectID BIGINT
	, @StartDate DATETIME
	, @EndDate DATETIME
	, @DTS DATETIME
	, @IsCommitteeActive BIT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.OPLM_PROJECT_COMMITTEE_HISTORY WHERE CommitteeHistoryID = @CommitteeHistoryID)
	BEGIN
		-- Update Existing ProjectCommitteeHistory Information
		UPDATE dbo.OPLM_PROJECT_COMMITTEE_HISTORY SET
			CurrentVersionNumber = @CurrentVersionNumber
			, CommitteeID = @CommitteeID
			, CommitteeName = @CommitteeName
			, ProjectID = @ProjectID
			, StartDate = @StartDate
			, EndDate = @EndDate
			, DTS = @DTS
			, IsCommitteeActive = @IsCommitteeActive
		WHERE CommitteeHistoryID = @CommitteeHistoryID;
		SET @GeneratedID = @CommitteeHistoryID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_COMMITTEE_HISTORY
		INSERT INTO dbo.OPLM_PROJECT_COMMITTEE_HISTORY (CurrentVersionNumber
			, CommitteeID
			, CommitteeName
			, ProjectID
			, StartDate
			, EndDate
			, DTS
			, IsCommitteeActive)
		VALUES(@CurrentVersionNumber
			, @CommitteeID
			, @CommitteeName
			, @ProjectID
			, @StartDate
			, @EndDate
			, @DTS
			, @IsCommitteeActive);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_COMMITTEE_HISTORY'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_PROJECT_COMMITTEE_HISTORY created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_PROJECT_COMMITTEE_HISTORY.';
END
GO
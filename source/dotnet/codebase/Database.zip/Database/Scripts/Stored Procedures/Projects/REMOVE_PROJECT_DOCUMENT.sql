
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REMOVE_PROJECT_DOCUMENT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure REMOVE_PROJECT_DOCUMENT.';
	DROP PROCEDURE REMOVE_PROJECT_DOCUMENT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: REMOVE_PROJECT_DOCUMENT
 * --Purpose/Function		: Removes a project document
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 02/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 02/14/2009		MH		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[REMOVE_PROJECT_DOCUMENT](
	@DocumentID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
	IF EXISTS(SELECT DocumentID FROM OPLM_PROJECT_DOCUMENT WHERE DocumentID = @DocumentID)
	BEGIN
		DELETE OPLM_PROJECT_DOCUMENT WHERE DocumentID = @DocumentID
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'REMOVE_PROJECT_DOCUMENT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure REMOVE_PROJECT_DOCUMENT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure REMOVE_PROJECT_DOCUMENT.';
END
GO

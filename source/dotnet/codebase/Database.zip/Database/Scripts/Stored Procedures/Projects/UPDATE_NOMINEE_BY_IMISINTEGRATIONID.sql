SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'UPDATE_NOMINEE_BY_IMISINTEGRATIONID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure UPDATE_NOMINEE_BY_IMISINTEGRATIONID.';
	DROP PROCEDURE UPDATE_NOMINEE_BY_IMISINTEGRATIONID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: UPDATE_NOMINEE_BY_IMISINTEGRATIONID
 * --Purpose/Function		: Saves a OfCommittee object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.UPDATE_NOMINEE_BY_IMISINTEGRATIONID(
	--@Prefix VARCHAR(50)
	--, 
	@FirstName VARCHAR(500)
	, @LastName VARCHAR(500)
	, @Title_Credential VARCHAR(50)
	--, @Affiliation VARCHAR(500)
	, @MemberCouncil VARCHAR(500)
	, @City VARCHAR(100)
	, @State VARCHAR(50)
	, @Email VARCHAR(100)
	, @IMISIntegrationID VARCHAR(6)
	, @IMISContactID BIGINT	
)
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.NOMINEE_OF_COMMITTEE WHERE IMISIntegrationID = @IMISIntegrationID)
	BEGIN
		-- Update Existing OfCommittee Information
		UPDATE 
			dbo.NOMINEE_OF_COMMITTEE 
		SET
			--Prefix = @Prefix
			--, 
			FirstName = @FirstName
			, LastName = @LastName
			, Title_Credential = @Title_Credential
			--, Affiliation = @Affiliation
			, MemberCouncil = @MemberCouncil
			, City = @City
			, State = @State
			, Email = @Email
			, IMISContactID = @IMISContactID
	        , IsSyncedWithIMIS = 'True'			
		WHERE 
			IMISIntegrationID = @IMISIntegrationID
	END	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'UPDATE_NOMINEE_BY_IMISINTEGRATIONID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure UPDATE_NOMINEE_BY_IMISINTEGRATIONID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure UPDATE_NOMINEE_BY_IMISINTEGRATIONID.';
END
GO

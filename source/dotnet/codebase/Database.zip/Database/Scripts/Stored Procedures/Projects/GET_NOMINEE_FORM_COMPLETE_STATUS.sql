SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINEE_FORM_COMPLETE_STATUS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_NOMINEE_FORM_COMPLETE_STATUS.';
	DROP PROCEDURE GET_NOMINEE_FORM_COMPLETE_STATUS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_NOMINEE_FORM_COMPLETE_STATUS
 * --Purpose/Function		: Gets Files objects by ID
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_NOMINEE_FORM_COMPLETE_STATUS(
	@NomineeID BIGINT,
    @ISCompleted BIT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
	DECLARE @LetterOfInterestFileName varchar(255)
	DECLARE @CVorExperienceFileName varchar(255)
	DECLARE @NonDisclosureAgreementFileName varchar(255)
	DECLARE @ShortBiography varchar(255)

	SELECT 
		 @LetterOfInterestFileName= ISNULL(files.LetterOfInterestFileName,'')
		,@CVorExperienceFileName=  ISNULL(files.CVorExperienceFileName,'')
		,@NonDisclosureAgreementFileName=  ISNULL(files.NonDisclosureAgreementFileName,'')
		,@ShortBiography=  ISNULL(nom.ShortBiography,'')
	FROM dbo.NOMINEES_FILES files
	INNER JOIN 
	     dbo.NOMINEE nom
	ON files.NomineeID = nom.NomineeID
	WHERE nom.NomineeID = @NomineeID;	

    IF @LetterOfInterestFileName <>'' AND @CVorExperienceFileName<>'' AND  @NonDisclosureAgreementFileName <>'' AND  @ShortBiography <> ''
      BEGIN
        SET @ISCompleted = 1
      END
	ELSE
      BEGIN
        SET @ISCompleted = 10;
      END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NOMINEE_FORM_COMPLETE_STATUS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_NOMINEE_FORM_COMPLETE_STATUS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_NOMINEE_FORM_COMPLETE_STATUS.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINEE_OF_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_NOMINEE_OF_COMMITTEE.';
	DROP PROCEDURE SAVE_NOMINEE_OF_COMMITTEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_NOMINEE_OF_COMMITTEE
 * --Purpose/Function		: Saves a OfCommittee object
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/15/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_NOMINEE_OF_COMMITTEE(
	@NomineeID BIGINT
	--, @CommiteeID BIGINT
	, @Prefix VARCHAR(50)
	, @FirstName VARCHAR(500)
	, @LastName VARCHAR(500)
	, @Title_Credential VARCHAR(50)
	, @Affiliation VARCHAR(500)
	, @MemberCouncil VARCHAR(500)
	, @City VARCHAR(100)
	, @State VARCHAR(50)
	, @Email VARCHAR(100)
	, @ShortBiography VARCHAR(750)
	, @NominatedOn DATETIME
	, @AddedOnAdhoc BIT
	--, @StatusID BIGINT
	, @WorkflowInstanceID UNIQUEIDENTIFIER
    , @CurrentState VARCHAR(50)	
	, @IMISIntegrationID VARCHAR(6)
	, @IMISContactID BIGINT
	, @IsSyncedWithIMIS BIT
	, @ReasonForAddition VARCHAR(1000)
	--, @AcceptanceEmailSent BIT
	--, @RejectionEmailSent BIT
	, @Reopened BIT
	, @UpdatedBy VARCHAR(50)
	, @GeneratedID INT OUTPUT
	, @UserName VARCHAR(50)
	, @Organization VARCHAR(200)
	, @Suffix VARCHAR(50)

	, @MailingAddress VARCHAR(1000)
	, @Zip VARCHAR(50)
	, @FedexAddress VARCHAR(1000)
	, @Telephone VARCHAR(50)
	, @Fax VARCHAR(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.NOMINEE_OF_COMMITTEE WHERE NomineeID = @NomineeID)
	BEGIN
		-- Update Existing OfCommittee Information
		UPDATE dbo.NOMINEE_OF_COMMITTEE SET
			
			 Prefix = @Prefix
			, FirstName = @FirstName
			, LastName = @LastName
			, Title_Credential = @Title_Credential
			, Affiliation = @Affiliation
			, MemberCouncil = @MemberCouncil
			, City = @City
			, State = @State
			, Email = @Email
			, ShortBiography = @ShortBiography
			, NominatedOn = @NominatedOn
			, AddedOnAdhoc = @AddedOnAdhoc
			--, StatusID = @StatusID
			, CurrentState =@CurrentState
			, WorkflowInstanceID = @WorkflowInstanceID
			-- ****** DEV: MHR ******* IT#4 ***** Feedback
			-- This is done because the IMIS Integration Code Will not Change 
			-- in the life cycle of a nominee data.
			--,IMISIntegrationID = @IMISIntegrationID
			-- ****** End Feedback **************
			,IMISContactID = @IMISContactID
	        ,IsSyncedWithIMIS = @IsSyncedWithIMIS
			, ReasonForAddition = @ReasonForAddition
			--, AcceptanceEmailSent = @AcceptanceEmailSent
			--, RejectionEmailSent = @RejectionEmailSent
			, Reopened = @Reopened
			, UpdatedBy = @UpdatedBy
			, UserName = @UserName
			, Organization = @Organization
			, Suffix = @Suffix
			, MailingAddress = @MailingAddress
			, Zip = @Zip
			, FedexAddress = @FedexAddress
			, Telephone = @Telephone
			, Fax = @Fax
		WHERE NomineeID = @NomineeID
		SET @GeneratedID = @NomineeID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.NOMINEE_OF_COMMITTEE
		INSERT INTO dbo.NOMINEE_OF_COMMITTEE ( UserName
			, Prefix
			, FirstName
			, LastName
			, Title_Credential
			, Affiliation
			, MemberCouncil
			, MailingAddress
			, City
			, State
			, Organization
			, Suffix
			, Zip
			, FedexAddress
			, Telephone
			, Fax
			, Email
			, ShortBiography
			, NominatedOn
			, AddedOnAdhoc
			--, StatusID			
			, WorkflowInstanceID
			, CurrentState
			, IMISIntegrationID
			, IMISContactID
			, IsSyncedWithIMIS
			, ReasonForAddition
			--, AcceptanceEmailSent
			--, RejectionEmailSent
			, Reopened
			, UpdatedBy)
		VALUES( @UserName
			, @Prefix
			, @FirstName
			, @LastName
			, @Title_Credential
			, @Affiliation
			, @MemberCouncil
			, @MailingAddress
			, @City
			, @State
			, @Organization
			, @Suffix
			, @Zip
			, @FedexAddress
			, @Telephone
			, @Fax
			, @Email
			, @ShortBiography
			, @NominatedOn
			, @AddedOnAdhoc
			--, @StatusID			
			, @WorkflowInstanceID
			, @CurrentState
			, @IMISIntegrationID
			, @IMISContactID
	        , @IsSyncedWithIMIS
			, @ReasonForAddition
			--, @AcceptanceEmailSent
			--, @RejectionEmailSent
			, @Reopened
			, @UpdatedBy)
		SET @GeneratedID = SCOPE_IDENTITY();		
	END

	-- Following Business Has been implemented in the DAL layer
	/*
	INSERT INTO NOMINEE_COMMITTEE 
             (CommitteeID
			, NomineeID)
              values 
              ( 
              @CommiteeID
            , @GeneratedID
              )
	*/
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINEE_OF_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_NOMINEE_OF_COMMITTEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_NOMINEE_OF_COMMITTEE.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_INTENT_FROM_NQF'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_INTENT_FROM_NQF.';
	DROP PROCEDURE OPLM_SAVE_INTENT_FROM_NQF;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: OPLM
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_INTENT_FROM_NQF
 * --Purpose/Function		: Save Intent From NQF
 * --Author					: MRZ
 * --Start Date(MM/DD/YY)	: 10/27/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 10/27/09		MRZ	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_SAVE_INTENT_FROM_NQF](
	@IntentID BIGINT
	,@IMISUserID BIGINT
	,@ProjectID BIGINT
	,@Title NVARCHAR(250)
	,@Description VARCHAR(MAX)
	,@OnBehalfName NVARCHAR(250)
	,@OnBehalfOrganization NVARCHAR(250)
	,@OnBehalfPhoneNo NVARCHAR(20)
	,@OnBehalfEmail NVARCHAR(255)
	,@SubmissionDate DATETIME
	,@SubmissionType NVARCHAR(255)
	,@imisUserName NVARCHAR(250)
	,@imisUserOrganization NVARCHAR(80)
	,@imisuserPhoneNo NVARCHAR(20)
	,@imisuserEmail NVARCHAR(100)
	,@GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT IntentID FROM dbo.OPLM_INTENT WHERE IntentID = @IntentID)
	BEGIN
	--Delete taxonomy
	DELETE FROM OPLM_INTENT_CATEGORY_RELATION WHERE IntentID = @IntentID	
	-- Update Existing OPLMPROJECTPRIMARYDATA Information
		UPDATE dbo.OPLM_INTENT SET
			IMISUserID = @IMISUserID
			, ProjectID = @ProjectID
			, Title = @Title
			, Description = @Description
			, OnBehalfName = @OnBehalfName
			, OnBehalfOrganization = @OnBehalfOrganization
			,OnBehalfPhoneNo=@OnBehalfPhoneNo
			,OnBehalfEmail=@OnBehalfEmail
			--,SubmissionDate=getdate()
			,SubmissionType=@SubmissionType
			,imisUserName=@imisUserName
			,imisUserOrganization=@imisUserOrganization
			,imisuserPhoneNo=@imisuserPhoneNo
			,imisuserEmail=@imisuserEmail
		WHERE IntentID = @IntentID
		SET @GeneratedID = @IntentID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_PRIMARY_DATA
		INSERT INTO dbo.OPLM_INTENT (
             IMISUserID
            ,ProjectID
			, Title
			, Description
			, OnBehalfName
			, OnBehalfOrganization
			, OnBehalfPhoneNo
			,OnBehalfEmail
			,SubmissionDate
			,SubmissionType
			,imisUserName
			,imisUserOrganization
			,imisuserPhoneNo
			,imisuserEmail)
		VALUES(
            @IMISUserID
            ,@ProjectID
			, @Title
			, @Description
			, @OnBehalfName
			, @OnBehalfOrganization
			, @OnBehalfPhoneNo
			,@OnBehalfEmail
			, getdate()
			,@SubmissionType
			,@imisUserName
			,@imisUserOrganization
			,@imisuserPhoneNo
			,@imisuserEmail);
		SET @GeneratedID =SCOPE_IDENTITY();	
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_INTENT_FROM_NQF'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_INTENT_FROM_NQF created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_INTENT_FROM_NQF.';
END
GO




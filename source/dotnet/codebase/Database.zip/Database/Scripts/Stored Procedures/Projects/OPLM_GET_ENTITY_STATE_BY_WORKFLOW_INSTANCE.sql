
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE.';
	DROP PROCEDURE OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE
 * --Purpose/Function		: Get an entity's current workflow status by workflow instance ID
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/13/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/13/2009		MHA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

-- OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE 'COMMITTEE_OF_NOMINEE' '4fb57119-5f3f-4e35-88b4-887e97a48b71'

CREATE PROCEDURE dbo.OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE
@EntityName VARCHAR(100),
@WorkflowInstanceID UNIQUEIDENTIFIER
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @SQL VARCHAR(300);
	SET @SQL = 'SELECT CurrentState
	FROM ' + @EntityName + '
	WHERE WorkflowInstanceID = ''' + CAST(@WorkflowInstanceID AS VARCHAR(50)) + '''';
	--PRINT @SQL;
	EXEC(@SQL);
	--WHERE ProjectTypeID = @ProjectTypeID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_ENTITY_STATE_BY_WORKFLOW_INSTANCE.';
END
GO

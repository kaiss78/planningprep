SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID.';
	DROP PROCEDURE GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPLM
 * --Procedure name			: GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID
 * --Purpose/Function		: Get Committee members of a committee
 * --Author					: MR
 * --Start Date(MM/DD/YY)	: 11/22/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/22/2009		MR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID(
	@CommitteeID BIGINT
	, @ShowInActive BIT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	--Select all members with inactive members
	IF (@ShowInActive = 1)
	BEGIN
		SELECT	
			CM.CommitteeMemberID,
			CM.IsChairPerson,
			CM.StartDate,
			CM.EndDate,
			CM.IsActive,
			CM.IsAddHoc,
			CMD.FirstName,
			CMD.LastName,
			CMD.Title,
			CMD.City,
			CMD.State,
			CMD.PrimaryCouncil,
			CMD.MemberID
		FROM 
			COMMITTEE_MEMBER CM
			INNER JOIN COMMITTEE_MEMBER_DETAILS CMD ON CMD.MemberID=CM.MemberID
		WHERE	
			CM.CommitteeID = @CommitteeID
		ORDER BY 
			CMD.FirstName
	END
	ELSE --Select only active members
	BEGIN
		SELECT	
			CM.CommitteeMemberID,
			CM.IsChairPerson,
			CM.StartDate,
			CM.EndDate,
			CM.IsActive,
			CM.IsAddHoc,
			CMD.FirstName,
			CMD.LastName,
			CMD.Title,
			CMD.City,
			CMD.State,
			CMD.PrimaryCouncil,
			CMD.MemberID
		FROM 
			COMMITTEE_MEMBER CM
			INNER JOIN COMMITTEE_MEMBER_DETAILS CMD ON CMD.MemberID=CM.MemberID
		WHERE	
			CM.CommitteeID = @CommitteeID
			AND CM.IsActive = 1
		ORDER BY 
			CMD.FirstName
	END
	--Select Inactive member count
	SELECT 
		COUNT (*) AS InActiveCount
	FROM 
		COMMITTEE_MEMBER
	WHERE
		IsActive = 0
		AND CommitteeID = @CommitteeID
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMITTEE_MEMBERS_BY_COMMITTEE_ID.';
END
GO
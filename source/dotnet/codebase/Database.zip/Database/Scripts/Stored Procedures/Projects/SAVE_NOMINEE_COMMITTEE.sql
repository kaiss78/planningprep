SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINEE_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_NOMINEE_COMMITTEE.';
	DROP PROCEDURE SAVE_NOMINEE_COMMITTEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: OPUS
 * --Procedure name			: SAVE_NOMINEE_COMMITTEE
 * --Purpose/Function		: Assignes Committees to a Nominee
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 12/01/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/01/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.SAVE_NOMINEE_COMMITTEE(
	@NomineeCommitteeID BIGINT
	, @NomineeID BIGINT
	, @CommitteeID BIGINT
    , @StatusID BIGINT
	, @GeneratedID BIGINT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.NOMINEE_COMMITTEE WHERE NomineeCommitteeID = @NomineeCommitteeID)
	BEGIN
		-- Update Existing Committee Information
		UPDATE dbo.NOMINEE_COMMITTEE SET
			NomineeID = @NomineeID
			, CommitteeID = @CommitteeID
            , StatusID = @StatusID
		WHERE NomineeCommitteeID = @NomineeCommitteeID;
		SET @GeneratedID = @NomineeCommitteeID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.NOMINEE_COMMITTEE
		INSERT INTO dbo.NOMINEE_COMMITTEE (NomineeID
			, CommitteeID
             ,StatusID)
		VALUES(@NomineeID
			, @CommitteeID
            , @StatusID);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_NOMINEE_COMMITTEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_NOMINEE_COMMITTEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_NOMINEE_COMMITTEE.';
END
GO
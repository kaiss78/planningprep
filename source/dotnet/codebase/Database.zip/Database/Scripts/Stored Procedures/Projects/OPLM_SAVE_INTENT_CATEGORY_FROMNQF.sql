SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_INTENT_CATEGORY_FROMNQF'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_INTENT_CATEGORY_FROMNQF.';
	DROP PROCEDURE OPLM_SAVE_INTENT_CATEGORY_FROMNQF;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: OPLM
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_INTENT_CATEGORY_FROMNQF
 * --Purpose/Function		: Save Intent Category
 * --Author					: MRZ
 * --Start Date(MM/DD/YY)	: 10/26/09
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date			Name	Comments
 * 01/10/09		MRZ	Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_SAVE_INTENT_CATEGORY_FROMNQF](
	@IntentID BIGINT
	, @IntentSubCategoryID BIGINT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
		--DELETE FROM OPLM_INTENT_CATEGORY_RELATION WHERE IntentID = @IntentID

--IF NOT EXISTS(SELECT IntentID FROM dbo.OPLM_INTENT_CATEGORY_RELATION WHERE IntentID = @IntentID AND IntentSubCategoryID=@IntentSubCategoryID)
	--BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_PRIMARY_DATA
		INSERT INTO dbo.OPLM_INTENT_CATEGORY_RELATION (
             IntentID
            ,IntentSubCategoryID)
		VALUES(
            @IntentID
            , @IntentSubCategoryID);

		SET @GeneratedID = SCOPE_IDENTITY();	
	--END
	
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_INTENT_CATEGORY_FROMNQF'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_INTENT_CATEGORY_FROMNQF created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_INTENT_CATEGORY_FROMNQF.';
END
GO






SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_PROJECT.';
	DROP PROCEDURE OPLM_GET_PROJECT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_PROJECT
 * --Purpose/Function		: Gets ProjectSecondaryData objects by ID
 * --Author					: AFS
 * --Start Date(MM/DD/YY)	: 10/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/14/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_GET_PROJECT(
	@ProjectID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT 
      master.ProjectID
    , master.DTS
    , master.UpdatedBy
		, priData.LongTitle
		, priData.ShortName
		, priData.StartDate
		, priData.EndDate
		, prjType.ProjectType
		, priData.UpdatedDate
		, priData.ProjectTypeID
		, secData.ProjectStatus
		, secData.ProjectStatusSummary
		, secData.ProjectExplanation
		, secData.ShortDescription
		, secData.ProjectDescription
		, secData.ProjectSoftekID
		, secData.SubmissionInstruction
		, secData.DetailIntro
		, secData.ProjectProposal
		, secData.ProjectContract
		, secData.Conditions
		, secData.CareSettings
		, secData.NPPTopics
		, secData.Completed
		FROM 
        dbo.OPLM_PROJECT_MASTER master
    INNER JOIN
        dbo.OPLM_PROJECT_PRIMARY_DATA priData
     ON 
        master.ProjectID = priData.ProjectID
    LEFT OUTER JOIN 
        dbo.OPLM_PROJECT_SECONDARY_DATA secData
    ON 
        priData.ProjectID = secData.ProjectID
    INNER JOIN
        dbo.OPLM_PROJECT_TYPE prjType
    ON
       priData.ProjectTypeID = prjType.ProjectTypeID
	WHERE master.ProjectID = @ProjectID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_PROJECT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_PROJECT.';
END
GO




SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_IMIS_SYNCED_NOMINEES_IMISID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_IMIS_SYNCED_NOMINEES_IMISID.';
	DROP PROCEDURE GET_IMIS_SYNCED_NOMINEES_IMISID;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_IMIS_SYNCED_NOMINEES_IMISID
 * --Purpose/Function		: Gets IMIS SYNCED NOMINEED IMISID
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 10/24/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/19/2009		AFS		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_IMIS_SYNCED_NOMINEES_IMISID
(
 @projectStepIDForNominationPeriod BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	SELECT DISTINCT nom.imiscontactid
	FROM   
    nominee_of_committee nom
    INNER JOIN
    NOMINEE_COMMITEE REL
    ON 
    nom.nomineeid = REL.nomineeid
    INNER JOIN   
    committee com
    ON  REL.commiteeid = com.committeeid
    
	WHERE  
	nom.issyncedwithimis = 1
	and nom.statusid <> 4
    and com.projectStepIDForNominationPeriod = @projectStepIDForNominationPeriod 
	ORDER  BY nom.imiscontactid
  



END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_IMIS_SYNCED_NOMINEES_IMISID'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_IMIS_SYNCED_NOMINEES_IMISID created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_IMIS_SYNCED_NOMINEES_IMISID.';
END
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEE_AND_STATUS_OF_NOMINEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_COMMITTEE_AND_STATUS_OF_NOMINEE.';
	DROP PROCEDURE GET_COMMITTEE_AND_STATUS_OF_NOMINEE;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_COMMITTEE_AND_STATUS_OF_NOMINEE
 * --Purpose/Function		: Gets all Committee Names and Status Names of a Nominee
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 12/02/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 12/02/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
--EXEC dbo.GET_COMMITTEE_AND_STATUS_OF_NOMINEE 71
CREATE PROCEDURE [dbo].[GET_COMMITTEE_AND_STATUS_OF_NOMINEE](
	@NomineeID BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT NC.NomineeCommitteeID
		, NC.NomineeID
		, NC.CommitteeID
		, NC.StatusID
		, AcceptanceEmailSent = ISNULL(NC.AcceptanceEmailSent, 0)
		, RejectionEmailSent = ISNULL(NC.RejectionEmailSent, 0)
		, C.CommitteeName
		, NSFC.StatusName
		, C.ProjectID
		, C.CommitteeTypeID
		, C.CommitteeName
		, C.ProjectStepIDForCommenting
		, C.ProjectStepIDForNominationPeriod
		, C.CreateWebLink
		, C.MeetingStartDate
		, C.MeetingEndDate
		, C.Background
		, C.iMISCode
		, C.IsActive
		, T.CommitteeType
	FROM dbo.NOMINEE_COMMITTEE NC
	INNER JOIN COMMITTEE C ON NC.CommitteeID = C.CommitteeID AND NC.SELECTED = 1
	--INNER JOIN COMMITTEE_TYPE CT ON C.CommitteeTypeID = CT.CommitteeTypeID
	INNER JOIN NOMINATION_STATUS_FOR_COMMITEE NSFC ON NC.StatusID = NSFC.StatusID
	LEFT OUTER JOIN COMMITTEE_TYPE T ON C.CommitteeTypeID=T.CommitteeTypeID
	WHERE NC.NomineeID = @NomineeID;			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_COMMITTEE_AND_STATUS_OF_NOMINEE'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_COMMITTEE_AND_STATUS_OF_NOMINEE created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_COMMITTEE_AND_STATUS_OF_NOMINEE.';
END
GO

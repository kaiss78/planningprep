

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS.';
	DROP PROCEDURE OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS
 * --Purpose/Function		: Saves a ProjectFundingOrganizations object
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 10/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/14/2009		MHA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS(
	@ProjectID BIGINT
	, @OrganizationID BIGINT
	, @OrganizationName VARCHAR(500)
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.OPLM_PROJECT_FUNDING_ORGANIZATIONS WHERE OrganizationID = @OrganizationID)
	BEGIN
		-- Update Existing ProjectFundingOrganizations Information
		UPDATE dbo.OPLM_PROJECT_FUNDING_ORGANIZATIONS SET
			ProjectID = @ProjectID
			, OrganizationName = @OrganizationName
		WHERE OrganizationID = @OrganizationID;
		SET @GeneratedID = @OrganizationID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_FUNDING_ORGANIZATIONS
		INSERT INTO dbo.OPLM_PROJECT_FUNDING_ORGANIZATIONS (
             OrganizationID
            , ProjectID
			, OrganizationName)
		VALUES(
              @OrganizationID
            , @ProjectID
			, @OrganizationName);
		SET @GeneratedID = SCOPE_IDENTITY();		
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_PROJECT_FUNDING_ORGANIZATIONS.';
END
GO



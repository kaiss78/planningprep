

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_FUNDING_CONTACTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_SAVE_PROJECT_FUNDING_CONTACTS.';
	DROP PROCEDURE OPLM_SAVE_PROJECT_FUNDING_CONTACTS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_SAVE_PROJECT_FUNDING_CONTACTS
 * --Purpose/Function		: Saves a ProjectFundingContacts object
 * --Author					: MHA
 * --Start Date(MM/DD/YY)	: 10/14/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/14/2009		MHA		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.OPLM_SAVE_PROJECT_FUNDING_CONTACTS(
	@ContactID BIGINT
	, @ProjectID BIGINT
	, @OrganizationID BIGINT
	, @ContactName VARCHAR(500)
	, @PrimaryContact BIT
	, @GeneratedID INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	IF EXISTS(SELECT * FROM dbo.OPLM_PROJECT_FUNDING_CONTACTS WHERE ContactID = @ContactID)
	BEGIN
		-- Update Existing ProjectFundingContacts Information
		UPDATE dbo.OPLM_PROJECT_FUNDING_CONTACTS SET
			ProjectID = @ProjectID
			, OrganizationID = @OrganizationID
			, ContactName = @ContactName
			, PrimaryContact = @PrimaryContact
		WHERE ContactID = @ContactID
        AND @OrganizationID IN (SELECT OrganizationID FROM OPLM_PROJECT_FUNDING_ORGANIZATIONS)
		SET @GeneratedID = @ContactID;		
	END
	ELSE
	BEGIN
		-- New Record, So insert it into the dbo.OPLM_PROJECT_FUNDING_CONTACTS
IF EXISTS ((SELECT * FROM OPLM_PROJECT_FUNDING_ORGANIZATIONS WHERE OrganizationID =@OrganizationID ))
BEGIN
		INSERT INTO dbo.OPLM_PROJECT_FUNDING_CONTACTS (
              ContactID
            , ProjectID
			, OrganizationID
			, ContactName
			, PrimaryContact)
		VALUES(
              @ContactID
            , @ProjectID
			, @OrganizationID
			, @ContactName
			, @PrimaryContact)
          
		SET @GeneratedID = @ContactID;	
END
ELSE
BEGIN
  SET @GeneratedID = 0
END
	END
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_SAVE_PROJECT_FUNDING_CONTACTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_SAVE_PROJECT_FUNDING_CONTACTS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_SAVE_PROJECT_FUNDING_CONTACTS.';
END
GO




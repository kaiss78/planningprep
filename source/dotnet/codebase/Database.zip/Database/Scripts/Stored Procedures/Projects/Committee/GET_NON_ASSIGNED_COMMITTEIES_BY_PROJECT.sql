SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT.';
	DROP PROCEDURE GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT
 * --Purpose/Function		: Saves a committee object
 * --Author					: MHR
 * --Start Date(MM/DD/YY)	: 11/12/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 11/12/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE dbo.GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT(
	@ProjectID BIGINT	
)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	-- If Exists then Update the Existing Record
	SELECT c.CommitteeID,
		c.CommitteeTypeID,
		c.ProjectID,
		c.CommitteeName,
		c.ProjectStepIDForCommenting,
		c.ProjectStepIDForNominationPeriod,
		c.CreateWebLink,
		c.MeetingStartDate,
		c.MeetingEndDate,
		c.Background,
		c.iMISCode,
		c.IsActive,
		t.CommitteeType
	FROM 
		dbo.COMMITTEE c 
	INNER JOIN 
		dbo.COMMITTEE_TYPE t 
		ON c.CommitteeTypeID = t.CommitteeTypeID
	INNER JOIN
			COMMITTEES_WITH_MEETING_DATES
		ON
			COMMITTEES_WITH_MEETING_DATES.CommitteeID = c.CommitteeID	
	WHERE c.ProjectID = @ProjectID
	AND c.IsActive = 1	
	AND ISNULL(ProjectStepIDForNominationPeriod, 0) <> 0
	AND c.ProjectStepIDForCommenting IS NULL
	AND c.Background IS NOT NULL
	AND c.CommitteeTypeID IS NOT NULL
	AND c.CommitteeName IS NOT NULL
	AND c.iMISCODE IS NOT NULL			
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_NON_ASSIGNED_COMMITTEIES_BY_PROJECT.';
END
GO
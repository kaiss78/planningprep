SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT.';
	DROP PROCEDURE OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT
 * --Purpose/Function		: Get Committee list for edit
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 11/15/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT](
	@ProjectID BIGINT,
	@ProjectStepIDForNominationPeriod BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
	dbo.COMMITTEE.CommitteeID, 
	dbo.COMMITTEE.CommitteeName, 
	dbo.COMMITTEE.ProjectStepIDForNominationPeriod, 
	dbo.COMMITTEE.ProjectStepIDForCommenting, 
	dbo.COMMITTEE_TYPE.CommitteeType 
	FROM dbo.COMMITTEE
	INNER JOIN COMMITTEES_WITH_MEETING_DATES 
	ON
	COMMITTEE.CommitteeID = COMMITTEES_WITH_MEETING_DATES.CommitteeID
	INNER JOIN  dbo.COMMITTEE_TYPE
	ON
	dbo.COMMITTEE.CommitteeTypeID = dbo.COMMITTEE_TYPE.CommitteeTypeID
	WHERE dbo.COMMITTEE.ProjectID = @ProjectID 
	AND ((dbo.COMMITTEE.ProjectStepIDForNominationPeriod IS NULL) OR (dbo.COMMITTEE.ProjectStepIDForNominationPeriod = @ProjectStepIDForNominationPeriod))
	AND ISNULL(dbo.COMMITTEE.Background,'') <> ''
	AND ISNULL(dbo.COMMITTEE.CommitteeTypeID,'') <> ''
	AND ISNULL(dbo.COMMITTEE.CommitteeName,'') <> ''
	AND ISNULL(dbo.COMMITTEE.iMISCODE,'') <> ''
	AND dbo.COMMITTEE.IsActive = 'True'
	
-- EXEC OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT 2, 48		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure OPLM_GET_COMMITTEE_FOR_NOMINATION_PERIOD_BY_PROJECTID_FOR_EDIT.';
END
GO
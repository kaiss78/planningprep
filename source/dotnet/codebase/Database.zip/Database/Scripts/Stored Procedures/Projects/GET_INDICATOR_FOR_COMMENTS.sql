SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_INDICATOR_FOR_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure GET_INDICATOR_FOR_COMMENTS.';
	DROP PROCEDURE GET_INDICATOR_FOR_COMMENTS;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: GET_INDICATOR_FOR_COMMENTS
 * --Purpose/Function		: GET INDICATOR FOR COMMENTS
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 01/11/2010
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GET_INDICATOR_FOR_COMMENTS](
	@ProjectID BIGINT
)
AS
BEGIN
	SELECT MAX(DTS) As DateOfLatestComment 
	FROM dbo.MEASURE_COMMENTS 
	WHERE ProjectID = @ProjectID

	SELECT Count(*) As NumberOfPublicComments 
	FROM dbo.MEASURE_COMMENTS 
	WHERE ProjectID = @ProjectID
	AND IsMemberComment = 'false'

	SELECT Count(*) As NumberOfMemberComments 
	FROM dbo.MEASURE_COMMENTS 
	WHERE ProjectID = @ProjectID
	AND IsMemberComment = 'true'

	SELECT Count(*) As NumberOfCommentsSentForResponse
	FROM dbo.MEASURE_COMMENTS 
	INNER JOIN 
	dbo.COMMENT_STATUS 
	ON dbo.MEASURE_COMMENTS.Status = dbo.COMMENT_STATUS.ID
	AND dbo.MEASURE_COMMENTS.ProjectID = @ProjectID
	AND dbo.COMMENT_STATUS.Name = 'Sent To Submitter Wait for Response'

	SELECT Count(*) As NumberOfCommentsAwaitingResponse
	FROM dbo.MEASURE_COMMENTS 
	INNER JOIN 
	dbo.COMMENT_STATUS 
	ON dbo.MEASURE_COMMENTS.Status = dbo.COMMENT_STATUS.ID
	AND dbo.MEASURE_COMMENTS.ProjectID = @ProjectID
	AND dbo.COMMENT_STATUS.Name = 'Sent To Submitter Wait for Response'

	SELECT Count(*) As NumberOfCommentsWithoutAFinalRemark
	FROM dbo.MEASURE_COMMENTS 
	INNER JOIN 
	dbo.COMMENT_STATUS 
	ON dbo.MEASURE_COMMENTS.Status = dbo.COMMENT_STATUS.ID
	AND dbo.MEASURE_COMMENTS.ProjectID = @ProjectID
	AND dbo.COMMENT_STATUS.Name = 'Without Final Remark'
	

-- EXEC GET_INDICATOR_FOR_COMMENTS 39
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'GET_INDICATOR_FOR_COMMENTS'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure GET_INDICATOR_FOR_COMMENTS created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure GET_INDICATOR_FOR_COMMENTS.';
END
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_FOR_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Dropping stored procedure SAVE_COMMITTEE_FOR_NOMINATION_PERIOD.';
	DROP PROCEDURE SAVE_COMMITTEE_FOR_NOMINATION_PERIOD;
END

GO

/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Client Name			: NQF
 * --Project Name			: New Website Implemenation
 * --Procedure name			: SAVE_COMMITTEE_FOR_NOMINATION_PERIOD
 * --Purpose/Function		: SAVE COMMITTEE FOR NOMINATION PERIOD
 * --Author					: SR
 * --Start Date(MM/DD/YY)	: 11/16/2009
 *
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * CHANGE HISTORY
 * ===================================================================
 * Date				Name	Comments
 * 10/29/2009		MHR		Initial Development				
 * ===================================================================*/

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[SAVE_COMMITTEE_FOR_NOMINATION_PERIOD](
	@CommiteeIDList VARCHAR(500),
	@ProjectStepID BIGINT
)
AS
BEGIN
	UPDATE dbo.COMMITTEE
	SET ProjectStepIDForNominationPeriod = NULL
	WHERE ProjectStepIDForNominationPeriod = @ProjectStepID


	UPDATE dbo.COMMITTEE
	SET ProjectStepIDForNominationPeriod = @ProjectStepID
	WHERE CommitteeID in (Select id from dbo.SplitId(@CommiteeIDList,','))

-- EXEC SAVE_COMMITTEE_FOR_NOMINATION_PERIOD '3,5', 48		
END

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------

IF EXISTS (	SELECT *
			FROM INFORMATION_SCHEMA.ROUTINES
			WHERE ROUTINE_NAME = 'SAVE_COMMITTEE_FOR_NOMINATION_PERIOD'
				AND ROUTINE_TYPE = 'PROCEDURE' )
BEGIN
	PRINT 'Stored procedure SAVE_COMMITTEE_FOR_NOMINATION_PERIOD created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create stored procedure SAVE_COMMITTEE_FOR_NOMINATION_PERIOD.';
END
GO
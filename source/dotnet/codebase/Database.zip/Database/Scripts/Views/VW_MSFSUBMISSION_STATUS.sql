/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Project Name			: NQF
 * --View name				: vw_MSFSubmissionStatus
 * --Purpose/Function		: 
 * --Author					: WM
 * --Start Date(MM-DD-YYYY)	: 12/15/09
 * --Change History:
 * --Author				Date			Description
 * --		
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================*/

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF object_id('vw_MSFSubmissionStatus', 'V') IS NOT NULL

BEGIN
	PRINT 'Dropping View vw_MSFSubmissionStatus.';
	DROP VIEW vw_MSFSubmissionStatus;
END

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
GO


CREATE VIEW [dbo].[vw_MSFSubmissionStatus]


AS
SELECT     ID, SUBMISSION_STATUS_ID, SUBMISSION_STATUS_NAME
FROM         dbo.MSF_SUBMISSION_STATUS
WHERE	
	(SUBMISSION_STATUS_ID = 1) 
OR	(SUBMISSION_STATUS_ID = 3) 
OR	(SUBMISSION_STATUS_ID = 11)
OR	(SUBMISSION_STATUS_ID = 12)
OR	(SUBMISSION_STATUS_ID = 10)
OR	(SUBMISSION_STATUS_ID = 9)
OR	(SUBMISSION_STATUS_ID = 13)
OR	(SUBMISSION_STATUS_ID = 7)
OR	(SUBMISSION_STATUS_ID = 17)
OR	(SUBMISSION_STATUS_ID = 14)
OR	(SUBMISSION_STATUS_ID = 15)
OR	(SUBMISSION_STATUS_ID = 6)
OR	(SUBMISSION_STATUS_ID = 18)
OR	(SUBMISSION_STATUS_ID = 19)
OR	(SUBMISSION_STATUS_ID = 20)
OR	(SUBMISSION_STATUS_ID = 21)
OR	(SUBMISSION_STATUS_ID = 22)
OR	(SUBMISSION_STATUS_ID = 23)
OR	(SUBMISSION_STATUS_ID = 24)
OR	(SUBMISSION_STATUS_ID = 25)
OR	(SUBMISSION_STATUS_ID = 26)
OR	(SUBMISSION_STATUS_ID = 27)
OR	(SUBMISSION_STATUS_ID = 28)
OR	(SUBMISSION_STATUS_ID = 29)
OR	(SUBMISSION_STATUS_ID = 30)
OR	(SUBMISSION_STATUS_ID = 31)
OR	(SUBMISSION_STATUS_ID = 32)
OR	(SUBMISSION_STATUS_ID = 33)
OR	(SUBMISSION_STATUS_ID = 34)
OR	(SUBMISSION_STATUS_ID = 35)
OR	(SUBMISSION_STATUS_ID = 36)
OR	(SUBMISSION_STATUS_ID = 37)
OR	(SUBMISSION_STATUS_ID = 38)

GO

-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF object_id('vw_MSFSubmissionStatus', 'V') IS NOT NULL
BEGIN
	PRINT 'View vw_MSFSubmissionStatus created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create View vw_MSFSubmissionStatus.';
END
GO
/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Project Name			: NQF
 * --View name				: VW_REPORT_COMMENT_LIST
 * --Purpose/Function		: 
 * --Author					: MZ
 * --Start Date(MM-DD-YYYY)	: 10/01/10
 * --Change History:
 * --Author				Date			Description
 * --		
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================*/

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF object_id('VW_REPORT_COMMENT_LIST', 'V') IS NOT NULL

BEGIN
	PRINT 'Dropping View VW_REPORT_COMMENT_LIST.';
	DROP VIEW VW_REPORT_COMMENT_LIST;
END

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
GO


CREATE VIEW [dbo].[VW_REPORT_COMMENT_LIST]

AS

SELECT     
	MC.ProjectID, 
	MC.CommentID, 
	MC.CommentType AS CommentTypeID, 
	CT.Name AS CommentType, 
	MC.Status AS CommentStatus, 
    MS.XML_DATA.value('(/tabs/tab[@id="2"]/NQFReviewTitle/text())[1]', 'varchar(2000)') AS MeasureTitle, 
	MC.DTS AS DateSubmitted, 
    MUD.FULL_NAME AS CommentByName, 
	MUD.InstituteName AS CommentByOrganization, 
	MUD.PrimaryCouncil AS CommentByMemberCouncil, 
    MUD.EMAIL AS CommentByEmail, 
	MC.Comment, 
	OBI.FirstName + ' ' + OBI.LastName AS OnBehalfName, 
	OBI.Organization AS OnBehalfOrganization, 
    OBI.PrimaryCouncil AS OnBehalfMemberCouncil, 
	OBI.Email AS OnBehalfEmail, 
	MS.IMISUserID AS SubmitterID, 
    MUD1.InstituteName AS SubmitterOrganization, 
	MC.ActivityID AS CommentingPeriod, 
	MC.SubmitterIMISUserID AS CommentBy, 
	MC.MeasureID, 
    MC.IsMemberComment, 
	ISNULL(SNOC.IsFinalRemark, 0) AS IsFinalRemark, 
	MC.IsTop, 
	MC.GroupID, 
	SR.ResponseText, 
    SNOC.StaffNotes AS FollowupText, 
	SNOC.FinalRemark AS StaffNotes
FROM         
	dbo.MEASURE_COMMENTS AS MC 
	LEFT OUTER JOIN
    dbo.MSF_SUBMISSIONS AS MS 
	ON MC.MeasureID = MS.ID 
	LEFT OUTER JOIN
    dbo.IMIS_USER_DETAILS AS MUD 
	ON MC.SubmitterIMISUserID = MUD.IMISUserID 
	LEFT OUTER JOIN
    dbo.COMMENT_ON_BEHALF_OF_INFORMATION AS OBI 
	ON MC.OnBehalfID = OBI.ID 
	LEFT OUTER JOIN
    dbo.IMIS_USER_DETAILS AS MUD1 
	ON MS.IMISUserID = MUD1.IMISUserID 
	LEFT OUTER JOIN
    dbo.STAFF_NOTES_ON_COMMENTS AS SNOC 
	ON MC.CommentID = SNOC.CommentID 
	LEFT OUTER JOIN
    dbo.SUBMITTER_RESPONSE_ON_COMMENT AS SR 
	ON MC.CommentID = SR.CommentID 
	INNER JOIN
    dbo.COMMENT_TYPE AS CT 
	ON MC.CommentType = CT.ID
	WHERE
	MS.IsDeleted=0
GO

-- select * from VW_REPORT_COMMENT_LIST
-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF object_id('VW_REPORT_COMMENT_LIST', 'V') IS NOT NULL
BEGIN
	PRINT 'View VW_REPORT_COMMENT_LIST created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create View VW_REPORT_COMMENT_LIST.';
END
GO
/*
 * ====================================================================
 * BASIC INFORMATION
 * ====================================================================
 *
 * --Project Name			: NQF
 * --View name				: VW_MEETING_DATES_WITH_MEASURES
 * --Purpose/Function		: 
 * --Author					: MZ
 * --Start Date(MM-DD-YYYY)	: 10/01/10
 * --Change History:
 * --Author				Date			Description
 * --		
 * ====================================================================
 * IMPLEMENTATION LOGIC
 * ====================================================================
 *
 * --
 *
 * ====================================================================
 * PERFORMANCE (To be filled up by developer,with "Yes" values)
 * ====================================================================
 *
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================
 * REVIEW (To be filled up by reviewer,with "Yes" values)
 * ===================================================================
 *
 * --Reviewed by				: 
 * --Review	date				: 
 * --TSQL reviewed				: No
 * --Indexing done properly		: No
 * --Index fragmentation checked: No
 * --Comment					: No comment
 *
 * ===================================================================*/

SET QUOTED_IDENTIFIER OFF;
SET ANSI_NULLS ON;
SET NOCOUNT ON;
GO

IF object_id('VW_MEETING_DATES_WITH_MEASURES', 'V') IS NOT NULL

BEGIN
	PRINT 'Dropping View VW_MEETING_DATES_WITH_MEASURES.';
	DROP VIEW VW_MEETING_DATES_WITH_MEASURES;
END

-------------------------------------------------------------------------------
--	METADATA AND OTHER MESSAGES ABOVE.
--	BEGIN CREATE STATEMENTS.
-------------------------------------------------------------------------------
GO


CREATE VIEW [dbo].[VW_MEETING_DATES_WITH_MEASURES]

AS

SELECT 
	DISTINCT MeetingDateID,sc.MeasureID
FROM 
	GROUP_MEETING_DATES_FOR_MEASURE gm
INNER JOIN
	MSF_STATUS_CHANGE sc
ON
	gm.MsfStatusChangeID = sc.MsfStatusChangeID
INNER JOIN
	MSF_SUBMISSIONS ms
ON
	ms.ID = sc.MeasureID
	--AND ms.StatusSubmitted = 19


GO

-- select * from VW_MEETING_DATES_WITH_MEASURES
-------------------------------------------------------------------------------
--	END OF CREATE STATEMENTS.
--	METADATA AND SUCCESS/ERROR MESSAGES BELOW.
-------------------------------------------------------------------------------
IF object_id('VW_MEETING_DATES_WITH_MEASURES', 'V') IS NOT NULL
BEGIN
	PRINT 'View VW_MEETING_DATES_WITH_MEASURES created successfully.';	
END
ELSE
BEGIN
	PRINT 'ERROR: Failed to create View VW_MEETING_DATES_WITH_MEASURES.';
END
GO
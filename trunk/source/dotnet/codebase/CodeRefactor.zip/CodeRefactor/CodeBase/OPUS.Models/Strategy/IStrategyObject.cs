namespace OPUS.Entity.Strategy
{
    /// <summary>
    /// 
    /// </summary>
    public interface IStrategyObject
    {
    }
}



﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Model
 * Name: OPUSStepType.cs
 * Purpose: Entity model class for OPUSStepType
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/10/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using OPUS.Models.Base;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class OPUSStepType : TableLevelAuditEntity
    {
        #region Properties

        /// <summary>
        /// Gets or sets the TypeName
        /// </summary>
        /// <value>The TypeName.</value>
        public string TypeName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the TypeIndicator
        /// </summary>
        /// <value>The TypeIndicator.</value>
        public OPUSStepType TypeIndicator
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        // TODO: Add reference properties here.
        #endregion

        #region Methods

        // TODO: Add methods here.
        #endregion

        #region Override Methods

        // TODO: Add methods here.
        #endregion
    }
}
﻿using System.ComponentModel;
using OPUS.Models.History;

namespace OPUS.Models.Base
{
    public class PropertyAuditChangedEventArgs : PropertyChangedEventArgs
    {
        public PropertyAuditChangedEventArgs(string propertyName, HistoryData historyData)
            : base(propertyName)
        {
            HistoryData = historyData;
        }

        public HistoryData HistoryData { get; private set; }
    }
}
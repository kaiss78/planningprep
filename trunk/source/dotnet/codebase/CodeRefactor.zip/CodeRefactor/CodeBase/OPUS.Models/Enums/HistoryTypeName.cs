﻿using System;
using System.ComponentModel;

namespace OPUS.Models.Enums
{
    [Flags]
    public enum HistoryType
    {
        [Description("Project")]
        Project,
        [Description("Committee")]
        Committee,
        [Description("Staffing")]
        Staffing,
        [Description("Intent")]
        Intent,
        [Description("Intent Submission")]
        IntentSubmission,
        [Description("Project Step")]
        ProjectStep,
        [Description("Call for nominations")]
        CallForNominations,
        [Description("Nomination Period")]
        NominationPeriod,
        [Description("Nomination commenting period")]
        NominationCommentingPeriod,
        [Description("Nomination Committee")]
        NominationCommittee,
        [Description("Nominee")]
        Nominee,
        [Description("Call for candidate standards")]
        CallForStandards,
        [Description("Measure Submission Period")]
        MeasureSubmissionPeriod,
        [Description("Reassigned Submitter")]
        ReassignedSubmitter,
        [Description("Measure Status")]
        MeasureStatus,
        [Description("Candidate Consensus Standards Review")]
        CandidateConsensusStandardsReview
    }
}



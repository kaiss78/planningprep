﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Model
 * Name: ProjectStep.cs
 * Purpose: Entity model class for ProjectStep
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/10/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using System.Collections.Generic;
using OPUS.Models.Base;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class ProjectStep : TableLevelAuditEntity
    {
        #region Properties

        /// <summary>
        /// Gets or sets the SubmissionId
        /// </summary>
        /// <value>The SubmissionId.</value>
        public long SubmissionId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the StepId
        /// </summary>
        /// <value>The StepId.</value>
        public long OPUSStepId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ParentStepId
        /// </summary>
        /// <value>The ParentStepId.</value>
        public long ParentStepId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the SortOrder
        /// </summary>
        /// <value>The SortOrder.</value>
        public int SortOrder
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        public ProjectSubmission ProjectSubmission { get; set; }

        public OPUSStep Step { get; set; }

        public ProjectStep ParentStep { get; set; }

        public List<ProjectStepDataDefinition> DataDefinition { get; set; }

        public List<ProjectStepData> Data { get; set; }
        #endregion

        #region Methods
        // TODO: Add methods here.
        #endregion

        #region Override Methods
        // TODO: Add override methods here.
        #endregion
    }
}
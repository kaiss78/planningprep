﻿using OPUS.Models.Enums;

namespace OPUS.Models.ProjectSteps
{
    public class CustomStep : OPUSStep
    {
        public override OPUSStepTypes TypeIndicator
        {
            get { return OPUSStepTypes.Custom; }
            set { }
        }
    }
}

﻿using System;
using OPUS.Models.Enums;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class SubmissionPeriodStep : OPUSStep
    {
        public override OPUSStepTypes TypeIndicator
        {
            get { return OPUSStepTypes.SubmissionPeriod; }
            set { }
        }
    }
}



﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Model
 * Name: OPUSStep.cs
 * Purpose: Entity model class for OPUSStep
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/10/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using OPUS.Models.Enums;
using OPUS.Models.Base;

namespace OPUS.Models.ProjectSteps
{
	[Serializable]
	public abstract class OPUSStep : HistoryEntity
	{
		#region Fields
		#endregion

		#region Properties

		/// <summary>
		/// Gets or sets the TypeId
		/// </summary>
		/// <value>The TypeId.</value>
		public long TypeId
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the TypeIndicator
		/// </summary>
		/// <value>The TypeIndicator.</value>
		public abstract OPUSStepTypes TypeIndicator
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		/// <value>The Name.</value>
		public string Name
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the StartDate
		/// </summary>
		/// <value>The StartDate.</value>
		public DateTime StartDate
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the EndDate
		/// </summary>
		/// <value>The EndDate.</value>
		public DateTime EndDate
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the BeforePeriodDescription
		/// </summary>
		/// <value>The BeforePeriodDescription.</value>
		public string BeforePeriodDescription
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the DuringPeriodDescription
		/// </summary>
		/// <value>The DuringPeriodDescription.</value>
		public string DuringPeriodDescription
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the AfterPeriodDescription
		/// </summary>
		/// <value>The AfterPeriodDescription.</value>
		public string AfterPeriodDescription
		{
			get;
			set;
		}

		/// <summary>
		/// Gets or sets the DetailPage
		/// </summary>
		/// <value>The DetailPage.</value>
		public string DetailPage
		{
			get;
			set;
		}
		#endregion

		#region Reference Properties
		// TODO: Add reference properties here.
		#endregion

		#region Methods
		// TODO: Add methods here.
		#endregion

		#region Override Methods
		// TODO: Add override methods here.
		#endregion
	}
}
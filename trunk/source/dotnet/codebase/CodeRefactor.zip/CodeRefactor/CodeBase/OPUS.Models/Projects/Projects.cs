﻿


#region File Info/History
/*
 * =============================================
 * Project Name: [Project Name]
 * Assembly:	   [Assembly Name]
 * Name:		Project
 * Purpose: Project entity class 
 * Language: C# SDK version 3.5
 * Change History
 * =============================================
 * Jason Duffus	1/9/2010 8:34:46 PM		Initial Code
 * =============================================
 */
#endregion

using System;
using OPUS.Models.Base;

namespace OPUS.Models.Projects
{
    [Serializable]
    public class Project : HistoryEntity
    {
        #region Fields

        // Reference Properties
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        /// <value>The Name.</value>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ShortName
        /// </summary>
        /// <value>The ShortName.</value>
        public string ShortName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the StartDate
        /// </summary>
        /// <value>The StartDate.</value>
        public DateTime StartDate
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the EndDate
        /// </summary>
        /// <value>The EndDate.</value>
        public DateTime EndDate
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the TypeId
        /// </summary>
        /// <value>The TypeId.</value>
        public long TypeId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Status
        /// </summary>
        /// <value>The Status.</value>
        public string Status
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the StatusSummary
        /// </summary>
        /// <value>The StatusSummary.</value>
        public string StatusSummary
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Explanation
        /// </summary>
        /// <value>The Explanation.</value>
        public string Explanation
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ShortDescription
        /// </summary>
        /// <value>The ShortDescription.</value>
        public string ShortDescription
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the FullDescription
        /// </summary>
        /// <value>The FullDescription.</value>
        public string FullDescription
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the SoftekId
        /// </summary>
        /// <value>The SoftekId.</value>
        public long SoftekId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the SubmissionInstruction
        /// </summary>
        /// <value>The SubmissionInstruction.</value>
        public string SubmissionInstruction
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the DetailIntro
        /// </summary>
        /// <value>The DetailIntro.</value>
        public string DetailIntro
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Proposal
        /// </summary>
        /// <value>The Proposal.</value>
        public string Proposal
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Contract
        /// </summary>
        /// <value>The Contract.</value>
        public string Contract
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Conditions
        /// </summary>
        /// <value>The Conditions.</value>
        public string Conditions
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the CareSettings
        /// </summary>
        /// <value>The CareSettings.</value>
        public string CareSettings
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the NPPTopics
        /// </summary>
        /// <value>The NPPTopics.</value>
        public string NPPTopics
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Completed
        /// </summary>
        /// <value>The Completed.</value>
        public bool Completed
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        public ProjectType ProjectType { get; set; }
        #endregion

        #region Methods

        // TODO: Add methods here.
        #endregion

        #region Business Validations

        // TODO: Add methods here.
        #endregion
    }
}

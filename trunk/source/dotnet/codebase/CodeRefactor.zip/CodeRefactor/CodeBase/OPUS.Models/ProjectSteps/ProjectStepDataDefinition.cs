﻿#region File Info/History
    /*
 * =============================================
 * Project Name: [Project Name]
 * Assembly:	   [Assembly Name]
 * Name:		ProjectStepDataDefinition
 * Purpose: ProjectStepDataDefinition entity class 
 * Language: C# SDK version 3.5
 * Change History
 * =============================================
 * Jason Duffus	1/10/2010 4:24:02 AM		Initial Code
 * =============================================
 */
#endregion

using System;
using OPUS.Models.Base;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class ProjectStepDataDefinition : TableLevelAuditEntity
    {
        #region Fields
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the StepID
        /// </summary>
        /// <value>The StepID.</value>
        public long StepID
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the FieldName
        /// </summary>
        /// <value>The FieldName.</value>
        public string FieldName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the WebCaption
        /// </summary>
        /// <value>The WebCaption.</value>
        public string WebCaption
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the DataType
        /// </summary>
        /// <value>The DataType.</value>
        public string DataType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Required
        /// </summary>
        /// <value>The Required.</value>
        public bool Required
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the DefaultValue
        /// </summary>
        /// <value>The DefaultValue.</value>
        public string DefaultValue
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the MinValue
        /// </summary>
        /// <value>The MinValue.</value>
        public string MinValue
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the MaxValue
        /// </summary>
        /// <value>The MaxValue.</value>
        public string MaxValue
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ControlType
        /// </summary>
        /// <value>The ControlType.</value>
        public string ControlType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the SelectionOptions
        /// </summary>
        /// <value>The SelectionOptions.</value>
        public string SelectionOptions
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        // TODO: Add reference properties here.
        #endregion

        #region Methods

        // TODO: Add methods here.
        #endregion

        #region Business Validations

        // TODO: Add methods here.
        #endregion
    }
}

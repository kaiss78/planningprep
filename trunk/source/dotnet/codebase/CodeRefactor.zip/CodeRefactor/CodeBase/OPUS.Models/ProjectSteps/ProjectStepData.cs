﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Model
 * Name: ProjectStepData.cs
 * Purpose: Entity model class for ProjectStepData
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/10/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using OPUS.Models.Base;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class ProjectStepData : TableLevelAuditEntity
    {
        #region Fields
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the DefinitionId
        /// </summary>
        /// <value>The DefinitionId.</value>
        public long DefinitionId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ProjectStepId
        /// </summary>
        /// <value>The ProjectStepId.</value>
        public long ProjectStepId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Value
        /// </summary>
        /// <value>The Value.</value>
        public string Value
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        public ProjectStepDataDefinition DataDefinition { get; set; }

        public ProjectStep Step { get; set; }
        #endregion

        #region Methods
        // TODO: Add methods here.
        #endregion

        #region Override Methods
        // TODO: Add override methods here.
        #endregion
    }
}
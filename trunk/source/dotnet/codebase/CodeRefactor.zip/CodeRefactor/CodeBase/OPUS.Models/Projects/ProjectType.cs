﻿
#region File Info/History
/*
 * =============================================
 * Project Name: [Project Name]
 * Assembly:	   [Assembly Name]
 * Name:		ProjectType
 * Purpose: ProjectType entity class 
 * Language: C# SDK version 3.5
 * Change History
 * =============================================
 * Jason Duffus	1/9/2010 8:39:46 PM		Initial Code
 * =============================================
 */
#endregion

using System;
using OPUS.Models.Base;

namespace OPUS.Models.Projects
{
    [Serializable]
    public class ProjectType : HistoryEntity
    {
        #region Fields

        // Reference Properties
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the TypeName
        /// </summary>
        /// <value>The TypeName.</value>
        public string TypeName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the WebTitle
        /// </summary>
        /// <value>The WebTitle.</value>
        public string WebTitle
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        // TODO: Add reference properties here.
        #endregion

        #region Methods

        // TODO: Add methods here.
        #endregion

        #region Business Validations

        // TODO: Add methods here.
        #endregion
    }
}

﻿using System;

namespace OPUS.Models.Enums
{
    [Flags]
    public enum OPUSDbType : byte
    {
        DbTypeInteger = 1,
        DbTypeLong = 2,
        DbTypeString = 3,
        DbTypeDateTime = 4,
        DbTypeBit = 5
    }
}
﻿using System;
using OPUS.Models.Enums;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class NominationPeriodStep : OPUSStep
    {
        public override OPUSStepTypes TypeIndicator
        {
            get { return OPUSStepTypes.NominationPeriod; }
            set { }
        }
    }
}



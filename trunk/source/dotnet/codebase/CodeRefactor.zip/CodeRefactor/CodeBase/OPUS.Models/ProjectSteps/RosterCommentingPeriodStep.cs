﻿using System;
using OPUS.Models.Enums;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class RosterCommentingPeriodStep : OPUSStep
    {
        public override OPUSStepTypes TypeIndicator
        {
            get { return OPUSStepTypes.RosterCommentingPeriod; }
            set{}
        }
    }
}



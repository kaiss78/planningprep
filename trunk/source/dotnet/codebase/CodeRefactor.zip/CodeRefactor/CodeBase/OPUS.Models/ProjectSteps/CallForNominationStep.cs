﻿using System;
using OPUS.Models.Enums;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class CallForNominationStep : OPUSStep
    {
        public override OPUSStepTypes TypeIndicator
        {
            get { return OPUSStepTypes.CallForNomination; }
            set { }
        }
    }
}



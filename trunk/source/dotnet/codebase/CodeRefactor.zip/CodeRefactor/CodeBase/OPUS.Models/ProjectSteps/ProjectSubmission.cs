﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Model
 * Name: ProjectSubmission.cs
 * Purpose: Entity model class for ProjectSubmission
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/11/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using System.Collections.Generic;
using OPUS.Models.Base;
using OPUS.Models.Projects;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class ProjectSubmission : TableLevelAuditEntity
    {
        #region Properties
        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        /// <value>The Name.</value>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ProjectId
        /// </summary>
        /// <value>The ProjectId.</value>
        public long ProjectId
        {
            get;
            set;
        }
        #endregion

        #region Reference Properties
        public Project Project
        {
            get;
            set;
        }

        public List<ProjectStep> ProjectSteps
        {
            get;
            set;
        }
        #endregion

        #region Methods
        // TODO: Add methods here.
        #endregion

        #region Override Methods
        // TODO: Add override methods here.
        #endregion
    }
}

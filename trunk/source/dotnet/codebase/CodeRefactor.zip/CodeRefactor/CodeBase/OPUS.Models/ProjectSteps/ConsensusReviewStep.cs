﻿using System;
using OPUS.Models.Enums;

namespace OPUS.Models.ProjectSteps
{
    [Serializable]
    public class ConsensusReviewStep : OPUSStep
    {
        public override OPUSStepTypes TypeIndicator
        {
            get { return OPUSStepTypes.ConsensusReview; }
            set { }
        }
    }
}



﻿using System;
using System.ComponentModel;

namespace OPUS.Models.Enums
{
    [Flags]
    public enum OPUSStepTypes
    {
        [Description("Custom")]
        Custom = 0,
        [Description("Call For Intent")]
        CallForIntent = 1,
        [Description("Call For Nomination")]
        CallForNomination = 2,
        [Description("Call For Standard")]
        CallForStandard = 3,
        [Description("Consensus Review")]
        ConsensusReview = 4,
        [Description("Nomination Period")]
        NominationPeriod = 5,
        [Description("Roster Commenting Period")]
        RosterCommentingPeriod = 6,
        [Description("Submission Period")]
        SubmissionPeriod = 7
    }
}

﻿using System;
using System.Collections.Generic;
using OPUS.Models.Projects;
using Pantheon.Core.Base.Managers;

namespace OPUS.Domain.Projects
{
    public class ProjectTypeManager : ManagerBase<ProjectType>
    {
        /*
        public List<T> GetList(bool loadSteps)
        {
            ProjectTypeDAO dao = new ProjectTypeDAO();
            List<T> listOfProjectType = dao.GetList() as List<T>;

            if (loadSteps == true)
            {
                foreach (OPUSProjectType projectType in listOfProjectType)
                {
                    ProjectTypeStepBLL<OPUSProjectTypeStep> blo = new ProjectTypeStepBLL<OPUSProjectTypeStep>();
                    projectType.ListOfProjectTypeSteps = blo.GetProjectTypeStepsByProjectType(projectType.Id);                    
                }
            }
            return listOfProjectType;
        }
        */
        public override void SaveOrUpdate(ProjectType entity)
        {
            throw new NotImplementedException();
        }

        public override ProjectType Get(long id)
        {
            throw new NotImplementedException();
        }

        public override ProjectType Get(long id, bool eagerLoad)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<ProjectType> GetList()
        {
            throw new NotImplementedException();
        }

        public override bool Delete(ProjectType entity)
        {
            throw new NotImplementedException();
        }
    }
}



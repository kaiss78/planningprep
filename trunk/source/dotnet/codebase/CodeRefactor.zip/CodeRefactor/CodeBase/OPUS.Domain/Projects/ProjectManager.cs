﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Domain
 * Name: ProjectManager.cs
 * Purpose: manager class for Project entity.
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/12/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using System.Collections.Generic;
using System.Transactions;
using OPUS.Data;
using OPUS.Data.Projects;
using OPUS.Models.Projects;
using Pantheon.Core;
using Pantheon.Core.Base.Managers;
using Pantheon.Core.Exceptions;

namespace OPUS.Domain.Projects
{
    public interface IProjectManager : IManagerBase<Project>
    { }

    public class ProjectManager : ManagerBase<Project>, IProjectManager
    {
        public ProjectManager()
        { }

        #region CRUD Methods
        public override void SaveOrUpdate(Project entity)
        {
            using (new TimedTraceLog(GetType().Name + ".SaveOrUpdate(Project)", ""))
            {
                try
                {
                    using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, TimeSpan.FromSeconds(60)))
                    {
                        using (IProjectDAO dao = (IProjectDAO)DAOFactory.Get<Project>())
                        {
                            dao.Save(entity);
                        }
                        scope.Complete();
                    }
                }
                catch (Exception ex)
                {
                    ExceptionHelper.HandleException<ManagerException>(ex, GetType().Name + ".SaveOrUpdate(Project)");
                }
            } 
        }

        public override Project Get(long id)
        {
            Project project = null;
            try
            {
                using (IProjectDAO dao = (IProjectDAO)DAOFactory.Get<Project>())
                {
                    project = dao.Get(id, false);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException<ManagerException>(ex);
            }
            return project;
        }

        public override Project Get(long id, bool eagarLoad)
        {
            Project project = null;
            try
            {
                using (IProjectDAO dao = (IProjectDAO)DAOFactory.Get<Project>())
                {
                    project = dao.Get(id, eagarLoad);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException<ManagerException>(ex);
            }
            return project;
        }

        public override IEnumerable<Project> GetList()
        {
            IEnumerable<Project> projectList = new List<Project>();
            try
            {
                using (IProjectDAO dao = (IProjectDAO)DAOFactory.Get<Project>())
                {
                    projectList = dao.GetAll(u => u.Active && !u.Deleted);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException<ManagerException>(ex);
            }
            return projectList;
        }

        public override bool Delete(Project entity)
        {
            bool result = false;
            try
            {
                using (IProjectDAO dao = (IProjectDAO)DAOFactory.Get<Project>())
                {
                    result = dao.Delete(entity);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException<ManagerException>(ex);
            }
            return result;
        }
        #endregion
    }
}
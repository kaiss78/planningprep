﻿using OPUS.Models.ProjectSteps;

namespace OPUS.Domain.ProjectSteps
{
    public class ConsensusReviewManager : OPUSStepManager<ConsensusReviewStep>
    {
        public ConsensusReviewManager()
        {
        }
    }
}



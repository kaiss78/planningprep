﻿using System;
using System.Collections.Generic;
using OPUS.Models.ProjectSteps;
using Pantheon.Core.Base.Managers;

namespace OPUS.Domain.ProjectSteps
{
    public interface IOPUSStepTypeManager
    {}

    public class OPUSStepTypeManager : ManagerBase<OPUSStepType>, IOPUSStepTypeManager
    {
        public override void SaveOrUpdate(OPUSStepType entity)
        {
            throw new NotImplementedException();
        }

        public override OPUSStepType Get(long id)
        {
            throw new NotImplementedException();
        }

        public override OPUSStepType Get(long id, bool eagarLoad)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<OPUSStepType> GetList()
        {
            throw new NotImplementedException();
        }

        public override bool Delete(OPUSStepType entity)
        {
            throw new NotImplementedException();
        }
    }
}
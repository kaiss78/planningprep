﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OPUS.Entity;
using OPUS.Models.Users;
using Pantheon.Core.Base;
using Pantheon.Core.Base.Model;

namespace OPUS.BLL
{
    public abstract class BaseBusinessObject<T> : IBusinessObject<T> where T : BaseEntity
    {
        protected BaseBusinessObject()
        {
        }

        protected BaseBusinessObject(T entity)
        {
            Entity = entity;
        }

        public T Entity { get; private set; }

        public OPUSUser LoggedInUser { get; set; }

        public abstract void Save();

        public abstract T Get(long id);

        public abstract List<T> GetList();

        public abstract bool Delete(long id);
    }
}

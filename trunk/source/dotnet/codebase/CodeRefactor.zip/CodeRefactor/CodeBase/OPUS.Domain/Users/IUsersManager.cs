﻿using OPUS.Models.Users;
using Pantheon.Core.Base.Managers;

namespace OPUS.Domain.Users
{
    public interface IUsersManager : IManagerBase<User>
    {
        
    }
}
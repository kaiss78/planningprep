﻿#region File Info/History
/* --------------------------------------------------------------------------------
 * Client Name: NQF
 * Project Name: OPUS
 * Module: OPUS.Domain
 * Name: ProjectSubmissionManager.cs
 * Purpose: manager class for ProjectSubmission entity.
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * version: 1.0    Jason Duffus  1/12/2010	Initial Development
 * -------------------------------------------------------------------------------- */
#endregion

using System;
using System.Collections.Generic;
using OPUS.Models.ProjectSteps;
using Pantheon.Core.Base.Managers;

namespace OPUS.Domain.ProjectSteps
{
    public interface IProjectSubmissionManager : IManagerBase<ProjectSubmission>
    { }

    public class ProjectSubmissionManager : ManagerBase<ProjectSubmission>, IProjectSubmissionManager
    {
        public ProjectSubmissionManager()
        { }

        #region CRUD Methods
        public override void SaveOrUpdate(ProjectSubmission entity)
        {
            throw new NotImplementedException();
        }

        public override ProjectSubmission Get(long id)
        {
            throw new NotImplementedException();
        }

        public override ProjectSubmission Get(long id, bool eagarLoad)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<ProjectSubmission> GetList()
        {
            throw new NotImplementedException();
        }

        public override bool Delete(ProjectSubmission entity)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
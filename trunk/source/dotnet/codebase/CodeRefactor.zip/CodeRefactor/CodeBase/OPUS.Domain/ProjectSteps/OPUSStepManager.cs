﻿using System;
using System.Collections.Generic;
using OPUS.Models.ProjectSteps;
using Pantheon.Core.Base.Managers;

namespace OPUS.Domain.ProjectSteps
{
    public class OPUSStepManager<T> : ManagerBase<T>
        where T : OPUSStep
    {
        public OPUSStepManager()
        {
        }

        public override void SaveOrUpdate(T entity)
        {
            throw new NotImplementedException();
        }

        public override T Get(long id)
        {
            throw new NotImplementedException();
        }

        public override T Get(long id, bool eagarLoad)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<T> GetList()
        {
            throw new NotImplementedException();
        }

        public override bool Delete(T entity)
        {
            throw new NotImplementedException();
        }
    }
}



﻿using System;
using System.Collections.Generic;
using OPUS.Models.ProjectSteps;
using Pantheon.Core.Base.Managers;
using Pantheon.Core.Base.Managers.Responses;

namespace OPUS.Domain.ProjectSteps
{
    public class ProjectStepManager : ManagerBase<ProjectStep>
    {
        public override void SaveOrUpdate(ProjectStep entity)
        {
            throw new NotImplementedException();
        }

        public override ProjectStep Get(long id)
        {
            throw new NotImplementedException();
        }

        public override ProjectStep Get(long id, bool eagarLoad)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<ProjectStep> GetList()
        {
            throw new NotImplementedException();
        }

        public override bool Delete(ProjectStep entity)
        {
            throw new NotImplementedException();
        }
    }

    /*
      #region Constructor
        private T _projectStep;

        public ProjectStepManager(T projectStep)
            : base(projectStep)
        {
            _projectStep = projectStep;
        }

        public ProjectStepManager()
        {

        }
        #endregion
        
        #region IBusinessObject Members

        /// <summary>
        /// Saves this instance.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        public override void Save()
        {
            ProjectStepDAO<T> dao = ManagerFactory.
            dao.Save(_projectStep);
        }

        /// <summary>
        /// Gets the specified object ID.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        /// <param name="objectID">The object ID.</param>
        /// <returns></returns>
        public override T Get(long objectID)
        {

            ProjectStepDAO<T> dao = new ProjectStepDAO<T>();
            return dao.Get(objectID);
        }

        /// <summary>
        /// Gets all project steps by step type.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        /// <param name="projectID">The project ID.</param>
        /// <param name="projectTypeStepID">The project type step ID.</param>
        /// <returns></returns>
        public T Get(long projectID, long projectTypeStepID)
        {
            ProjectStepDAO<T> dao = new ProjectStepDAO<T>();
            return dao.Get(projectID, projectTypeStepID);
        }

        /// <summary>
        /// Gets the list.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        /// <returns></returns>
        public override List<T> GetList()
        {
            throw new NotImplementedException();
        }

        public override bool Delete(long id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods
        

        /// <summary>
        /// Gets all project child steps by parent step and step type.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        /// <param name="projectParentStepID">The project parent step ID.</param>
        /// <param name="projectTypeStepID">The project type step ID.</param>
        /// <returns></returns>
        public T GetChildSteps(long projectParentStepID, long projectTypeStepID)
        {
            ProjectStepDAO<T> dao = new ProjectStepDAO<T>();
            return dao.GetChildSteps(projectParentStepID, projectTypeStepID) as T;
        }

        /// <summary>
        /// Gets all project child steps by parent step.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        /// <param name="projectParentStepID">The project parent step ID.</param>
        /// <returns></returns>
        public T GetChildSteps(long projectParentStepID)
        {
            ProjectStepDAO<T> dao = new ProjectStepDAO<T>();
            return dao.GetChildSteps(projectParentStepID) as T;
        }

        /// <summary>
        /// Get All OPUSProjectStep For a Project
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public List<T> GetAllOPUSProjectStepsForAProject(long projectID)
        {
            ProjectStepDAO<T> dal = new ProjectStepDAO<T>();
            return dal.GetAllOPUSProjectStepsForAProject(projectID);
        }
        #endregion

        #region Methods for business rules
        public bool LoggedInUserHasEditAccessToProjectStep()
        {
            try
            {
                if (LoggedInUser != null)
                {
                    OPUSUserManager blo = new OPUSUserManager();
                    return blo.LoggedInUserHasEditAccessToProject(this.LoggedInUser, _projectStep.ProjectID);
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new DomainException("Error checking if logged in user has edit access to project step.", ex, "ProjectStepBLL.LoggedInUserHasEditAccessToProjectStep()");
            }
        }
        #endregion

        #region Methods to validate business rules
        public bool ValidatePreConditionToCreate(List<ValidationError> errors)
        {
            // Instantiate the validation result object
            ValidationResult result = new ValidationResult();
            //Validate the rule
            result = new BusinessRuleValidator.PreConditionToCreateValidator(result).Validate(this);
            errors.AddRange(result.Errors);

            return result.IsValid;
        }
        #endregion

        #region BusinessRules

        public class BusinessRules
        {
            public class PreConditionToCreate
            {
                /// <summary>
                /// Gets the intent to call must be setup.
                /// </summary>
                /// <value>The intent to call must be setup.</value>
                public static Specification<ProjectStepManager<T>> LoggedInUserHasEditAccess
                {
                    get
                    {
                        return new Specification<ProjectStepManager<T>>(ps => ps.LoggedInUserHasEditAccessToProjectStep());
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class BusinessRuleValidator 
        {
            public class PreConditionToCreateValidator : EntityValidatorBase<ProjectStepManager<T>>
            {
                /// <summary>
                /// Initializes a new instance of the <see cref="BusinessRuleValidator"/> class.
                /// </summary>
                /// <param name="result">The result.</param>
                public PreConditionToCreateValidator(ValidationResult result)
                    : base(result)
                {
                    AddValidation("Logged in user must have edit access to the project", new ValidationRule<ProjectStepManager<T>>(BusinessRules.PreConditionToCreate.LoggedInUserHasEditAccess, "The logged in user does not have enough accesss to create project step.", "Security check"));                    
                }
            }
        }


        #endregion
     */
}



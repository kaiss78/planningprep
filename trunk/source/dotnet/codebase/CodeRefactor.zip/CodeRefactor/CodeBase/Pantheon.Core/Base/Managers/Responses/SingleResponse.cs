﻿using Pantheon.Core.Base.Model;

namespace Pantheon.Core.Base.Managers.Responses
{
    public class SingleResponse : PanthResponse
    {
        public BaseEntity Object { get; set; }
    }
}

﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: OPUS
 * Module: OPUS.Data
 * Name: ProjectTypeDAO.cs
 * Purpose: DAO Class to get/set the data from ProjectTypes table.
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/11/2010 00:14:57		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Data;
using OPUS.Models.Projects;
using Pantheon.Core.DB;
using Pantheon.Core.Factories;

namespace OPUS.Data.Projects
{
    public class ProjectTypeDAO : BaseDataAccess<ProjectType>, IProjectTypeDAO
    {
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectTypeDAO"/> class.
        /// </summary>
        public ProjectTypeDAO()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectTypeDAO"/> class.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        public ProjectTypeDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Helper Methods
        protected override ProjectType Map(IDataReader reader)
        {
            ProjectType entity = EntityFactory.Create<ProjectType>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.TypeName = NullHandler.GetString(reader["TypeName"]);
            entity.WebTitle = NullHandler.GetString(reader["WebTitle"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            return entity;
        }

        protected override void EagerLoad(ProjectType entity)
        {
            // Add eager loading functionality here
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(ProjectType entity)
        {
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(ProjectType entity)
        {
        }

        #endregion
    }
}
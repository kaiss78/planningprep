﻿using OPUS.Models.ProjectSteps;

namespace OPUS.Data.ProjectSteps
{
    public class CallForIntentStepDAO : OpusStepDAO<CallForIntentStep>, ICallForIntentStepDAO
    {
    }
}



﻿using OPUS.Models.Projects;

namespace OPUS.Data.Projects
{
    public interface IProjectDAO : IDataAccess<Project>
    {}
}
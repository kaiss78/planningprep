﻿using OPUS.Models.ProjectSteps;

namespace OPUS.Data.ProjectSteps
{
    public interface ICallForNominationStepDAO : IOpusStepDAO<CallForNominationStep>
    { }
}
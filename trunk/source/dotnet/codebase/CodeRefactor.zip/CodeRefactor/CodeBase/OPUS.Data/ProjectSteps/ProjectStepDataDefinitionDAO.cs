﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: [Project Name]
 * Module: [Assembly Name]
 * Name: ProjectStepDataDefinition.cs
 * Purpose: DAO Class to get/set the data from ProjectStepDataDefinition Table
 * 
 * Author: [Developer Name]
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/10/2010 16:08:32		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class ProjectStepDataDefinitionDAO : BaseDataAccess<ProjectStepDataDefinition>, IProjectStepDataDefinitionDAO
    {
        #region Constructor
        public ProjectStepDataDefinitionDAO()
        {
        }

        public ProjectStepDataDefinitionDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Save ProjectStepDataDefinition entity class.
        /// </summary>
        public override void Save(Models.ProjectSteps.ProjectStepDataDefinition entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectStepDataDefinitionDAO.Save(ProjectStepDataDefinition,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't save a null {0} entity.", typeof(Models.ProjectSteps.ProjectStepDataDefinition).Name));

                    entity.SetTableLevelAuditInfo(CurrentUser != null ? CurrentUser.Identity.Name : null);
                    entity.CleanBeforeSave();

                    DbParameter[] parameters = new[] {
													new DbParameter("Id", DbType.String, entity.Id),
													new DbParameter("StepID", DbType.String, entity.StepID),
													new DbParameter("FieldName", DbType.String, entity.FieldName),
													new DbParameter("WebCaption", DbType.String, entity.WebCaption),
													new DbParameter("DataType", DbType.String, entity.DataType),
													new DbParameter("Required", DbType.Boolean, entity.Required),
													new DbParameter("DefaultValue", DbType.String, entity.DefaultValue),
													new DbParameter("MinValue", DbType.String, entity.MinValue),
													new DbParameter("MaxValue", DbType.String, entity.MaxValue),
													new DbParameter("ControlType", DbType.String, entity.ControlType),
													new DbParameter("SelectionOptions", DbType.String, entity.SelectionOptions),
													new DbParameter("Active", DbType.Boolean, entity.Active),
													new DbParameter("Deleted", DbType.Boolean, entity.Deleted),
													new DbParameter("Locked", DbType.Boolean, entity.Locked),
													new DbParameter("CreatedBy", DbType.String, entity.CreatedBy),
													new DbParameter("CreatedByDateTime", DbType.String, entity.CreatedByDateTime),
													new DbParameter("LastModifiedBy", DbType.String, entity.LastModifiedBy),
													new DbParameter("LastModifiedByDateTime", DbType.DateTime, entity.LastModifiedByDateTime),
													new DbParameter("DatetimeStamp", DbType.DateTime, entity.DatetimeStamp),
												};

                    long newId = (long)SaveInternal("spProjectStepDataDefinitionSet", parameters);

                    if (entity.IsNew)
                    {
                        entity.Id = newId;
                    }
                }
                catch (Exception ex)
                {
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectStepDataDefinitionDAO.Save(ProjectStepDataDefinition,DbTransaction)");
                }
            }
        }

        public override bool Delete(Models.ProjectSteps.ProjectStepDataDefinition entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectStepDataDefinitionDAO.Delete(ProjectStepDataDefinition,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't delete a null {0} entity.", typeof(Models.ProjectSteps.ProjectStepDataDefinition).Name));

                    return DeleteInternal("spProjectStepDataDefinitionDelete", new DbParameter("Id", DbType.Int64, entity.Id));
                }
                catch (Exception ex)
                {
                    if (ex is DBConcurrencyException) // If concurrency error then let's do a soft delete.
                    {
                        entity.Deleted = true;

                        Save(entity);

                        return true;
                    }
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectStepDataDefinitionDAO.Delete(ProjectStepDataDefinition,DbTransaction)");
                }
            }
        }

        public override Models.ProjectSteps.ProjectStepDataDefinition Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDataDefinitionDAO.Get(long,bool)"))
            {
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    return GetInternal("spProjectStepDataDefinitionGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDataDefinitionDAO.Get(long,bool)");
                }
            }
        }

        public override List<Models.ProjectSteps.ProjectStepDataDefinition> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDataDefinitionDAO.GetAll(bool)"))
            {
                try
                {
                    return GetAllInternal("spProjectStepDataDefinitionGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDataDefinitionDAO.GetAll(bool)");
                }
            }
        }
        #endregion

        #region Helper Methods
        protected override Models.ProjectSteps.ProjectStepDataDefinition Map(IDataReader reader)
        {
            Models.ProjectSteps.ProjectStepDataDefinition entity = EntityFactory.Create<Models.ProjectSteps.ProjectStepDataDefinition>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.StepID = NullHandler.GetLong(reader["StepID"]);
            entity.FieldName = NullHandler.GetString(reader["FieldName"]);
            entity.WebCaption = NullHandler.GetString(reader["WebCaption"]);
            entity.DataType = NullHandler.GetString(reader["DataType"]);
            entity.Required = NullHandler.GetBoolean(reader["Required"]);
            entity.DefaultValue = NullHandler.GetString(reader["DefaultValue"]);
            entity.MinValue = NullHandler.GetString(reader["MinValue"]);
            entity.MaxValue = NullHandler.GetString(reader["MaxValue"]);
            entity.ControlType = NullHandler.GetString(reader["ControlType"]);
            entity.SelectionOptions = NullHandler.GetString(reader["SelectionOptions"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            return entity;
        }

        protected override void EagerLoad(Models.ProjectSteps.ProjectStepDataDefinition entity)
        {
            // Add eager loading functionality here
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(ProjectStepDataDefinition entity)
        {
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(ProjectStepDataDefinition entity)
        {
        }

        #endregion
    }
}
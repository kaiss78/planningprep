﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: [Project Name]
 * Module: [Assembly Name]
 * Name: OPUSStep.cs
 * Purpose: DAO Class to get/set the data from OPUSSteps Table
 * 
 * Author: [Developer Name]
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/10/2010 20:39:13		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.Enums;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class OpusStepDAO<TEntity> : BaseDataAccess<TEntity>, IOpusStepDAO<TEntity>
        where TEntity : OPUSStep
    {
        #region Constructor
        public OpusStepDAO()
        {
        }

        public OpusStepDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Save OPUSStep entity class.
        /// </summary>
        public override void Save(TEntity entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "OPUSStepDAO.Save(OPUSStep,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't save a null {0} entity.", typeof(TEntity).Name));

                    entity.SetTableLevelAuditInfo(CurrentUser != null ? CurrentUser.Identity.Name : null);
                    entity.CleanBeforeSave();

                    DbParameter[] parameters = new[] {
													new DbParameter("Id", DbType.String, entity.Id),
													new DbParameter("TypeId", DbType.String, entity.TypeId),
													new DbParameter("TypeIndicator", DbType.Int32, (int)entity.TypeIndicator),
													new DbParameter("Name", DbType.String, entity.Name),
													new DbParameter("StartDate", DbType.DateTime, entity.StartDate),
													new DbParameter("EndDate", DbType.DateTime, entity.EndDate),
													new DbParameter("BeforePeriodDescription", DbType.String, entity.BeforePeriodDescription),
													new DbParameter("DuringPeriodDescription", DbType.String, entity.DuringPeriodDescription),
													new DbParameter("AfterPeriodDescription", DbType.String, entity.AfterPeriodDescription),
													new DbParameter("DetailPage", DbType.String, entity.DetailPage),
													new DbParameter("Active", DbType.Boolean, entity.Active),
													new DbParameter("Deleted", DbType.Boolean, entity.Deleted),
													new DbParameter("Locked", DbType.Boolean, entity.Locked),
													new DbParameter("CreatedBy", DbType.String, entity.CreatedBy),
													new DbParameter("CreatedByDateTime", DbType.String, entity.CreatedByDateTime),
													new DbParameter("LastModifiedBy", DbType.String, entity.LastModifiedBy),
													new DbParameter("LastModifiedByDateTime", DbType.DateTime, entity.LastModifiedByDateTime),
													new DbParameter("DatetimeStamp", DbType.DateTime, entity.DatetimeStamp),
												};

                    long newId = (long)SaveInternal("spOPUSStepSet", parameters);

                    if (entity.IsNew)
                        entity.Id = newId;
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "OPUSStepDAO.Save(OPUSStep,DbTransaction)");
                }
            }
        }

        public override bool Delete(TEntity entity)
        {
            bool result;
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "OPUSStepDAO.Delete(OPUSStep,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't delete a null {0} entity.", typeof(TEntity).Name));

                    result = DeleteInternal("spOPUSStepDelete", new DbParameter("Id", DbType.Int64, entity.Id));
                }
                catch (Exception ex)
                {
                    if (ex is InvalidConstraintException) // If foreign key constraint exception then let's do a soft delete.
                    {
                        entity.Deleted = true;
                        Save(entity);

                        result = true;
                    }
                    else
                    {
                        result = false;
                        HandleDataAccessException(ex, "OPUSStepDAO.Delete(OPUSStep,DbTransaction)");
                    }
                }
            }

            return result;
        }

        public override TEntity Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "OPUSStepDAO.Get(long,bool)"))
            {
                TEntity foundEntity = default(TEntity);
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    foundEntity = GetInternal("spOPUSStepGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "OPUSStepDAO.Get(long,bool)");
                }

                return foundEntity;
            }
        }

        public override List<TEntity> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "OPUSStepDAO.GetAll(bool)"))
            {
                List<TEntity> foundModels = new List<TEntity>();
                try
                {
                    foundModels = GetAllInternal("spOPUSStepGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "OPUSStepDAO.GetAll(bool)");
                }
                return foundModels;
            }
        }

        #endregion

        #region Helper Methods
        protected override TEntity Map(IDataReader reader)
        {
            TEntity entity = EntityFactory.Create<TEntity>();

            entity.IsLoading = true;

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.TypeId = NullHandler.GetLong(reader["TypeId"]);
            entity.TypeIndicator = NullHandler.GetEnum<OPUSStepTypes>(reader["TypeIndicator"]);
            entity.Name = NullHandler.GetString(reader["Name"]);
            entity.StartDate = NullHandler.GetDateTime(reader["StartDate"]);
            entity.EndDate = NullHandler.GetDateTime(reader["EndDate"]);
            entity.BeforePeriodDescription = NullHandler.GetString(reader["BeforePeriodDescription"]);
            entity.DuringPeriodDescription = NullHandler.GetString(reader["DuringPeriodDescription"]);
            entity.AfterPeriodDescription = NullHandler.GetString(reader["AfterPeriodDescription"]);
            entity.DetailPage = NullHandler.GetString(reader["DetailPage"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            entity.IsLoading = false;

            return entity;
        }

        protected override void EagerLoad(TEntity entity)
        {
            // Add eager loading functionality here
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(TEntity entity)
        {
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(TEntity entity)
        {
        }

        #endregion
    }
}
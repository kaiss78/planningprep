﻿using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class ConsensusReviewStepDAO : OpusStepDAO<ConsensusReviewStep>, IConsensusReviewStepDAO
    {
        #region Constructor
        public ConsensusReviewStepDAO()
        {
        }

        public ConsensusReviewStepDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion
    }
}

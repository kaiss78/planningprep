﻿using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core.DB;
using System.Data.Common;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class ProjectTypeStepDAO : BaseDataAccess<OPUSStepType>, IProjectTypeStepDAO
    {
        protected override OPUSStepType Map(IDataReader reader)
        {
            OPUSStepType opusProjectTypeStep = EntityFactory.Create<OPUSStepType>();

            opusProjectTypeStep.Id = NullHandler.GetLong(reader["ProjectTypeStepID"]);
            //opusProjectTypeStep.StepID = NullHandler.GetLong(reader["StepID"]);
            //opusProjectTypeStep.ParentStepID = NullHandler.GetLong(reader["ParentStepID"]);
            //opusProjectTypeStep.ProjectTypeID = NullHandler.GetLong(reader["ProjectTypeID"]);
            //opusProjectTypeStep.ProjectTypeStepName = NullHandler.GetString(reader["ProjectTypeStepName"]);

            return opusProjectTypeStep;  
        }

        protected override void EagerLoad(OPUSStepType entity)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(OPUSStepType entity)
        {
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(OPUSStepType entity)
        {
        }
    }
}



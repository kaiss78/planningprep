﻿using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class RosterCommentingPeriodStepDAO : OpusStepDAO<RosterCommentingPeriodStep>, IRosterCommentingPeriodStepDAO
    {
        public override RosterCommentingPeriodStep Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "RosterCommentingPeriodStepDAO.Get(long,bool)"))
            {
                RosterCommentingPeriodStep foundModel = EntityFactory.Create<RosterCommentingPeriodStep>();
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    foundModel = GetInternal("spRosterCommentingPeriodStepGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "RosterCommentingPeriodStepDAO.Get(long,bool)");
                }

                return foundModel;
            }
        }

        public override List<RosterCommentingPeriodStep> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "RosterCommentingPeriodStepDAO.GetAll(bool)"))
            {
                List<RosterCommentingPeriodStep> foundModels = new List<RosterCommentingPeriodStep>();
                try
                {
                    foundModels = GetAllInternal("spRosterCommentingPeriodStepGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "RosterCommentingPeriodStepDAO.GetAll(bool)");
                }
                return foundModels;
            }
        }
    }
}



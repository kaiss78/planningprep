﻿using System.Collections.Generic;
using OPUS.Models.History;
using Pantheon.Core.Base.Model;

namespace OPUS.Data.History
{
    public interface IHistoryDataDAO : IDataAccess<HistoryData>
    {
        /// <summary>
        /// Gets the history for record.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="recordId">The record id.</param>
        /// <returns></returns>
        List<HistoryData> GetAllForRecord<T>(long recordId) where T : BaseEntity;
    }
}
﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: [Project Name]
 * Module: [Assembly Name]
 * Name: ProjectStep.cs
 * Purpose: DAO Class to get/set the data from ProjectSteps Table
 * 
 * Author: [Developer Name]
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/10/2010 20:43:40		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class ProjectStepDAO : BaseDataAccess<ProjectStep>, IProjectStepDAO
    {
        #region Constructor
        public ProjectStepDAO()
        {
        }

        public ProjectStepDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Save ProjectStep entity class.
        /// </summary>
        public override void Save(ProjectStep entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectStepDAO.Save(ProjectStep,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't save a null {0} entity.", typeof(ProjectStep).Name));

                    entity.SetTableLevelAuditInfo(CurrentUser != null ? CurrentUser.Identity.Name : null);
                    entity.CleanBeforeSave();

                    DbParameter[] parameters = new[] {
													new DbParameter("Id", DbType.String, entity.Id),
													new DbParameter("SubmissionId", DbType.String, entity.SubmissionId),
													new DbParameter("StepId", DbType.String, entity.Step),
													new DbParameter("ParentStepId", DbType.String, entity.ParentStepId),
													new DbParameter("SortOrder", DbType.Int32, entity.SortOrder),
													new DbParameter("Active", DbType.Boolean, entity.Active),
													new DbParameter("Deleted", DbType.Boolean, entity.Deleted),
													new DbParameter("Locked", DbType.Boolean, entity.Locked),
													new DbParameter("CreatedBy", DbType.String, entity.CreatedBy),
													new DbParameter("CreatedByDateTime", DbType.DateTime, entity.CreatedByDateTime),
													new DbParameter("LastModifiedBy", DbType.String, entity.LastModifiedBy),
													new DbParameter("LastModifiedByDateTime", DbType.DateTime, entity.LastModifiedByDateTime),
													new DbParameter("DatetimeStamp", DbType.DateTime, entity.DatetimeStamp),
												};

                    // Perform save returning new Id of insert or the amount of rows updated
                    long newId = (long)SaveInternal("spProjectStepSet", parameters);
                    
                    // Set Id of newly inserted Project Step
                    if (entity.IsNew)
                        entity.Id = newId;

                    // Save OPUS Step
                    if (entity.Step != null)
                        SaveOPUSStep(entity);

                    // Save Parent Project Step
                    if (entity.ParentStep != null)
                        Save(entity);

                    // Save Project Step Data
                    if (entity.Data != null)
                        SaveProjectStepData(entity);
                }
                catch (Exception ex)
                {
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectStepDAO.Save(ProjectStep,DbTransaction)");
                }
            }
        }

        public override bool Delete(ProjectStep entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectStepDAO.Delete(ProjectStep,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't delete a null {0} entity.", typeof(ProjectStep).Name));

                    return DeleteInternal("spProjectStepDelete", new DbParameter("Id", DbType.Int64, entity.Id));
                }
                catch (Exception ex)
                {
                    if (ex is InvalidConstraintException) // If foreign key constraint exception then let's do a soft delete.
                    {
                        entity.Deleted = true;
                        Save(entity);

                        return true;
                    }
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectStepDAO.Delete(ProjectStep,DbTransaction)");
                }
            }
        }

        public override ProjectStep Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDAO.Get(long,bool)"))
            {
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    return GetInternal("spProjectStepGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDAO.Get(long,bool)");
                }
            }
        }

        public override List<ProjectStep> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDAO.GetAll(bool)"))
            {
                try
                {
                    return GetAllInternal("spProjectStepGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDAO.GetAll(bool)");
                }
            }
        }

        public List<ProjectStep> GetAllBySubmissionId(long submissionId, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDAO.GetAllBySubmissionId(long,bool)"))
            {
                List<ProjectStep> foundModels = new List<ProjectStep>();
                try
                {
                    Check.Require(submissionId > 0, "Can't get an project steps with a invalid  submission id.");

                    DbParameter[] parameters = new[] { new DbParameter("SubmissionId", DbType.Int64, submissionId) };

                    foundModels = GetAllInternal("spProjectStepsGetAllBySubmissionId", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "ProjectStepDAO.GetAllBySubmissionId(long,bool)");
                }
                return foundModels;
            }
        }

        public List<ProjectStep> GetAllByProjectId(long projectId, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDAO.GetAllByProjectId(long,bool)"))
            {
                List<ProjectStep> foundModels = new List<ProjectStep>();
                try
                {
                    Check.Require(projectId > 0, "Can't get an project steps with a invalid project id.");

                    DbParameter[] parameters = new[] { new DbParameter("ProjectId", DbType.Int64, projectId) };

                    foundModels = GetAllInternal("spProjectStepsGetAllByProjectId", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "ProjectStepDAO.GetAllByProjectId(long,bool)");
                }
                return foundModels;
            }
        }
        #endregion


        #region Private Methods
        private void SaveProjectStepData(ProjectStep entity)
        {
            using (ProjectStepDataDAO dao = (ProjectStepDataDAO)DAOFactory.Get<ProjectStepData>())
            {
                foreach(ProjectStepData data in entity.Data )
                {
                    if(data.IsNew)
                    {
                        if (data.ProjectStepId <= 0)
                            data.ProjectStepId = entity.Id;

                        if (data.Step == null)
                            data.Step = entity;

                        dao.Save(data);
                    }
                }
            }
        }

        private void SaveOPUSStep(ProjectStep entity)
        {
            using (IDataAccess<OPUSStep> dao = DAOFactory.Get<OPUSStep>())
                dao.Save(entity.Step);
        }
        #endregion

        #region Helper Methods
        protected override ProjectStep Map(IDataReader reader)
        {
            ProjectStep entity = EntityFactory.Create<ProjectStep>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.SubmissionId = NullHandler.GetLong(reader["SubmissionId"]);
            entity.OPUSStepId = NullHandler.GetLong(reader["StepId"]);
            entity.ParentStepId = NullHandler.GetLong(reader["ParentStepId"]);
            entity.SortOrder = NullHandler.GetInt32(reader["SortOrder"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            return entity;
        }

        protected override void EagerLoad(ProjectStep entity)
        {
            // Add eager loading functionality here
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(ProjectStep entity)
        {
         
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(ProjectStep entity)
        {
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class NominationPeriodStepDAO : OpusStepDAO<NominationPeriodStep>, INominationPeriodStepDAO
    {
        #region Constructor
        public NominationPeriodStepDAO()
        {
        }

        public NominationPeriodStepDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion
    }
}



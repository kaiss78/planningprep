using OPUS.Models.Projects;

namespace OPUS.Data.Projects
{
    public interface IProjectTypeDAO : IDataAccess<ProjectType>
    {
    }
}
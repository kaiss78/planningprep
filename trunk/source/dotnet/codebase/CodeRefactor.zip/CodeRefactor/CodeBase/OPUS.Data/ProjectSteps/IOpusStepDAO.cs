﻿using OPUS.Models.ProjectSteps;

namespace OPUS.Data.ProjectSteps
{
    public interface IOpusStepDAO<TEntity> : IDataAccess<TEntity>
        where TEntity : OPUSStep
    {}
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class SubmissionPeriodStepDAO : OpusStepDAO<SubmissionPeriodStep>, ISubmissionPeriodStepDAO
    {
        public override SubmissionPeriodStep Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "SubmissionPeriodStepDAO.Get(long,bool)"))
            {
                SubmissionPeriodStep foundModel = EntityFactory.Create<SubmissionPeriodStep>();
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    foundModel = GetInternal("spSubmissionPeriodStepGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "SubmissionPeriodStepDAO.Get(long,bool)");
                }

                return foundModel;
            }
        }

        public override List<SubmissionPeriodStep> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "SubmissionPeriodStepDAO.GetAll(bool)"))
            {
                List<SubmissionPeriodStep> foundModels = new List<SubmissionPeriodStep>();
                try
                {
                    foundModels = GetAllInternal("spSubmissionPeriodStepGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    HandleDataAccessException(ex, "SubmissionPeriodStepDAO.GetAll(bool)");
                }
                return foundModels;
            }
        }
    }
}



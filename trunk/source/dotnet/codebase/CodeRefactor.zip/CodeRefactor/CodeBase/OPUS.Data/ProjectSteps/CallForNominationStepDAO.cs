﻿using OPUS.Models.ProjectSteps;

namespace OPUS.Data.ProjectSteps
{
    public class CallForNominationStepDAO : OpusStepDAO<CallForNominationStep>, ICallForNominationStepDAO
    {
    }
}



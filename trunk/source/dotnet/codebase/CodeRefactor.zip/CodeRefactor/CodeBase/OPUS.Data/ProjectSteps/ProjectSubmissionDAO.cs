﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: OPUS
 * Module: OPUS.Data
 * Name: ProjectSubmissionDAO.cs
 * Purpose: DAO Class to get/set the data from ProjectSubmissions table.
 * 
 * Author: Jason Duffus
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/11/2010 21:51:18		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using OPUS.Data.Projects;
using OPUS.Models.Projects;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class ProjectSubmissionDAO : BaseDataAccess<ProjectSubmission>, IProjectSubmissionDAO
    {
        #region Constructor
        public ProjectSubmissionDAO()
        {
        }

        public ProjectSubmissionDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Save ProjectSubmission entity class.
        /// </summary>
        public override void Save(ProjectSubmission entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectSubmissionDAO.Save(ProjectSubmission)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't save a null {0} entity.", typeof(ProjectSubmission).Name));

                    entity.SetTableLevelAuditInfo(CurrentUser != null ? CurrentUser.Identity.Name : null);
                    entity.CleanBeforeSave();

                    DbParameter[] parameters = new[] {
													new DbParameter("Id", DbType.String, entity.Id),
													new DbParameter("Name", DbType.String, entity.Name),
													new DbParameter("ProjectId", DbType.String, entity.ProjectId),
													new DbParameter("Active", DbType.Boolean, entity.Active),
													new DbParameter("Deleted", DbType.Boolean, entity.Deleted),
													new DbParameter("Locked", DbType.Boolean, entity.Locked),
													new DbParameter("CreatedBy", DbType.String, entity.CreatedBy),
													new DbParameter("CreatedByDateTime", DbType.DateTime, entity.CreatedByDateTime),
													new DbParameter("LastModifiedBy", DbType.String, entity.LastModifiedBy),
													new DbParameter("LastModifiedByDateTime", DbType.DateTime, entity.LastModifiedByDateTime),
													new DbParameter("DatetimeStamp", DbType.DateTime, entity.DatetimeStamp),
												};

                    long newId = (long)SaveInternal("spProjectSubmissionSet", parameters);

                    if (entity.IsNew)
                    {
                        entity.Id = newId;
                    }
                }
                catch (Exception ex)
                {
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectSubmissionDAO.Save(ProjectSubmission)");
                }
            }
        }

        public override bool Delete(ProjectSubmission entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectSubmissionDAO.Delete(ProjectSubmission)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't delete a null {0} entity.", typeof(ProjectSubmission).Name));

                    return DeleteInternal("spProjectSubmissionDelete", new DbParameter("Id", DbType.Int64, entity.Id));
                }
                catch (Exception ex)
                {
                    if (ex is InvalidConstraintException) // If foreign key constraint exception then let's do a soft delete.
                    {
                        entity.Deleted = true;
                        Save(entity);

                        return true;
                    }
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectSubmissionDAO.Delete(ProjectSubmission)");
                }
            }
        }

        public override ProjectSubmission Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectSubmissionDAO.Get(long,bool)"))
            {
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    return GetInternal("spProjectSubmissionGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectSubmissionDAO.Get(long,bool)");
                }
            }
        }

        public override List<ProjectSubmission> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectSubmissionDAO.GetAll(bool)"))
            {
                try
                {
                    return GetAllInternal("spProjectSubmissionGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectSubmissionDAO.GetAll(bool)");
                }
            }
        }
        #endregion

        #region Helper Methods
        protected override ProjectSubmission Map(IDataReader reader)
        {
            ProjectSubmission entity = EntityFactory.Create<ProjectSubmission>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.Name = NullHandler.GetString(reader["Name"]);
            entity.ProjectId = NullHandler.GetLong(reader["ProjectId"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            return entity;
        }

        protected override void EagerLoad(ProjectSubmission entity)
        {
            // Add eager loading functionality here
            using (ProjectDAO dao = (ProjectDAO) DAOFactory.Get<Project>())
            {
                entity.Project = dao.Get(entity.ProjectId);
            }

            using (ProjectStepDAO dao = (ProjectStepDAO)DAOFactory.Get<ProjectStep>())
            {
                entity.ProjectSteps = dao.GetAllBySubmissionId(entity.Id, true);
            }
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(ProjectSubmission entity)
        {
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(ProjectSubmission entity)
        {
        }

        #endregion
    }
}
﻿using OPUS.Models.ProjectSteps;

namespace OPUS.Data.ProjectSteps
{
    public class CustomStepDAO : OpusStepDAO<CustomStep>, ICustomStepDAO
    {
        #region Constructor
        public CustomStepDAO()
        {
        }

        public CustomStepDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion
    }
}



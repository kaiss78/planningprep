﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: [Project Name]
 * Module: [Assembly Name]
 * Name: ProjectStepData.cs
 * Purpose: DAO Class to get/set the data from ProjectStepData Table
 * 
 * Author: [Developer Name]
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/10/2010 11:40:53		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.ProjectSteps;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;

namespace OPUS.Data.ProjectSteps
{
    public class ProjectStepDataDAO : BaseDataAccess<ProjectStepData>, IProjectStepDataDAO
    {
        #region Constructor
        public ProjectStepDataDAO()
        {
        }

        public ProjectStepDataDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Save ProjectStepData entity class.
        /// </summary>
        public override void Save(Models.ProjectSteps.ProjectStepData entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectStepDataDAO.Save(ProjectStepData,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't save a null {0} entity.", typeof(Models.ProjectSteps.ProjectStepData).Name));

                    entity.SetTableLevelAuditInfo(CurrentUser != null ? CurrentUser.Identity.Name : null);
                    entity.CleanBeforeSave();

                    DbParameter[] parameters = new[] {
													new DbParameter("Id", DbType.String, entity.Id),
													new DbParameter("DefinitionId", DbType.String, entity.DefinitionId),
													new DbParameter("ProjectStepId", DbType.String, entity.ProjectStepId),
													new DbParameter("Value", DbType.String, entity.Value),
													new DbParameter("Active", DbType.Boolean, entity.Active),
													new DbParameter("Deleted", DbType.Boolean, entity.Deleted),
													new DbParameter("Locked", DbType.Boolean, entity.Locked),
													new DbParameter("CreatedBy", DbType.String, entity.CreatedBy),
													new DbParameter("CreatedByDateTime", DbType.String, entity.CreatedByDateTime),
													new DbParameter("LastModifiedBy", DbType.String, entity.LastModifiedBy),
													new DbParameter("LastModifiedByDateTime", DbType.DateTime, entity.LastModifiedByDateTime),
													new DbParameter("DatetimeStamp", DbType.DateTime, entity.DatetimeStamp),
												};

                    long newId = (long)SaveInternal("spProjectStepDataSet", parameters);

                    if (entity.IsNew)
                    {
                        entity.Id = newId;
                    }

                }
                catch (Exception ex)
                {
                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectStepDataDAO.Save(ProjectStepData,DbTransaction)");
                }
            }
        }

        public override bool Delete(ProjectStepData entity)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "Unknown User", "ProjectStepDataDAO.Delete(ProjectStepData,DbTransaction)"))
            {
                try
                {
                    Check.Require(entity != null, string.Format("Can't delete a null {0} entity.", typeof(ProjectStepData).Name));

                    return DeleteInternal("spProjectStepDataDelete", new DbParameter("Id", DbType.Int64, entity.Id));
                }
                catch (Exception ex)
                {
                    if (ex is DBConcurrencyException) // If concurrency error then let's do a soft delete.
                    {
                        entity.Deleted = true;
                        Save(entity);
                        return true;
                    }

                    Exception excToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(excToUse.Message, excToUse, "ProjectStepDataDAO.Delete(ProjectStepData,DbTransaction)");
                }
            }
        }

        public override ProjectStepData Get(long id, bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDataDAO.Get(long,bool)"))
            {
                try
                {
                    Check.Require(id > 0, "Can't get an entity with a invalid id.");

                    DbParameter[] parameters = new[] { new DbParameter("Id", DbType.Int64, id) };

                    return GetInternal("spProjectStepDataGetById", parameters, eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDataDAO.Get(long,bool)");
                }
            }
        }

        public override List<ProjectStepData> GetAll(bool eagerLoad)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDataDAO.GetAll(bool)"))
            {
                try
                {
                    return GetAllInternal("spProjectStepDataGetAll", eagerLoad);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDataDAO.GetAll(bool)");
                }
            }
        }
        #endregion

        #region Filter Methods
        public List<Models.ProjectSteps.ProjectStepData> GetAllByProjectStep(long stepId)
        {
            using (new TimedTraceLog(CurrentUser != null ? CurrentUser.Identity.Name : "", "ProjectStepDataDAO.GetAllByProjectStep(long)"))
            {
                try
                {
                    Check.Require(stepId > 0, "Can't get an entity with a invalid id.");

                    return GetAll(data => data.ProjectStepId == stepId);
                }
                catch (Exception ex)
                {
                    Exception exToUse = ex.InnerException ?? ex;
                    throw new DataAccessException(exToUse.Message, exToUse, "ProjectStepDataDAO.GetAllByProjectStep(long)");
                }
            }
        }
        #endregion

        #region Helper Methods
        protected override ProjectStepData Map(IDataReader reader)
        {
            ProjectStepData entity = EntityFactory.Create<ProjectStepData>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.DefinitionId = NullHandler.GetLong(reader["DefinitionID"]);
            entity.ProjectStepId = NullHandler.GetLong(reader["ProjectStepID"]);
            entity.Value = NullHandler.GetString(reader["Value"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            return entity;
        }

        protected override void EagerLoad(ProjectStepData entity)
        {
            // Add eager loading functionality here
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(ProjectStepData entity)
        {
        
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(ProjectStepData entity)
        {
        }

        #endregion
    }
}



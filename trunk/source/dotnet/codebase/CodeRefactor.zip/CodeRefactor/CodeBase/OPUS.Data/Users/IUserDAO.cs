﻿using OPUS.Models.Users;

namespace OPUS.Data.Users
{
    public interface IUserDAO : IDataAccess<User>
    {
        bool IsUserAssignedToProject(long userId, long projectId);
        User GetByUserName(string userName);
    }
}
﻿#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: [Project Name]
 * Module: [Assembly Name]
 * Name: Project.cs
 * Purpose: DAO Class to get/set the data from Projects Table
 * 
 * Author: [Developer Name]
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * User					Date					Comments
 * [Developer Name]		01/09/2010 19:42:34		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data;
using OPUS.Models.Projects;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;

namespace OPUS.Data.Projects
{
    public class ProjectDAO : BaseDataAccess<Project>, IProjectDAO
    {
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectDAO"/> class.
        /// </summary>
        public ProjectDAO()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectDAO"/> class.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        public ProjectDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Helper Methods
        /// <summary>
        /// Maps and sets the Entity Model from the specified reader.
        /// </summary>
        /// <param name="reader">The reader.</param>
        /// <returns></returns>
        protected override Project Map(IDataReader reader)
        {
            Project entity = EntityFactory.Create<Project>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.Name = NullHandler.GetString(reader["Name"]);
            entity.ShortName = NullHandler.GetString(reader["ShortName"]);
            entity.StartDate = NullHandler.GetDateTime(reader["StartDate"]);
            entity.EndDate = NullHandler.GetDateTime(reader["EndDate"]);
            entity.TypeId = NullHandler.GetLong(reader["TypeId"]);
            entity.Status = NullHandler.GetString(reader["Status"]);
            entity.StatusSummary = NullHandler.GetString(reader["StatusSummary"]);
            entity.Explanation = NullHandler.GetString(reader["Explanation"]);
            entity.ShortDescription = NullHandler.GetString(reader["ShortDescription"]);
            entity.FullDescription = NullHandler.GetString(reader["FullDescription"]);
            entity.SoftekId = NullHandler.GetLong(reader["SoftekId"]);
            entity.SubmissionInstruction = NullHandler.GetString(reader["SubmissionInstruction"]);
            entity.DetailIntro = NullHandler.GetString(reader["DetailIntro"]);
            entity.Proposal = NullHandler.GetString(reader["Proposal"]);
            entity.Contract = NullHandler.GetString(reader["Contract"]);
            entity.Conditions = NullHandler.GetString(reader["Conditions"]);
            entity.CareSettings = NullHandler.GetString(reader["CareSettings"]);
            entity.NPPTopics = NullHandler.GetString(reader["NPPTopics"]);
            entity.Completed = NullHandler.GetBoolean(reader["Completed"]);
            entity.Active = NullHandler.GetBoolean(reader["Active"]);
            entity.Deleted = NullHandler.GetBoolean(reader["Deleted"]);
            entity.Locked = NullHandler.GetBoolean(reader["Locked"]);
            entity.CreatedBy = NullHandler.GetString(reader["CreatedBy"]);
            entity.CreatedByDateTime = NullHandler.GetDateTime(reader["CreatedByDateTime"]);
            entity.LastModifiedBy = NullHandler.GetString(reader["LastModifiedBy"]);
            entity.LastModifiedByDateTime = NullHandler.GetDateTime(reader["LastModifiedByDateTime"]);
            entity.DatetimeStamp = NullHandler.GetDateTime(reader["DatetimeStamp"]);

            return entity;
        }

        protected override void EagerLoad(Project entity)
        {
            // Add eager loading functionality here
            using (IProjectTypeDAO dao = (IProjectTypeDAO) DAOFactory.Get<ProjectType>())
            {
                entity.ProjectType = dao.Get(entity.TypeId);
            }
        }

        /// <summary>
        /// Saves the reference properties before.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesBefore(Project entity)
        {
        }

        /// <summary>
        /// Saves the reference properties after.
        /// </summary>
        /// <param name="entity">The entity.</param>
        protected override void SaveReferencePropertiesAfter(Project entity)
        {
        }

        #endregion
    }
}
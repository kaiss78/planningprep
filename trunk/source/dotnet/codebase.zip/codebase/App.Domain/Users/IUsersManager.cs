﻿using App.Models.Users;
using Pantheon.Core.Base.Managers;

namespace App.Domain.Users
{
    public interface IUsersManager : IManagerBase<User>
    {
        
    }
}
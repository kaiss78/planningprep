﻿namespace App.Models.Enums
{
    public enum NomineeFileTypes : byte
    {
        LetterOfInterest = 1,
        CVorExperience = 2,
        NonDisclosureAgreement = 3
    }
}

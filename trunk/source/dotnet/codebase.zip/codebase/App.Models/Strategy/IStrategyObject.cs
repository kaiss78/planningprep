namespace Pantheon.Entity.Strategy
{
    /// <summary>
    /// 
    /// </summary>
    public interface IStrategyObject
    {
    }
}



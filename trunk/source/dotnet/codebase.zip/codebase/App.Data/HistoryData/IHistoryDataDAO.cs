﻿namespace OPUS.Data.HistoryData
{
    public interface IHistoryDataDAO : IDataAccess<Models.HistoryData.HistoryData>
    { }
}
﻿
using App.Models.Products;
namespace App.Data.Products
{
    public interface IProductDAO : IDataAccess<Product>
    { }
}
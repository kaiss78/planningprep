﻿


#region File Info/History
/*
 * --------------------------------------------------------------------------------
 * Project Name: App
 * Module: App.Data
 * Name: ProductCategoryDAO.cs
 * Purpose: DAO Class to get/set the data from ProductCategory table.
 * 
 * Author: AFS
 * Language: C# SDK version 3.5
 * --------------------------------------------------------------------------------
 * Change History:
 * Product					Date					Comments
 * [Developer Name]		03/04/2010 13:31:47		Initial Development
 * -------------------------------------------------------------------------------- 
 */
#endregion

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using App.Models.Enums;
using Pantheon.Core;
using Pantheon.Core.DB;
using Pantheon.Core.Exceptions;
using Pantheon.Core.Factories;
using System.Security.Principal;
using Models.Products;

namespace App.Data.Products
{
    

    public class ProductCategoryDAO : BaseDataAccess<ProductCategory>, IProductCategoryDAO
    {
        #region Constructor
        public ProductCategoryDAO()
        {
        }

        public ProductCategoryDAO(string connectionString)
            : base(connectionString)
        {
        }
        #endregion

        #region Helper Methods
        protected override ProductCategory Map(IDataReader reader)
        {
            ProductCategory entity = EntityFactory.Create<ProductCategory>();

            entity.Id = NullHandler.GetLong(reader["Id"]);
            entity.ProductCategoryName = NullHandler.GetString(reader["ProductCategoryName"]);

            return entity;
        }

        protected override void EagerLoad(ProductCategory entity)
        {
            // Add eager loading functionality here
        }
        #endregion
    }
}

﻿namespace Pantheon.Core.Base.Managers.Responses
{
    public class SaveOrUpdateResponse : SingleResponse
    {
       
    }
}

﻿using System.Collections;

namespace Pantheon.Core.Base.Managers.Responses
{
    public class ListResponse : PanthResponse
    {
        IList Objects { get; set; }
    }
}

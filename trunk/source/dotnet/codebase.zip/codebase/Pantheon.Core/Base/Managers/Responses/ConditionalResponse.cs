﻿namespace Pantheon.Core.Base.Managers.Responses
{
    public abstract class ConditionalResponse : PanthResponse
    {
    }
}
